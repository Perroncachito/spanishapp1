import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser, insertUserSchema } from "@shared/schema";
import { z } from "zod";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

const registerSchema = insertUserSchema.extend({
  confirmPassword: z.string(),
  invitationCode: z.string().regex(/^SRLS-[A-Z0-9]{4}-[A-Z0-9]{4}$/, {
    message: "Invitation code must be in the format SRLS-XXXX-XXXX",
  }),
  parentPin: z.string().regex(/^\d{4}$/, {
    message: "PIN must be a 4-digit number",
  }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "srls-spanish-secret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false);
        } else {
          return done(null, user);
        }
      } catch (err) {
        return done(err);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      const parsed = registerSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ errors: parsed.error.format() });
      }

      const { invitationCode, confirmPassword, ...userData } = parsed.data;

      // Check if invitation code is valid
      const code = await storage.getInvitationCode(invitationCode);
      if (!code) {
        return res.status(400).json({ message: "Invalid invitation code" });
      }
      
      if (code.isUsed) {
        return res.status(400).json({ message: "Invitation code already used" });
      }
      
      if (code.expiresAt && code.expiresAt < new Date()) {
        return res.status(400).json({ message: "Invitation code has expired" });
      }

      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Create user with hashed password
      const user = await storage.createUser({
        ...userData,
        password: await hashPassword(userData.password),
        invitationCode,
      });

      // Mark invitation code as used
      await storage.useInvitationCode(invitationCode, user.id);

      // Create default progress record
      await storage.createProgress({
        userId: user.id,
        currentLevel: 1,
        completedLevels: [],
        totalTimeSpent: 0,
        lastPlayed: new Date(),
        lastGameType: null,
      });

      // Create default parent settings
      await storage.createParentSettings({
        userId: user.id,
        sessionDuration: 30,
        dailyTimeLimit: 60,
        availableDays: ["1", "2", "3", "4", "5"],
        startTime: "15:00",
        endTime: "18:00",
        deviceRestriction: true,
      });

      // Create first achievement
      await storage.createAchievement({
        userId: user.id,
        achievementType: "registration",
        metadata: { message: "Welcome to SRLS Spanish!" },
      });

      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json(user);
      });
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/login", passport.authenticate("local"), (req, res) => {
    res.status(200).json(req.user);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });
  
  app.post("/api/verify-pin", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const { pin } = req.body;
    if (!pin) {
      return res.status(400).json({ message: "PIN is required" });
    }
    
    if (req.user.parentPin === pin) {
      return res.status(200).json({ valid: true });
    } else {
      return res.status(200).json({ valid: false });
    }
  });
  
  app.post("/api/update-pin", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const { currentPin, newPin } = req.body;
      
      if (!currentPin || !newPin) {
        return res.status(400).json({ message: "Current PIN and new PIN are required" });
      }
      
      if (req.user.parentPin !== currentPin) {
        return res.status(400).json({ message: "Current PIN is incorrect" });
      }
      
      if (!/^\d{4}$/.test(newPin)) {
        return res.status(400).json({ message: "New PIN must be a 4-digit number" });
      }
      
      const updatedUser = await storage.updateUserPin(req.user.id, newPin);
      res.status(200).json(updatedUser);
    } catch (err) {
      next(err);
    }
  });
}
