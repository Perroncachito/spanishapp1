import { 
  User, InsertUser, 
  Progress, InsertProgress, 
  ParentSettings, InsertParentSettings,
  Achievement, InsertAchievement,
  InvitationCode, InsertInvitationCode,
  QuizResult, InsertQuizResult,
  GameSession, InsertGameSession,
  users, progress, parentSettings, achievements, invitationCodes, quizResults, gameSessions
} from "@shared/schema";
import session from "express-session";
import { Store as SessionStore } from "express-session";
import createMemoryStore from "memorystore";
import { pool, db } from "./db";
import { eq, and, desc, isNull } from "drizzle-orm";
import connectPg from "connect-pg-simple";

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPin(userId: number, newPin: string): Promise<User>;
  updateUserDevice(userId: number, deviceFingerprint: string): Promise<User>;
  
  // Progress methods
  getProgress(userId: number): Promise<Progress | undefined>;
  createProgress(progress: InsertProgress): Promise<Progress>;
  updateProgress(userId: number, progress: Partial<Progress>): Promise<Progress>;
  
  // Parent settings methods
  getParentSettings(userId: number): Promise<ParentSettings | undefined>;
  createParentSettings(settings: InsertParentSettings): Promise<ParentSettings>;
  updateParentSettings(userId: number, settings: Partial<ParentSettings>): Promise<ParentSettings>;
  
  // Achievement methods
  getAchievements(userId: number): Promise<Achievement[]>;
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;
  
  // Invitation code methods
  getInvitationCode(code: string): Promise<InvitationCode | undefined>;
  createInvitationCode(code: InsertInvitationCode): Promise<InvitationCode>;
  useInvitationCode(code: string, userId: number): Promise<InvitationCode>;
  
  // Quiz results methods
  getQuizResults(userId: number, levelId?: number): Promise<QuizResult[]>;
  createQuizResult(result: InsertQuizResult): Promise<QuizResult>;
  
  // Game session methods
  getGameSessions(userId: number): Promise<GameSession[]>;
  getActiveGameSession(userId: number): Promise<GameSession | undefined>;
  createGameSession(session: InsertGameSession): Promise<GameSession>;
  updateGameSession(sessionId: number, data: Partial<GameSession>): Promise<GameSession>;
  completeGameSession(sessionId: number, timeSpent: number): Promise<GameSession>;
  
  // Session store
  sessionStore: SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private progressRecords: Map<number, Progress>;
  private parentSettingsRecords: Map<number, ParentSettings>;
  private achievementRecords: Achievement[];
  private invitationCodes: Map<string, InvitationCode>;
  private quizResults: QuizResult[];
  private gameSessions: GameSession[];
  
  private currentUserId: number;
  private currentProgressId: number;
  private currentSettingsId: number;
  private currentAchievementId: number;
  private currentInvitationId: number;
  private currentQuizResultId: number;
  private currentGameSessionId: number;
  
  sessionStore: SessionStore;

  constructor() {
    this.users = new Map();
    this.progressRecords = new Map();
    this.parentSettingsRecords = new Map();
    this.achievementRecords = [];
    this.invitationCodes = new Map();
    this.quizResults = [];
    this.gameSessions = [];
    
    this.currentUserId = 1;
    this.currentProgressId = 1;
    this.currentSettingsId = 1;
    this.currentAchievementId = 1;
    this.currentInvitationId = 1;
    this.currentQuizResultId = 1;
    this.currentGameSessionId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24 hours
    });
    
    // Create an admin invitation code
    this.createInvitationCode({
      code: "SRLS-ADMIN-CODE",
      expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000) // 1 year from now
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id, isAdmin: false, deviceFingerprint: null, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserPin(userId: number, newPin: string): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, parentPin: newPin };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async updateUserDevice(userId: number, deviceFingerprint: string): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, deviceFingerprint };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  // Progress methods
  async getProgress(userId: number): Promise<Progress | undefined> {
    return Array.from(this.progressRecords.values()).find(
      (progress) => progress.userId === userId
    );
  }

  async createProgress(insertProgress: InsertProgress): Promise<Progress> {
    const id = this.currentProgressId++;
    const progress: Progress = { 
      ...insertProgress, 
      id, 
      completedLevels: insertProgress.completedLevels || [], 
      updatedAt: new Date() 
    };
    this.progressRecords.set(id, progress);
    return progress;
  }
  
  async updateProgress(userId: number, progressUpdate: Partial<Progress>): Promise<Progress> {
    const existingProgress = await this.getProgress(userId);
    if (!existingProgress) {
      throw new Error("Progress not found for user");
    }
    
    const updatedProgress = { 
      ...existingProgress, 
      ...progressUpdate, 
      updatedAt: new Date() 
    };
    this.progressRecords.set(existingProgress.id, updatedProgress);
    return updatedProgress;
  }

  // Parent settings methods
  async getParentSettings(userId: number): Promise<ParentSettings | undefined> {
    return Array.from(this.parentSettingsRecords.values()).find(
      (settings) => settings.userId === userId
    );
  }

  async createParentSettings(insertSettings: InsertParentSettings): Promise<ParentSettings> {
    const id = this.currentSettingsId++;
    const settings: ParentSettings = { 
      ...insertSettings, 
      id, 
      availableDays: insertSettings.availableDays || ["1", "2", "3", "4", "5"], 
      updatedAt: new Date() 
    };
    this.parentSettingsRecords.set(id, settings);
    return settings;
  }
  
  async updateParentSettings(userId: number, settingsUpdate: Partial<ParentSettings>): Promise<ParentSettings> {
    const existingSettings = await this.getParentSettings(userId);
    if (!existingSettings) {
      throw new Error("Settings not found for user");
    }
    
    const updatedSettings = { 
      ...existingSettings, 
      ...settingsUpdate, 
      updatedAt: new Date() 
    };
    this.parentSettingsRecords.set(existingSettings.id, updatedSettings);
    return updatedSettings;
  }

  // Achievement methods
  async getAchievements(userId: number): Promise<Achievement[]> {
    return this.achievementRecords.filter(
      (achievement) => achievement.userId === userId
    );
  }

  async createAchievement(insertAchievement: InsertAchievement): Promise<Achievement> {
    const id = this.currentAchievementId++;
    const achievement: Achievement = { 
      ...insertAchievement, 
      id, 
      earnedAt: new Date() 
    };
    this.achievementRecords.push(achievement);
    return achievement;
  }

  // Invitation code methods
  async getInvitationCode(code: string): Promise<InvitationCode | undefined> {
    return this.invitationCodes.get(code);
  }

  async createInvitationCode(insertCode: InsertInvitationCode): Promise<InvitationCode> {
    const id = this.currentInvitationId++;
    const invitationCode: InvitationCode = { 
      ...insertCode, 
      id, 
      isUsed: false, 
      usedBy: null, 
      createdAt: new Date() 
    };
    this.invitationCodes.set(insertCode.code, invitationCode);
    return invitationCode;
  }
  
  async useInvitationCode(code: string, userId: number): Promise<InvitationCode> {
    const invitationCode = await this.getInvitationCode(code);
    if (!invitationCode) {
      throw new Error("Invalid invitation code");
    }
    
    if (invitationCode.isUsed) {
      throw new Error("Invitation code already used");
    }
    
    if (invitationCode.expiresAt && invitationCode.expiresAt < new Date()) {
      throw new Error("Invitation code has expired");
    }
    
    const updatedCode = { 
      ...invitationCode, 
      isUsed: true, 
      usedBy: userId 
    };
    this.invitationCodes.set(code, updatedCode);
    return updatedCode;
  }

  // Quiz results methods
  async getQuizResults(userId: number, levelId?: number): Promise<QuizResult[]> {
    return this.quizResults.filter(
      (result) => result.userId === userId && (levelId ? result.levelId === levelId : true)
    );
  }

  async createQuizResult(insertResult: InsertQuizResult): Promise<QuizResult> {
    const id = this.currentQuizResultId++;
    const result: QuizResult = { 
      ...insertResult, 
      id, 
      completedAt: new Date() 
    };
    this.quizResults.push(result);
    return result;
  }

  // Game session methods
  async getGameSessions(userId: number): Promise<GameSession[]> {
    return this.gameSessions.filter(
      (session) => session.userId === userId
    );
  }
  
  async getActiveGameSession(userId: number): Promise<GameSession | undefined> {
    return this.gameSessions.find(
      (session) => session.userId === userId && !session.isCompleted
    );
  }

  async createGameSession(insertSession: InsertGameSession): Promise<GameSession> {
    const id = this.currentGameSessionId++;
    const session: GameSession = { 
      ...insertSession, 
      id, 
      startTime: new Date(),
      endTime: null,
      timeSpent: 0,
      gamesCompleted: insertSession.gamesCompleted || [],
      isCompleted: false
    };
    this.gameSessions.push(session);
    return session;
  }
  
  async updateGameSession(sessionId: number, data: Partial<GameSession>): Promise<GameSession> {
    const sessionIndex = this.gameSessions.findIndex(s => s.id === sessionId);
    if (sessionIndex === -1) {
      throw new Error("Game session not found");
    }
    
    const updatedSession = { 
      ...this.gameSessions[sessionIndex], 
      ...data 
    };
    this.gameSessions[sessionIndex] = updatedSession;
    return updatedSession;
  }
  
  async completeGameSession(sessionId: number, timeSpent: number): Promise<GameSession> {
    const sessionIndex = this.gameSessions.findIndex(s => s.id === sessionId);
    if (sessionIndex === -1) {
      throw new Error("Game session not found");
    }
    
    const updatedSession = { 
      ...this.gameSessions[sessionIndex], 
      endTime: new Date(),
      timeSpent,
      isCompleted: true 
    };
    this.gameSessions[sessionIndex] = updatedSession;
    return updatedSession;
  }
}

export class DatabaseStorage implements IStorage {
  sessionStore: SessionStore;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
    
    // Create an admin invitation code if it doesn't exist
    this.getInvitationCode("SRLS-ADMIN-CODE").then((code) => {
      if (!code) {
        this.createInvitationCode({
          code: "SRLS-ADMIN-CODE",
          expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year from now
        });
      }
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values({
      ...insertUser,
      isAdmin: false,
      deviceFingerprint: null,
      createdAt: new Date(),
    }).returning();
    return result[0];
  }
  
  async updateUserPin(userId: number, newPin: string): Promise<User> {
    const result = await db.update(users)
      .set({ parentPin: newPin })
      .where(eq(users.id, userId))
      .returning();
      
    if (!result[0]) throw new Error("User not found");
    return result[0];
  }
  
  async updateUserDevice(userId: number, deviceFingerprint: string): Promise<User> {
    const result = await db.update(users)
      .set({ deviceFingerprint })
      .where(eq(users.id, userId))
      .returning();
      
    if (!result[0]) throw new Error("User not found");
    return result[0];
  }

  // Progress methods
  async getProgress(userId: number): Promise<Progress | undefined> {
    const result = await db.select()
      .from(progress)
      .where(eq(progress.userId, userId));
    return result[0];
  }

  async createProgress(insertProgress: InsertProgress): Promise<Progress> {
    const result = await db.insert(progress).values({
      ...insertProgress,
      completedLevels: insertProgress.completedLevels || [],
      updatedAt: new Date(),
    }).returning();
    return result[0];
  }
  
  async updateProgress(userId: number, progressUpdate: Partial<Progress>): Promise<Progress> {
    const existingProgress = await this.getProgress(userId);
    if (!existingProgress) {
      throw new Error("Progress not found for user");
    }
    
    const result = await db.update(progress)
      .set({
        ...progressUpdate,
        updatedAt: new Date(),
      })
      .where(eq(progress.userId, userId))
      .returning();
      
    return result[0];
  }

  // Parent settings methods
  async getParentSettings(userId: number): Promise<ParentSettings | undefined> {
    const result = await db.select()
      .from(parentSettings)
      .where(eq(parentSettings.userId, userId));
    return result[0];
  }

  async createParentSettings(insertSettings: InsertParentSettings): Promise<ParentSettings> {
    const result = await db.insert(parentSettings).values({
      ...insertSettings,
      availableDays: insertSettings.availableDays || ["1", "2", "3", "4", "5"],
      updatedAt: new Date(),
    }).returning();
    return result[0];
  }
  
  async updateParentSettings(userId: number, settingsUpdate: Partial<ParentSettings>): Promise<ParentSettings> {
    const existingSettings = await this.getParentSettings(userId);
    if (!existingSettings) {
      throw new Error("Settings not found for user");
    }
    
    const result = await db.update(parentSettings)
      .set({
        ...settingsUpdate,
        updatedAt: new Date(),
      })
      .where(eq(parentSettings.userId, userId))
      .returning();
      
    return result[0];
  }

  // Achievement methods
  async getAchievements(userId: number): Promise<Achievement[]> {
    return db.select()
      .from(achievements)
      .where(eq(achievements.userId, userId));
  }

  async createAchievement(insertAchievement: InsertAchievement): Promise<Achievement> {
    const result = await db.insert(achievements).values({
      ...insertAchievement,
      earnedAt: new Date(),
    }).returning();
    return result[0];
  }

  // Invitation code methods
  async getInvitationCode(code: string): Promise<InvitationCode | undefined> {
    const result = await db.select()
      .from(invitationCodes)
      .where(eq(invitationCodes.code, code));
    return result[0];
  }

  async createInvitationCode(insertCode: InsertInvitationCode): Promise<InvitationCode> {
    const result = await db.insert(invitationCodes).values({
      ...insertCode,
      isUsed: false,
      usedBy: null,
      createdAt: new Date(),
    }).returning();
    return result[0];
  }
  
  async useInvitationCode(code: string, userId: number): Promise<InvitationCode> {
    const invitationCode = await this.getInvitationCode(code);
    if (!invitationCode) {
      throw new Error("Invalid invitation code");
    }
    
    if (invitationCode.isUsed) {
      throw new Error("Invitation code already used");
    }
    
    if (invitationCode.expiresAt && invitationCode.expiresAt < new Date()) {
      throw new Error("Invitation code has expired");
    }
    
    const result = await db.update(invitationCodes)
      .set({
        isUsed: true,
        usedBy: userId,
      })
      .where(eq(invitationCodes.code, code))
      .returning();
      
    return result[0];
  }

  // Quiz results methods
  async getQuizResults(userId: number, levelId?: number): Promise<QuizResult[]> {
    let query = db.select()
      .from(quizResults)
      .where(eq(quizResults.userId, userId));
      
    if (levelId) {
      query = query.where(eq(quizResults.levelId, levelId));
    }
    
    return query;
  }

  async createQuizResult(insertResult: InsertQuizResult): Promise<QuizResult> {
    const result = await db.insert(quizResults).values({
      ...insertResult,
      completedAt: new Date(),
    }).returning();
    return result[0];
  }

  // Game session methods
  async getGameSessions(userId: number): Promise<GameSession[]> {
    return db.select()
      .from(gameSessions)
      .where(eq(gameSessions.userId, userId))
      .orderBy(desc(gameSessions.startTime));
  }
  
  async getActiveGameSession(userId: number): Promise<GameSession | undefined> {
    const result = await db.select()
      .from(gameSessions)
      .where(and(
        eq(gameSessions.userId, userId),
        eq(gameSessions.isCompleted, false)
      ));
    return result[0];
  }

  async createGameSession(insertSession: InsertGameSession): Promise<GameSession> {
    const result = await db.insert(gameSessions).values({
      ...insertSession,
      startTime: new Date(),
      endTime: null,
      timeSpent: 0,
      gamesCompleted: insertSession.gamesCompleted || [],
      isCompleted: false,
    }).returning();
    return result[0];
  }
  
  async updateGameSession(sessionId: number, data: Partial<GameSession>): Promise<GameSession> {
    const result = await db.update(gameSessions)
      .set(data)
      .where(eq(gameSessions.id, sessionId))
      .returning();
      
    if (!result[0]) {
      throw new Error("Game session not found");
    }
    
    return result[0];
  }
  
  async completeGameSession(sessionId: number, timeSpent: number): Promise<GameSession> {
    const result = await db.update(gameSessions)
      .set({
        endTime: new Date(),
        timeSpent,
        isCompleted: true,
      })
      .where(eq(gameSessions.id, sessionId))
      .returning();
      
    if (!result[0]) {
      throw new Error("Game session not found");
    }
    
    return result[0];
  }
}

// Use DatabaseStorage instead of MemStorage
export const storage = new DatabaseStorage();
