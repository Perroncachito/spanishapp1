import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  childName: text("child_name").notNull(),
  parentEmail: text("parent_email").notNull(),
  parentPin: text("parent_pin").notNull(),
  deviceFingerprint: text("device_fingerprint"),
  isAdmin: boolean("is_admin").default(false),
  invitationCode: text("invitation_code").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  childName: true,
  parentEmail: true,
  parentPin: true,
  invitationCode: true,
});

// Progress tracking schema
export const progress = pgTable("progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  currentLevel: integer("current_level").default(1),
  completedLevels: text("completed_levels").array(),
  totalTimeSpent: integer("total_time_spent").default(0), // in minutes
  lastPlayed: timestamp("last_played"),
  lastGameType: text("last_game_type"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertProgressSchema = createInsertSchema(progress).pick({
  userId: true,
  currentLevel: true,
  completedLevels: true,
  totalTimeSpent: true,
  lastPlayed: true,
  lastGameType: true,
});

// Parent settings schema
export const parentSettings = pgTable("parent_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique(),
  sessionDuration: integer("session_duration").default(30), // in minutes
  dailyTimeLimit: integer("daily_time_limit").default(60), // in minutes
  availableDays: text("available_days").array().default(["1", "2", "3", "4", "5"]), // 0 = Sunday, 1 = Monday, etc.
  startTime: text("start_time").default("15:00"), // 24-hour format
  endTime: text("end_time").default("18:00"), // 24-hour format
  deviceRestriction: boolean("device_restriction").default(true),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertParentSettingsSchema = createInsertSchema(parentSettings).pick({
  userId: true,
  sessionDuration: true,
  dailyTimeLimit: true,
  availableDays: true,
  startTime: true,
  endTime: true,
  deviceRestriction: true,
});

// Achievements schema
export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  achievementType: text("achievement_type").notNull(), // e.g. "first_level", "daily_streak", etc.
  earnedAt: timestamp("earned_at").defaultNow(),
  metadata: jsonb("metadata"),
});

export const insertAchievementSchema = createInsertSchema(achievements).pick({
  userId: true,
  achievementType: true,
  metadata: true,
});

// Invitation codes schema
export const invitationCodes = pgTable("invitation_codes", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  isUsed: boolean("is_used").default(false),
  usedBy: integer("used_by"),
  createdAt: timestamp("created_at").defaultNow(),
  expiresAt: timestamp("expires_at"),
});

export const insertInvitationCodeSchema = createInsertSchema(invitationCodes).pick({
  code: true,
  expiresAt: true,
});

// Quiz results schema
export const quizResults = pgTable("quiz_results", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  levelId: integer("level_id").notNull(),
  score: integer("score").notNull(),
  totalQuestions: integer("total_questions").notNull(),
  isPassed: boolean("is_passed").default(false),
  completedAt: timestamp("completed_at").defaultNow(),
});

export const insertQuizResultSchema = createInsertSchema(quizResults).pick({
  userId: true,
  levelId: true,
  score: true,
  totalQuestions: true,
  isPassed: true,
});

// Game session schema
export const gameSessions = pgTable("game_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  levelId: integer("level_id").notNull(),
  startTime: timestamp("start_time").defaultNow(),
  endTime: timestamp("end_time"),
  timeSpent: integer("time_spent"), // in seconds
  gamesCompleted: jsonb("games_completed").array(),
  isCompleted: boolean("is_completed").default(false),
});

export const insertGameSessionSchema = createInsertSchema(gameSessions).pick({
  userId: true,
  levelId: true,
  gamesCompleted: true,
});

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Progress = typeof progress.$inferSelect;
export type InsertProgress = z.infer<typeof insertProgressSchema>;

export type ParentSettings = typeof parentSettings.$inferSelect;
export type InsertParentSettings = z.infer<typeof insertParentSettingsSchema>;

export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = z.infer<typeof insertAchievementSchema>;

export type InvitationCode = typeof invitationCodes.$inferSelect;
export type InsertInvitationCode = z.infer<typeof insertInvitationCodeSchema>;

export type QuizResult = typeof quizResults.$inferSelect;
export type InsertQuizResult = z.infer<typeof insertQuizResultSchema>;

export type GameSession = typeof gameSessions.$inferSelect;
export type InsertGameSession = z.infer<typeof insertGameSessionSchema>;
