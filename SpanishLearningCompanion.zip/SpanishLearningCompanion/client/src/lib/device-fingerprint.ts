export const generateDeviceFingerprint = async (): Promise<string> => {
  try {
    // Collect browser and navigator information
    const screenInfo = `${window.screen.width}x${window.screen.height}x${window.screen.colorDepth}`;
    const userAgent = navigator.userAgent;
    const language = navigator.language;
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const platform = navigator.platform;
    
    // Check for available features
    const touchSupport = "ontouchstart" in window;
    const cookiesEnabled = navigator.cookieEnabled;
    
    // Get canvas fingerprint
    const canvasFingerprint = getCanvasFingerprint();
    
    // Combine all data points
    const fingerprintData = [
      screenInfo,
      userAgent,
      language,
      timezone,
      platform,
      touchSupport,
      cookiesEnabled,
      canvasFingerprint,
      getPluginsInfo(),
      getHardwareConcurrency(),
      getDeviceMemory(),
      getAudioFingerprint()
    ].join('|');
    
    // Create a hash of the fingerprint data
    // In a real implementation, you'd use a cryptographic hash function
    // For this demo, we'll use a simple hash
    return simpleHash(fingerprintData);
  } catch (error) {
    console.error("Error generating device fingerprint:", error);
    // Return a fallback fingerprint
    return simpleHash(navigator.userAgent);
  }
};

// Helper function to get canvas fingerprint
const getCanvasFingerprint = (): string => {
  try {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return "";
    
    // Set canvas dimensions
    canvas.width = 200;
    canvas.height = 50;
    
    // Fill with a specific text
    ctx.textBaseline = "top";
    ctx.font = "14px 'Arial'";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "#f60";
    ctx.fillRect(125, 1, 62, 20);
    ctx.fillStyle = "#069";
    ctx.fillText("SRLS Spanish", 2, 15);
    ctx.fillStyle = "rgba(102, 204, 0, 0.7)";
    ctx.fillText("Fingerprint", 4, 17);
    
    // Get DataURL and extract unique part
    return canvas.toDataURL().slice(-50);
  } catch (e) {
    return "";
  }
};

// Helper function to get plugins info
const getPluginsInfo = (): string => {
  try {
    if (!navigator.plugins || navigator.plugins.length === 0) return "";
    
    return Array.from(navigator.plugins)
      .map(p => p.name)
      .join(",");
  } catch (e) {
    return "";
  }
};

// Helper function to get hardware concurrency
const getHardwareConcurrency = (): number => {
  try {
    return navigator.hardwareConcurrency || 0;
  } catch (e) {
    return 0;
  }
};

// Helper function to get device memory
const getDeviceMemory = (): number => {
  try {
    // @ts-ignore: Device memory is not in the standard navigator interface
    return navigator.deviceMemory || 0;
  } catch (e) {
    return 0;
  }
};

// Helper function to get audio fingerprint
const getAudioFingerprint = (): string => {
  try {
    const audioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (!audioContext) return "";
    
    const context = new audioContext();
    const oscillator = context.createOscillator();
    const analyser = context.createAnalyser();
    
    oscillator.connect(analyser);
    oscillator.type = "triangle";
    oscillator.frequency.setValueAtTime(10000, context.currentTime);
    
    // Generate a simple value based on the audio capabilities
    return `${context.sampleRate}-${analyser.fftSize}`;
  } catch (e) {
    return "";
  }
};

// Simple hash function for demo purposes only
// In a real application, you'd use a cryptographic hash function
const simpleHash = (str: string): string => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  
  // Convert to a hexadecimal string and ensure positive
  let hexHash = (hash >>> 0).toString(16);
  
  // Ensure it's long enough for a decent fingerprint
  while (hexHash.length < 12) {
    hexHash = "0" + hexHash;
  }
  
  // Return formatted fingerprint
  return `SRLS-${hexHash.substring(0, 8)}-${hexHash.substring(8, 16)}`;
};

export default generateDeviceFingerprint;
