import GreetingMatch from "@/components/games/greeting-match";
import MemoryCards from "@/components/games/memory-cards";
import WordSeeker from "@/components/games/word-seeker";
import ListenSelect from "@/components/games/listen-select";
import DialogueBuilder from "@/components/games/dialogue-builder";
import TimeMatch from "@/components/games/time-match";

// Define game types
export type GameType = 
  | "greeting-match" 
  | "memory-cards" 
  | "word-seeker" 
  | "listen-select" 
  | "dialogue-builder" 
  | "time-match";

export type GameComponentProps = {
  levelId: number;
  onComplete: () => void;
  difficulty?: "easy" | "normal";
};

// Map game index to game type
export const getGameType = (index: number): GameType => {
  const gameTypes: GameType[] = [
    "greeting-match",
    "memory-cards", 
    "word-seeker",
    "listen-select",
    "dialogue-builder",
    "time-match"
  ];
  
  // Ensure index is within bounds
  const normalizedIndex = index % gameTypes.length;
  return gameTypes[normalizedIndex];
};

// Map game index to component
export const getGameComponent = (index: number) => {
  const gameType = getGameType(index);
  
  // Return the corresponding component based on game type
  switch (gameType) {
    case "greeting-match":
      return GreetingMatch;
    case "memory-cards":
      return MemoryCards;
    case "word-seeker":
      return WordSeeker;
    case "listen-select":
      return ListenSelect;
    case "dialogue-builder":
      return DialogueBuilder;
    case "time-match":
      return TimeMatch;
    default:
      // Default to memory cards if somehow an invalid type is provided
      return MemoryCards;
  }
};

// Get game name from type
export const getGameName = (gameType: GameType): string => {
  switch (gameType) {
    case "greeting-match":
      return "Greeting Match";
    case "memory-cards":
      return "Memory Cards";
    case "word-seeker":
      return "Word Seeker";
    case "listen-select":
      return "Listen and Select";
    case "dialogue-builder":
      return "Dialogue Builder";
    case "time-match":
      return "Time Match";
    default:
      return "Game";
  }
};

// Get a random game type (useful for rotating games)
export const getRandomGameType = (): GameType => {
  const gameTypes: GameType[] = [
    "greeting-match",
    "memory-cards", 
    "word-seeker",
    "listen-select",
    "dialogue-builder",
    "time-match"
  ];
  
  const randomIndex = Math.floor(Math.random() * gameTypes.length);
  return gameTypes[randomIndex];
};
