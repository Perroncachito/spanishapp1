// Types for vocabulary
export type VocabularyWord = {
  spanish: string;
  english: string;
  type: string;
  contextExample?: string;
  audioUrl?: string;
  imageUrl?: string;
  contextual?: boolean;
};

// Import images
// Using dynamic imports instead of static imports to ensure the SVG files are properly loaded
const greetingImg = new URL('../assets/vocabulary/greeting.svg', import.meta.url).href;
const buenosDiasImg = new URL('../assets/vocabulary/buenos-dias.svg', import.meta.url).href;
const goodAfternoonImg = new URL('../assets/vocabulary/good-afternoon.svg', import.meta.url).href;
const goodEveningImg = new URL('../assets/vocabulary/good-evening.svg', import.meta.url).href;
const thankYouImg = new URL('../assets/vocabulary/thank-you.svg', import.meta.url).href;
const pleaseImg = new URL('../assets/vocabulary/please.svg', import.meta.url).href;
const howAreYouImg = new URL('../assets/vocabulary/how-are-you.svg', import.meta.url).href;

// Level 1: Basic Greetings - 25 vocabulary items
const level1Vocabulary: VocabularyWord[] = [
  {
    spanish: "¡Hola!",
    english: "Hello!",
    type: "greeting",
    contextExample: "When greeting someone at any time of day",
    imageUrl: greetingImg
  },
  {
    spanish: "Buenos días",
    english: "Good morning",
    type: "greeting",
    contextExample: "When greeting someone in the morning",
    imageUrl: buenosDiasImg
  },
  {
    spanish: "Buenas tardes",
    english: "Good afternoon",
    type: "greeting",
    contextExample: "When greeting someone in the afternoon",
    imageUrl: goodAfternoonImg
  },
  {
    spanish: "Buenas noches",
    english: "Good evening/night",
    type: "greeting",
    contextExample: "When greeting someone in the evening or saying goodnight",
    imageUrl: goodEveningImg
  },
  {
    spanish: "¿Cómo estás?",
    english: "How are you?",
    type: "greeting",
    contextExample: "When asking someone informally how they are",
    contextual: true,
    imageUrl: howAreYouImg
  },
  {
    spanish: "¿Cómo está usted?",
    english: "How are you? (formal)",
    type: "greeting",
    contextExample: "When asking someone formally how they are",
    contextual: true
  },
  {
    spanish: "Estoy bien, gracias",
    english: "I'm fine, thank you",
    type: "response",
    contextExample: "When someone asks how you are"
  },
  {
    spanish: "Muy bien",
    english: "Very good",
    type: "response",
    contextExample: "When responding to someone asking how you are"
  },
  {
    spanish: "¿Y tú?",
    english: "And you?",
    type: "question",
    contextExample: "When asking how someone is after they asked you",
    contextual: true
  },
  {
    spanish: "Me llamo...",
    english: "My name is...",
    type: "phrase",
    contextExample: "When introducing yourself"
  },
  {
    spanish: "¿Cómo te llamas?",
    english: "What's your name?",
    type: "question",
    contextExample: "When asking someone their name",
    contextual: true
  },
  {
    spanish: "Mucho gusto",
    english: "Nice to meet you",
    type: "greeting",
    contextExample: "When meeting someone for the first time"
  },
  {
    spanish: "Adiós",
    english: "Goodbye",
    type: "farewell",
    contextExample: "When saying goodbye"
  },
  {
    spanish: "Hasta luego",
    english: "See you later",
    type: "farewell",
    contextExample: "When saying goodbye and expecting to see the person later"
  },
  {
    spanish: "Hasta mañana",
    english: "See you tomorrow",
    type: "farewell",
    contextExample: "When saying goodbye and expecting to see the person tomorrow"
  },
  // Adding 10 more vocabulary items
  {
    spanish: "Gracias",
    english: "Thank you",
    type: "phrase",
    contextExample: "When expressing gratitude",
    imageUrl: thankYouImg
  },
  {
    spanish: "Por favor",
    english: "Please",
    type: "phrase",
    contextExample: "When asking for something politely",
    imageUrl: pleaseImg
  },
  {
    spanish: "De nada",
    english: "You're welcome",
    type: "response",
    contextExample: "When responding to someone who thanked you"
  },
  {
    spanish: "Sí",
    english: "Yes",
    type: "response",
    contextExample: "When agreeing or confirming something"
  },
  {
    spanish: "No",
    english: "No",
    type: "response",
    contextExample: "When disagreeing or refusing something"
  },
  {
    spanish: "Disculpe",
    english: "Excuse me",
    type: "phrase",
    contextExample: "When getting someone's attention formally"
  },
  {
    spanish: "Perdón",
    english: "Sorry",
    type: "phrase",
    contextExample: "When apologizing"
  },
  {
    spanish: "Hasta pronto",
    english: "See you soon",
    type: "farewell",
    contextExample: "When saying goodbye and expecting to see the person soon"
  },
  {
    spanish: "Encantado/a",
    english: "Pleased to meet you",
    type: "greeting",
    contextExample: "When expressing pleasure at meeting someone"
  },
  {
    spanish: "Bienvenido/a",
    english: "Welcome",
    type: "greeting",
    contextExample: "When greeting someone who has arrived"
  }
];

// Level 2: Formal vs. Informal Greetings - 25 vocabulary items
const level2Vocabulary: VocabularyWord[] = [
  {
    spanish: "Señor",
    english: "Mr./Sir",
    type: "noun",
    contextExample: "When addressing a man formally"
  },
  {
    spanish: "Señora",
    english: "Mrs./Madam",
    type: "noun",
    contextExample: "When addressing a married woman formally"
  },
  {
    spanish: "Señorita",
    english: "Miss",
    type: "noun",
    contextExample: "When addressing a young or unmarried woman formally"
  },
  {
    spanish: "Usted",
    english: "You (formal)",
    type: "pronoun",
    contextExample: "When addressing someone formally"
  },
  {
    spanish: "Tú",
    english: "You (informal)",
    type: "pronoun",
    contextExample: "When addressing someone informally"
  },
  {
    spanish: "Con permiso",
    english: "Excuse me (to pass)",
    type: "phrase",
    contextExample: "When trying to pass by someone",
    contextual: true
  },
  {
    spanish: "Disculpe",
    english: "Excuse me (formal)",
    type: "phrase",
    contextExample: "When interrupting someone formally",
    contextual: true
  },
  {
    spanish: "Disculpa",
    english: "Excuse me (informal)",
    type: "phrase",
    contextExample: "When interrupting someone informally",
    contextual: true
  },
  {
    spanish: "Por favor",
    english: "Please",
    type: "phrase",
    contextExample: "When asking for something politely",
    imageUrl: pleaseImg
  },
  {
    spanish: "Gracias",
    english: "Thank you",
    type: "phrase",
    contextExample: "When expressing gratitude",
    imageUrl: thankYouImg
  },
  {
    spanish: "Muchas gracias",
    english: "Thank you very much",
    type: "phrase",
    contextExample: "When expressing stronger gratitude"
  },
  {
    spanish: "De nada",
    english: "You're welcome",
    type: "response",
    contextExample: "When responding to someone thanking you"
  },
  {
    spanish: "Encantado/a",
    english: "Delighted (to meet you)",
    type: "greeting",
    contextExample: "When expressing pleasure in meeting someone",
    contextual: true
  },
  {
    spanish: "Bienvenido/a",
    english: "Welcome",
    type: "greeting",
    contextExample: "When welcoming someone",
    contextual: true
  },
  {
    spanish: "Igualmente",
    english: "Likewise",
    type: "response",
    contextExample: "When responding to a nice-to-meet-you or similar pleasantry"
  },
  {
    spanish: "Buenos días, señor",
    english: "Good morning, sir",
    type: "greeting",
    contextExample: "Formal morning greeting to a man",
    contextual: true
  },
  {
    spanish: "¿Cómo le va?",
    english: "How's it going? (formal)",
    type: "greeting",
    contextExample: "Formal way to ask how someone is doing",
    contextual: true
  },
  {
    spanish: "¿Qué tal?",
    english: "How's it going? (informal)",
    type: "greeting",
    contextExample: "Informal way to ask how someone is doing",
    contextual: true
  },
  // Adding 7 more vocabulary items
  {
    spanish: "Ustedes",
    english: "You all (formal)",
    type: "pronoun",
    contextExample: "When addressing multiple people formally"
  },
  {
    spanish: "Vosotros/as",
    english: "You all (informal, Spain)",
    type: "pronoun",
    contextExample: "When addressing multiple people informally in Spain"
  },
  {
    spanish: "A sus órdenes",
    english: "At your service",
    type: "phrase",
    contextExample: "Very formal way to offer assistance"
  },
  {
    spanish: "Le agradezco",
    english: "I thank you (formal)",
    type: "phrase",
    contextExample: "Formal expression of gratitude"
  },
  {
    spanish: "Te agradezco",
    english: "I thank you (informal)",
    type: "phrase",
    contextExample: "Informal expression of gratitude"
  },
  {
    spanish: "Saludos cordiales",
    english: "Kind regards",
    type: "phrase",
    contextExample: "Formal closing in written communication"
  },
  {
    spanish: "Un abrazo",
    english: "A hug",
    type: "phrase",
    contextExample: "Informal closing in written communication to friends or family"
  }
];

// Level 3: Introductions & Personal Information - 25 vocabulary items
const level3Vocabulary: VocabularyWord[] = [
  {
    spanish: "Soy de...",
    english: "I'm from...",
    type: "phrase",
    contextExample: "When telling someone where you're from"
  },
  {
    spanish: "¿De dónde eres?",
    english: "Where are you from?",
    type: "question",
    contextExample: "When asking someone where they're from",
    contextual: true
  },
  {
    spanish: "Vivo en...",
    english: "I live in...",
    type: "phrase",
    contextExample: "When telling someone where you live"
  },
  {
    spanish: "¿Dónde vives?",
    english: "Where do you live?",
    type: "question",
    contextExample: "When asking someone where they live",
    contextual: true
  },
  {
    spanish: "Tengo ... años",
    english: "I am ... years old",
    type: "phrase",
    contextExample: "When telling someone your age"
  },
  {
    spanish: "¿Cuántos años tienes?",
    english: "How old are you?",
    type: "question",
    contextExample: "When asking someone their age",
    contextual: true
  },
  {
    spanish: "Mi cumpleaños es...",
    english: "My birthday is...",
    type: "phrase",
    contextExample: "When telling someone your birthday"
  },
  {
    spanish: "¿Cuándo es tu cumpleaños?",
    english: "When is your birthday?",
    type: "question",
    contextExample: "When asking someone about their birthday",
    contextual: true
  },
  {
    spanish: "Mi número de teléfono es...",
    english: "My phone number is...",
    type: "phrase",
    contextExample: "When giving someone your phone number"
  },
  {
    spanish: "¿Cuál es tu número de teléfono?",
    english: "What's your phone number?",
    type: "question",
    contextExample: "When asking someone for their phone number",
    contextual: true
  },
  {
    spanish: "Mi correo electrónico es...",
    english: "My email is...",
    type: "phrase",
    contextExample: "When giving someone your email address"
  },
  {
    spanish: "¿Cuál es tu correo electrónico?",
    english: "What's your email?",
    type: "question",
    contextExample: "When asking someone for their email address",
    contextual: true
  },
  {
    spanish: "Soy estudiante",
    english: "I am a student",
    type: "phrase",
    contextExample: "When telling someone you're a student"
  },
  {
    spanish: "¿A qué te dedicas?",
    english: "What do you do? (occupation)",
    type: "question",
    contextExample: "When asking someone about their occupation",
    contextual: true
  },
  {
    spanish: "Trabajo en...",
    english: "I work at...",
    type: "phrase",
    contextExample: "When telling someone where you work"
  },
  {
    spanish: "Estudio...",
    english: "I study...",
    type: "phrase",
    contextExample: "When telling someone what you study"
  },
  {
    spanish: "¿Qué estudias?",
    english: "What do you study?",
    type: "question",
    contextExample: "When asking someone what they study",
    contextual: true
  },
  {
    spanish: "Hablo español",
    english: "I speak Spanish",
    type: "phrase",
    contextExample: "When telling someone you speak Spanish"
  },
  {
    spanish: "¿Hablas inglés?",
    english: "Do you speak English?",
    type: "question",
    contextExample: "When asking someone if they speak English",
    contextual: true
  },
  {
    spanish: "Un poco",
    english: "A little",
    type: "phrase",
    contextExample: "When saying you speak a little of a language"
  },
  // Adding 5 more vocabulary items
  {
    spanish: "Soy casado/a",
    english: "I am married",
    type: "phrase",
    contextExample: "When telling someone your marital status"
  },
  {
    spanish: "Soy soltero/a",
    english: "I am single",
    type: "phrase",
    contextExample: "When telling someone you're not married"
  },
  {
    spanish: "Tengo hermanos",
    english: "I have siblings",
    type: "phrase",
    contextExample: "When telling someone about your family"
  },
  {
    spanish: "¿Tienes hermanos?",
    english: "Do you have siblings?",
    type: "question",
    contextExample: "When asking someone about their family",
    contextual: true
  },
  {
    spanish: "Mi dirección es...",
    english: "My address is...",
    type: "phrase",
    contextExample: "When giving someone your address"
  }
];

// Level 4: Conversation Basics - 25 vocabulary items
const level4Vocabulary: VocabularyWord[] = [
  {
    spanish: "¿Qué?",
    english: "What?",
    type: "question",
    contextExample: "When asking someone to repeat or clarify"
  },
  {
    spanish: "¿Cómo?",
    english: "How?",
    type: "question",
    contextExample: "When asking how something is done"
  },
  {
    spanish: "¿Cuándo?",
    english: "When?",
    type: "question",
    contextExample: "When asking about time"
  },
  {
    spanish: "¿Dónde?",
    english: "Where?",
    type: "question",
    contextExample: "When asking about location"
  },
  {
    spanish: "¿Por qué?",
    english: "Why?",
    type: "question",
    contextExample: "When asking for a reason"
  },
  {
    spanish: "¿Quién?",
    english: "Who?",
    type: "question",
    contextExample: "When asking about a person"
  },
  {
    spanish: "¿Cuál?",
    english: "Which?",
    type: "question",
    contextExample: "When asking for a choice"
  },
  {
    spanish: "¿Cuánto?",
    english: "How much?",
    type: "question",
    contextExample: "When asking about quantity"
  },
  {
    spanish: "¿Puedes repetir?",
    english: "Can you repeat?",
    type: "phrase",
    contextExample: "When asking someone to repeat"
  },
  {
    spanish: "No entiendo",
    english: "I don't understand",
    type: "phrase",
    contextExample: "When you don't understand something"
  },
  {
    spanish: "Entiendo",
    english: "I understand",
    type: "phrase",
    contextExample: "When you understand something"
  },
  {
    spanish: "Despacio, por favor",
    english: "Slowly, please",
    type: "phrase",
    contextExample: "When asking someone to speak more slowly"
  },
  {
    spanish: "Sí",
    english: "Yes",
    type: "response",
    contextExample: "When agreeing"
  },
  {
    spanish: "No",
    english: "No",
    type: "response",
    contextExample: "When disagreeing"
  },
  {
    spanish: "Tal vez",
    english: "Maybe",
    type: "response",
    contextExample: "When expressing uncertainty"
  },
  // Adding 10 more vocabulary items
  {
    spanish: "Por supuesto",
    english: "Of course",
    type: "response",
    contextExample: "When agreeing strongly"
  },
  {
    spanish: "De ninguna manera",
    english: "No way",
    type: "response",
    contextExample: "When strongly disagreeing"
  },
  {
    spanish: "Un momento",
    english: "One moment",
    type: "phrase",
    contextExample: "When asking someone to wait briefly"
  },
  {
    spanish: "Más despacio",
    english: "More slowly",
    type: "phrase",
    contextExample: "When asking someone to speak more slowly"
  },
  {
    spanish: "Repite, por favor",
    english: "Repeat, please",
    type: "phrase",
    contextExample: "When asking someone to repeat what they said"
  },
  {
    spanish: "No sé",
    english: "I don't know",
    type: "response",
    contextExample: "When you don't have the information"
  },
  {
    spanish: "Lo siento",
    english: "I'm sorry",
    type: "phrase",
    contextExample: "When apologizing"
  },
  {
    spanish: "Claro",
    english: "Sure/Of course",
    type: "response",
    contextExample: "When agreeing casually"
  },
  {
    spanish: "¿Puedes ayudarme?",
    english: "Can you help me?",
    type: "question",
    contextExample: "When asking for assistance",
    contextual: true
  },
  {
    spanish: "Habla más alto, por favor",
    english: "Speak louder, please",
    type: "phrase",
    contextExample: "When you can't hear someone well"
  }
];

// Level 5: Numbers 1-10 - 25 vocabulary items
const level5Vocabulary: VocabularyWord[] = [
  {
    spanish: "Uno",
    english: "One",
    type: "number",
    contextExample: "The number 1"
  },
  {
    spanish: "Dos",
    english: "Two",
    type: "number",
    contextExample: "The number 2"
  },
  {
    spanish: "Tres",
    english: "Three",
    type: "number",
    contextExample: "The number 3"
  },
  {
    spanish: "Cuatro",
    english: "Four",
    type: "number",
    contextExample: "The number 4"
  },
  {
    spanish: "Cinco",
    english: "Five",
    type: "number",
    contextExample: "The number 5"
  },
  {
    spanish: "Seis",
    english: "Six",
    type: "number",
    contextExample: "The number 6"
  },
  {
    spanish: "Siete",
    english: "Seven",
    type: "number",
    contextExample: "The number 7"
  },
  {
    spanish: "Ocho",
    english: "Eight",
    type: "number",
    contextExample: "The number 8"
  },
  {
    spanish: "Nueve",
    english: "Nine",
    type: "number",
    contextExample: "The number 9"
  },
  {
    spanish: "Diez",
    english: "Ten",
    type: "number",
    contextExample: "The number 10"
  },
  {
    spanish: "¿Cuántos?",
    english: "How many?",
    type: "question",
    contextExample: "When asking about quantity"
  },
  {
    spanish: "Más",
    english: "More",
    type: "adjective",
    contextExample: "When asking for or describing more of something"
  },
  {
    spanish: "Menos",
    english: "Less",
    type: "adjective",
    contextExample: "When asking for or describing less of something"
  },
  {
    spanish: "Mucho",
    english: "A lot",
    type: "adjective",
    contextExample: "When describing a large quantity"
  },
  {
    spanish: "Poco",
    english: "A little",
    type: "adjective",
    contextExample: "When describing a small quantity"
  },
  // Adding 10 more vocabulary items
  {
    spanish: "Contar",
    english: "To count",
    type: "verb",
    contextExample: "To recite numbers in sequence"
  },
  {
    spanish: "Número",
    english: "Number",
    type: "noun",
    contextExample: "A mathematical value"
  },
  {
    spanish: "Cero",
    english: "Zero",
    type: "number",
    contextExample: "The number 0"
  },
  {
    spanish: "Primero",
    english: "First",
    type: "ordinal",
    contextExample: "The position of being first in a sequence"
  },
  {
    spanish: "Segundo",
    english: "Second",
    type: "ordinal",
    contextExample: "The position of being second in a sequence"
  },
  {
    spanish: "Tercero",
    english: "Third",
    type: "ordinal",
    contextExample: "The position of being third in a sequence"
  },
  {
    spanish: "El doble",
    english: "The double",
    type: "noun",
    contextExample: "Twice the amount"
  },
  {
    spanish: "La mitad",
    english: "The half",
    type: "noun",
    contextExample: "One of two equal parts"
  },
  {
    spanish: "¿Cuántos años tienes?",
    english: "How old are you?",
    type: "question",
    contextExample: "Literally: How many years do you have?",
    contextual: true
  },
  {
    spanish: "Tengo diez años",
    english: "I am ten years old",
    type: "phrase",
    contextExample: "Literally: I have ten years"
  }
];

// Level 6: Numbers 11-31 - 25 vocabulary items
const level6Vocabulary: VocabularyWord[] = [
  {
    spanish: "Once",
    english: "Eleven",
    type: "number",
    contextExample: "The number 11"
  },
  {
    spanish: "Doce",
    english: "Twelve",
    type: "number",
    contextExample: "The number 12"
  },
  {
    spanish: "Trece",
    english: "Thirteen",
    type: "number",
    contextExample: "The number 13"
  },
  {
    spanish: "Catorce",
    english: "Fourteen",
    type: "number",
    contextExample: "The number 14"
  },
  {
    spanish: "Quince",
    english: "Fifteen",
    type: "number",
    contextExample: "The number 15"
  },
  {
    spanish: "Dieciséis",
    english: "Sixteen",
    type: "number",
    contextExample: "The number 16"
  },
  {
    spanish: "Diecisiete",
    english: "Seventeen",
    type: "number",
    contextExample: "The number 17"
  },
  {
    spanish: "Dieciocho",
    english: "Eighteen",
    type: "number",
    contextExample: "The number 18"
  },
  {
    spanish: "Diecinueve",
    english: "Nineteen",
    type: "number",
    contextExample: "The number 19"
  },
  {
    spanish: "Veinte",
    english: "Twenty",
    type: "number",
    contextExample: "The number 20"
  },
  {
    spanish: "Veintiuno",
    english: "Twenty-one",
    type: "number",
    contextExample: "The number 21"
  },
  {
    spanish: "Veintidós",
    english: "Twenty-two",
    type: "number",
    contextExample: "The number 22"
  },
  {
    spanish: "Veintitrés",
    english: "Twenty-three",
    type: "number",
    contextExample: "The number 23"
  },
  {
    spanish: "Veinticuatro",
    english: "Twenty-four",
    type: "number",
    contextExample: "The number 24"
  },
  {
    spanish: "Veinticinco",
    english: "Twenty-five",
    type: "number",
    contextExample: "The number 25"
  },
  {
    spanish: "Treinta",
    english: "Thirty",
    type: "number",
    contextExample: "The number 30"
  },
  {
    spanish: "Treinta y uno",
    english: "Thirty-one",
    type: "number",
    contextExample: "The number 31"
  },
  {
    spanish: "Primero",
    english: "First",
    type: "ordinal",
    contextExample: "When describing the 1st position"
  },
  {
    spanish: "Segundo",
    english: "Second",
    type: "ordinal",
    contextExample: "When describing the 2nd position"
  },
  {
    spanish: "Tercero",
    english: "Third",
    type: "ordinal",
    contextExample: "When describing the 3rd position"
  },
  {
    spanish: "Cuarto",
    english: "Fourth",
    type: "ordinal",
    contextExample: "When describing the 4th position"
  },
  {
    spanish: "Quinto",
    english: "Fifth",
    type: "ordinal",
    contextExample: "When describing the 5th position"
  },
  {
    spanish: "La fecha",
    english: "The date",
    type: "noun",
    contextExample: "When talking about dates"
  },
  {
    spanish: "El día",
    english: "The day",
    type: "noun",
    contextExample: "When talking about a day"
  },
  {
    spanish: "El mes",
    english: "The month",
    type: "noun",
    contextExample: "When talking about months"
  }
];

// Level 7: Counting & Basic Math - 25 vocabulary items
const level7Vocabulary: VocabularyWord[] = [
  {
    spanish: "Sumar",
    english: "To add",
    type: "verb",
    contextExample: "When doing addition"
  },
  {
    spanish: "Restar",
    english: "To subtract",
    type: "verb",
    contextExample: "When doing subtraction"
  },
  {
    spanish: "Multiplicar",
    english: "To multiply",
    type: "verb",
    contextExample: "When doing multiplication"
  },
  {
    spanish: "Dividir",
    english: "To divide",
    type: "verb",
    contextExample: "When doing division"
  },
  {
    spanish: "Igual",
    english: "Equal",
    type: "adjective",
    contextExample: "When describing equality"
  },
  {
    spanish: "Más",
    english: "Plus",
    type: "math",
    contextExample: "Addition symbol"
  },
  {
    spanish: "Menos",
    english: "Minus",
    type: "math",
    contextExample: "Subtraction symbol"
  },
  {
    spanish: "Por",
    english: "Times",
    type: "math",
    contextExample: "Multiplication symbol"
  },
  {
    spanish: "Dividido por",
    english: "Divided by",
    type: "math",
    contextExample: "Division symbol"
  },
  {
    spanish: "Es igual a",
    english: "Equals",
    type: "math",
    contextExample: "Equals symbol"
  },
  {
    spanish: "La suma",
    english: "The sum",
    type: "noun",
    contextExample: "The result of addition"
  },
  {
    spanish: "La resta",
    english: "The difference",
    type: "noun",
    contextExample: "The result of subtraction"
  },
  {
    spanish: "El producto",
    english: "The product",
    type: "noun",
    contextExample: "The result of multiplication"
  },
  {
    spanish: "El cociente",
    english: "The quotient",
    type: "noun",
    contextExample: "The result of division"
  },
  {
    spanish: "Contar",
    english: "To count",
    type: "verb",
    contextExample: "When counting objects"
  },
  // Adding 10 more vocabulary items
  {
    spanish: "El número",
    english: "The number",
    type: "noun",
    contextExample: "A numerical value"
  },
  {
    spanish: "Sumar dos y dos",
    english: "To add two and two",
    type: "phrase",
    contextExample: "When adding specific numbers"
  },
  {
    spanish: "La calculadora",
    english: "The calculator",
    type: "noun",
    contextExample: "A device for performing calculations"
  },
  {
    spanish: "El problema matemático",
    english: "The math problem",
    type: "noun",
    contextExample: "A mathematical question to solve"
  },
  {
    spanish: "La solución",
    english: "The solution",
    type: "noun",
    contextExample: "The answer to a problem"
  },
  {
    spanish: "Resolver",
    english: "To solve",
    type: "verb",
    contextExample: "When finding the solution to a problem"
  },
  {
    spanish: "El doble",
    english: "The double/twice",
    type: "noun",
    contextExample: "Two times a number"
  },
  {
    spanish: "La mitad",
    english: "The half",
    type: "noun",
    contextExample: "One of two equal parts"
  },
  {
    spanish: "Correcto",
    english: "Correct",
    type: "adjective",
    contextExample: "When an answer is right"
  },
  {
    spanish: "Incorrecto",
    english: "Incorrect",
    type: "adjective",
    contextExample: "When an answer is wrong"
  }
];

// Level 8: Basic Colors - 25 vocabulary items
const level8Vocabulary: VocabularyWord[] = [
  {
    spanish: "Rojo",
    english: "Red",
    type: "color",
    contextExample: "The color red"
  },
  {
    spanish: "Azul",
    english: "Blue",
    type: "color",
    contextExample: "The color blue"
  },
  {
    spanish: "Amarillo",
    english: "Yellow",
    type: "color",
    contextExample: "The color yellow"
  },
  {
    spanish: "Verde",
    english: "Green",
    type: "color",
    contextExample: "The color green"
  },
  {
    spanish: "Negro",
    english: "Black",
    type: "color",
    contextExample: "The color black"
  },
  {
    spanish: "Blanco",
    english: "White",
    type: "color",
    contextExample: "The color white"
  },
  {
    spanish: "Marrón",
    english: "Brown",
    type: "color",
    contextExample: "The color brown"
  },
  {
    spanish: "Gris",
    english: "Gray",
    type: "color",
    contextExample: "The color gray"
  },
  {
    spanish: "Naranja",
    english: "Orange",
    type: "color",
    contextExample: "The color orange"
  },
  {
    spanish: "Morado",
    english: "Purple",
    type: "color",
    contextExample: "The color purple"
  },
  {
    spanish: "Rosa",
    english: "Pink",
    type: "color",
    contextExample: "The color pink"
  },
  {
    spanish: "¿De qué color es?",
    english: "What color is it?",
    type: "question",
    contextExample: "When asking about the color of something",
    contextual: true
  },
  // Adding 13 more vocabulary items
  {
    spanish: "Azul claro",
    english: "Light blue",
    type: "color",
    contextExample: "A pale shade of blue"
  },
  {
    spanish: "Azul oscuro",
    english: "Dark blue",
    type: "color",
    contextExample: "A deep shade of blue"
  },
  {
    spanish: "Verde claro",
    english: "Light green",
    type: "color",
    contextExample: "A pale shade of green"
  },
  {
    spanish: "Verde oscuro",
    english: "Dark green",
    type: "color",
    contextExample: "A deep shade of green"
  },
  {
    spanish: "Rojo oscuro",
    english: "Dark red",
    type: "color",
    contextExample: "A deep shade of red"
  },
  {
    spanish: "Colores primarios",
    english: "Primary colors",
    type: "phrase",
    contextExample: "Red, yellow, and blue"
  },
  {
    spanish: "Mi color favorito es",
    english: "My favorite color is",
    type: "phrase",
    contextExample: "When expressing your preferred color"
  },
  {
    spanish: "¿Cuál es tu color favorito?",
    english: "What is your favorite color?",
    type: "question",
    contextExample: "When asking someone about their preferred color",
    contextual: true
  },
  {
    spanish: "Colorear",
    english: "To color",
    type: "verb",
    contextExample: "When adding color to something"
  },
  {
    spanish: "El arcoíris",
    english: "The rainbow",
    type: "noun",
    contextExample: "A natural phenomenon showing all colors"
  },
  {
    spanish: "El rojo es bonito",
    english: "Red is pretty",
    type: "phrase",
    contextExample: "When describing a color as attractive"
  },
  {
    spanish: "Dorado",
    english: "Golden",
    type: "color",
    contextExample: "The color similar to gold"
  },
  {
    spanish: "Plateado",
    english: "Silver",
    type: "color",
    contextExample: "The color similar to silver"
  }
];

// Level 9: Family Members - 25 vocabulary items with greetings
const level9Vocabulary: VocabularyWord[] = [
  {
    spanish: "La familia",
    english: "The family",
    type: "noun",
    contextExample: "Talking about the family as a group"
  },
  {
    spanish: "El padre",
    english: "The father",
    type: "noun",
    contextExample: "Male parent"
  },
  {
    spanish: "La madre",
    english: "The mother",
    type: "noun",
    contextExample: "Female parent"
  },
  {
    spanish: "El hermano",
    english: "The brother",
    type: "noun",
    contextExample: "Male sibling"
  },
  {
    spanish: "La hermana",
    english: "The sister",
    type: "noun",
    contextExample: "Female sibling"
  },
  {
    spanish: "El abuelo",
    english: "The grandfather",
    type: "noun",
    contextExample: "Father of a parent"
  },
  {
    spanish: "La abuela",
    english: "The grandmother",
    type: "noun",
    contextExample: "Mother of a parent"
  },
  {
    spanish: "El tío",
    english: "The uncle",
    type: "noun",
    contextExample: "Brother of a parent"
  },
  {
    spanish: "La tía",
    english: "The aunt",
    type: "noun",
    contextExample: "Sister of a parent"
  },
  {
    spanish: "El primo",
    english: "The male cousin",
    type: "noun",
    contextExample: "Son of an aunt or uncle"
  },
  {
    spanish: "La prima",
    english: "The female cousin",
    type: "noun",
    contextExample: "Daughter of an aunt or uncle"
  },
  {
    spanish: "El hijo",
    english: "The son",
    type: "noun",
    contextExample: "Male child in relation to parents"
  },
  {
    spanish: "La hija",
    english: "The daughter",
    type: "noun",
    contextExample: "Female child in relation to parents"
  },
  {
    spanish: "Los padres",
    english: "The parents",
    type: "noun",
    contextExample: "Mother and father together"
  },
  {
    spanish: "Los abuelos",
    english: "The grandparents",
    type: "noun",
    contextExample: "Grandmother and grandfather together"
  },
  // Adding family-related greeting phrases
  {
    spanish: "¡Hola, familia!",
    english: "Hello, family!",
    type: "greeting",
    contextExample: "When greeting your whole family"
  },
  {
    spanish: "Buenos días, mamá",
    english: "Good morning, mom",
    type: "greeting",
    contextExample: "When greeting your mother in the morning"
  },
  {
    spanish: "Buenas tardes, papá",
    english: "Good afternoon, dad",
    type: "greeting",
    contextExample: "When greeting your father in the afternoon"
  },
  {
    spanish: "Buenas noches, abuelos",
    english: "Good night, grandparents",
    type: "greeting",
    contextExample: "When saying goodnight to your grandparents"
  },
  {
    spanish: "¿Cómo estás, hermano?",
    english: "How are you, brother?",
    type: "greeting",
    contextExample: "When asking your brother how he is",
    contextual: true
  },
  {
    spanish: "¿Cómo estás, hermana?",
    english: "How are you, sister?",
    type: "greeting",
    contextExample: "When asking your sister how she is",
    contextual: true
  },
  {
    spanish: "Te presento a mi familia",
    english: "Let me introduce you to my family",
    type: "phrase",
    contextExample: "When introducing someone to your family"
  },
  {
    spanish: "Mi familia es grande",
    english: "My family is big",
    type: "phrase",
    contextExample: "When describing a large family"
  },
  {
    spanish: "Te extraño, mamá",
    english: "I miss you, mom",
    type: "phrase",
    contextExample: "When expressing that you miss your mother"
  },
  {
    spanish: "Feliz cumpleaños, tío",
    english: "Happy birthday, uncle",
    type: "greeting",
    contextExample: "When wishing your uncle a happy birthday"
  }
];

// Level 10: Common Animals - 25 vocabulary items with greetings and phrases
const level10Vocabulary: VocabularyWord[] = [
  {
    spanish: "El perro",
    english: "The dog",
    type: "animal",
    contextExample: "Common domestic pet"
  },
  {
    spanish: "El gato",
    english: "The cat",
    type: "animal",
    contextExample: "Common domestic pet"
  },
  {
    spanish: "El pájaro",
    english: "The bird",
    type: "animal",
    contextExample: "Flying animal with feathers"
  },
  {
    spanish: "El pez",
    english: "The fish",
    type: "animal",
    contextExample: "Aquatic animal that swims"
  },
  {
    spanish: "El caballo",
    english: "The horse",
    type: "animal",
    contextExample: "Large domestic animal for riding"
  },
  {
    spanish: "La vaca",
    english: "The cow",
    type: "animal",
    contextExample: "Farm animal that produces milk"
  },
  {
    spanish: "El cerdo",
    english: "The pig",
    type: "animal",
    contextExample: "Farm animal"
  },
  {
    spanish: "La gallina",
    english: "The hen",
    type: "animal",
    contextExample: "Female farm bird that lays eggs"
  },
  {
    spanish: "El ratón",
    english: "The mouse",
    type: "animal",
    contextExample: "Small rodent"
  },
  {
    spanish: "El conejo",
    english: "The rabbit",
    type: "animal",
    contextExample: "Small animal with long ears"
  },
  {
    spanish: "El león",
    english: "The lion",
    type: "animal",
    contextExample: "Large wild cat"
  },
  {
    spanish: "El oso",
    english: "The bear",
    type: "animal",
    contextExample: "Large wild animal"
  },
  {
    spanish: "La serpiente",
    english: "The snake",
    type: "animal",
    contextExample: "Reptile without legs"
  },
  {
    spanish: "La tortuga",
    english: "The turtle",
    type: "animal",
    contextExample: "Slow reptile with a shell"
  },
  {
    spanish: "El elefante",
    english: "The elephant",
    type: "animal",
    contextExample: "Large animal with a trunk"
  },
  // Adding more animals and related expressions
  {
    spanish: "El mono",
    english: "The monkey",
    type: "animal",
    contextExample: "Primate that often lives in trees"
  },
  {
    spanish: "La jirafa",
    english: "The giraffe",
    type: "animal",
    contextExample: "Tall animal with a long neck"
  },
  {
    spanish: "El tigre",
    english: "The tiger",
    type: "animal",
    contextExample: "Large wild cat with stripes"
  },
  {
    spanish: "El lobo",
    english: "The wolf",
    type: "animal",
    contextExample: "Wild canine that lives in packs"
  },
  {
    spanish: "La rana",
    english: "The frog",
    type: "animal",
    contextExample: "Amphibian that jumps"
  },
  // Adding greeting phrases and animal-related expressions
  {
    spanish: "¡Hola, animalitos!",
    english: "Hello, little animals!",
    type: "greeting",
    contextExample: "When greeting small animals or pets"
  },
  {
    spanish: "Buenos días, Perrito",
    english: "Good morning, little dog",
    type: "greeting",
    contextExample: "Greeting your pet dog in the morning"
  },
  {
    spanish: "Buenas noches, Gatito",
    english: "Good night, little cat",
    type: "greeting",
    contextExample: "Saying good night to your pet cat"
  },
  {
    spanish: "¿Cómo están los animales hoy?",
    english: "How are the animals today?",
    type: "greeting",
    contextExample: "Asking about animals at a zoo or farm",
    contextual: true
  },
  {
    spanish: "Este es mi mascota",
    english: "This is my pet",
    type: "phrase",
    contextExample: "When introducing your pet to someone"
  }
];

// Level 11: Food and Drink - 25 vocabulary items with greetings and phrases
const level11Vocabulary: VocabularyWord[] = [
  {
    spanish: "La comida",
    english: "The food",
    type: "noun",
    contextExample: "General term for things we eat"
  },
  {
    spanish: "La bebida",
    english: "The drink",
    type: "noun",
    contextExample: "General term for things we drink"
  },
  {
    spanish: "El agua",
    english: "The water",
    type: "drink",
    contextExample: "Clear liquid to drink"
  },
  {
    spanish: "El pan",
    english: "The bread",
    type: "food",
    contextExample: "Baked food made of flour"
  },
  {
    spanish: "La leche",
    english: "The milk",
    type: "drink",
    contextExample: "White drink from cows"
  },
  {
    spanish: "El jugo",
    english: "The juice",
    type: "drink",
    contextExample: "Drink made from fruits"
  },
  {
    spanish: "La manzana",
    english: "The apple",
    type: "food",
    contextExample: "Round red or green fruit"
  },
  {
    spanish: "El plátano",
    english: "The banana",
    type: "food",
    contextExample: "Long yellow fruit"
  },
  {
    spanish: "La naranja",
    english: "The orange",
    type: "food",
    contextExample: "Round orange fruit"
  },
  {
    spanish: "El queso",
    english: "The cheese",
    type: "food",
    contextExample: "Dairy product"
  },
  {
    spanish: "El pollo",
    english: "The chicken",
    type: "food",
    contextExample: "Meat from a chicken"
  },
  {
    spanish: "La carne",
    english: "The meat",
    type: "food",
    contextExample: "Food from animals"
  },
  {
    spanish: "El arroz",
    english: "The rice",
    type: "food",
    contextExample: "Small white grain"
  },
  {
    spanish: "La sopa",
    english: "The soup",
    type: "food",
    contextExample: "Liquid food in a bowl"
  },
  {
    spanish: "El helado",
    english: "The ice cream",
    type: "food",
    contextExample: "Frozen sweet dessert"
  },
  // Additional food and drink items
  {
    spanish: "El chocolate",
    english: "The chocolate",
    type: "food",
    contextExample: "Sweet brown treat"
  },
  {
    spanish: "La pasta",
    english: "The pasta",
    type: "food",
    contextExample: "Italian noodle dish"
  },
  {
    spanish: "Las verduras",
    english: "The vegetables",
    type: "food",
    contextExample: "Edible plant parts"
  },
  {
    spanish: "Las frutas",
    english: "The fruits",
    type: "food",
    contextExample: "Sweet plant parts with seeds"
  },
  {
    spanish: "El café",
    english: "The coffee",
    type: "drink",
    contextExample: "Hot beverage made from ground beans"
  },
  // Food-related greeting phrases
  {
    spanish: "¡Buen provecho!",
    english: "Enjoy your meal!",
    type: "greeting",
    contextExample: "Said before starting to eat a meal"
  },
  {
    spanish: "¡A la mesa!",
    english: "To the table!",
    type: "greeting",
    contextExample: "Calling people to come eat"
  },
  {
    spanish: "La comida está lista",
    english: "The food is ready",
    type: "phrase",
    contextExample: "Announcing that a meal is prepared"
  },
  {
    spanish: "¿Tienes hambre?",
    english: "Are you hungry?",
    type: "greeting",
    contextExample: "Asking if someone wants to eat",
    contextual: true
  },
  {
    spanish: "¿Qué quieres comer?",
    english: "What do you want to eat?",
    type: "greeting",
    contextExample: "Asking for food preferences",
    contextual: true
  }
];

// Level 12: Days of the Week and Time - 25 vocabulary items with greetings
const level12Vocabulary: VocabularyWord[] = [
  {
    spanish: "Lunes",
    english: "Monday",
    type: "day",
    contextExample: "First day of the work week"
  },
  {
    spanish: "Martes",
    english: "Tuesday",
    type: "day",
    contextExample: "Second day of the work week"
  },
  {
    spanish: "Miércoles",
    english: "Wednesday",
    type: "day",
    contextExample: "Third day of the work week"
  },
  {
    spanish: "Jueves",
    english: "Thursday",
    type: "day",
    contextExample: "Fourth day of the work week"
  },
  {
    spanish: "Viernes",
    english: "Friday",
    type: "day",
    contextExample: "Fifth day of the work week"
  },
  {
    spanish: "Sábado",
    english: "Saturday",
    type: "day",
    contextExample: "Weekend day"
  },
  {
    spanish: "Domingo",
    english: "Sunday",
    type: "day",
    contextExample: "Weekend day"
  },
  {
    spanish: "La hora",
    english: "The hour/time",
    type: "time",
    contextExample: "Measurement of time"
  },
  {
    spanish: "El minuto",
    english: "The minute",
    type: "time",
    contextExample: "60 seconds"
  },
  {
    spanish: "El segundo",
    english: "The second",
    type: "time",
    contextExample: "Basic unit of time"
  },
  {
    spanish: "La mañana",
    english: "The morning",
    type: "time",
    contextExample: "Early part of the day"
  },
  {
    spanish: "La tarde",
    english: "The afternoon",
    type: "time",
    contextExample: "Middle part of the day"
  },
  {
    spanish: "La noche",
    english: "The night",
    type: "time",
    contextExample: "Dark part of the day"
  },
  {
    spanish: "¿Qué hora es?",
    english: "What time is it?",
    type: "question",
    contextExample: "Asking for the current time"
  },
  {
    spanish: "Son las...",
    english: "It is... (time)",
    type: "phrase",
    contextExample: "Telling the time"
  },
  // Additional time vocabulary
  {
    spanish: "El reloj",
    english: "The clock/watch",
    type: "noun",
    contextExample: "Device used to tell time"
  },
  {
    spanish: "El día",
    english: "The day",
    type: "time",
    contextExample: "24-hour period"
  },
  {
    spanish: "La semana",
    english: "The week",
    type: "time",
    contextExample: "Period of seven days"
  },
  {
    spanish: "El mes",
    english: "The month",
    type: "time",
    contextExample: "One of twelve divisions of a year"
  },
  {
    spanish: "El año",
    english: "The year",
    type: "time",
    contextExample: "Period of 365/366 days"
  },
  // Time-related greetings and phrases
  {
    spanish: "Feliz fin de semana",
    english: "Happy weekend",
    type: "greeting",
    contextExample: "Wishing someone a good weekend"
  },
  {
    spanish: "Hasta el lunes",
    english: "See you on Monday",
    type: "greeting",
    contextExample: "Saying goodbye until Monday"
  },
  {
    spanish: "Nos vemos mañana",
    english: "See you tomorrow",
    type: "greeting",
    contextExample: "Saying goodbye until the next day"
  },
  {
    spanish: "¡Que tengas un buen día!",
    english: "Have a good day!",
    type: "greeting",
    contextExample: "Wishing someone a good day"
  },
  {
    spanish: "¿A qué hora nos vemos?",
    english: "What time are we meeting?",
    type: "greeting",
    contextExample: "Asking about meeting time",
    contextual: true
  }
];

// Level 13: Weather and Seasons - 25 vocabulary items with greetings
const level13Vocabulary: VocabularyWord[] = [
  {
    spanish: "El clima",
    english: "The weather",
    type: "noun",
    contextExample: "Atmospheric conditions"
  },
  {
    spanish: "La estación",
    english: "The season",
    type: "noun",
    contextExample: "Part of the year with distinctive weather"
  },
  {
    spanish: "La primavera",
    english: "Spring",
    type: "season",
    contextExample: "Season after winter, with flowers blooming"
  },
  {
    spanish: "El verano",
    english: "Summer",
    type: "season",
    contextExample: "Hot season of the year"
  },
  {
    spanish: "El otoño",
    english: "Fall/Autumn",
    type: "season",
    contextExample: "Season when leaves change color"
  },
  {
    spanish: "El invierno",
    english: "Winter",
    type: "season",
    contextExample: "Cold season of the year"
  },
  {
    spanish: "Hace sol",
    english: "It's sunny",
    type: "phrase",
    contextExample: "Describing sunny weather"
  },
  {
    spanish: "Hace calor",
    english: "It's hot",
    type: "phrase",
    contextExample: "Describing hot weather"
  },
  {
    spanish: "Hace frío",
    english: "It's cold",
    type: "phrase",
    contextExample: "Describing cold weather"
  },
  {
    spanish: "Llueve",
    english: "It's raining",
    type: "phrase",
    contextExample: "Describing rainy weather"
  },
  {
    spanish: "Nieva",
    english: "It's snowing",
    type: "phrase",
    contextExample: "Describing snowy weather"
  },
  {
    spanish: "Está nublado",
    english: "It's cloudy",
    type: "phrase",
    contextExample: "Describing cloudy weather"
  },
  {
    spanish: "Hay viento",
    english: "It's windy",
    type: "phrase",
    contextExample: "Describing windy weather"
  },
  {
    spanish: "La temperatura",
    english: "The temperature",
    type: "noun",
    contextExample: "Measurement of how hot or cold it is"
  },
  {
    spanish: "El pronóstico",
    english: "The forecast",
    type: "noun",
    contextExample: "Prediction of future weather"
  },
  // Additional weather vocabulary
  {
    spanish: "La lluvia",
    english: "The rain",
    type: "noun",
    contextExample: "Water falling from clouds"
  },
  {
    spanish: "La nieve",
    english: "The snow",
    type: "noun",
    contextExample: "Frozen precipitation in white flakes"
  },
  {
    spanish: "El hielo",
    english: "The ice",
    type: "noun",
    contextExample: "Frozen water"
  },
  {
    spanish: "La niebla",
    english: "The fog",
    type: "noun",
    contextExample: "Cloud near the ground that reduces visibility"
  },
  {
    spanish: "El arcoiris",
    english: "The rainbow",
    type: "noun",
    contextExample: "Multicolored arc in the sky after rain"
  },
  // Weather-related greetings and phrases
  {
    spanish: "¡Qué día tan bonito!",
    english: "What a beautiful day!",
    type: "greeting",
    contextExample: "Commenting on nice weather"
  },
  {
    spanish: "¡Qué frío hace hoy!",
    english: "How cold it is today!",
    type: "greeting",
    contextExample: "Commenting on cold weather"
  },
  {
    spanish: "¡Qué calor hace!",
    english: "How hot it is!",
    type: "greeting",
    contextExample: "Commenting on hot weather"
  },
  {
    spanish: "¿Cómo está el clima hoy?",
    english: "How is the weather today?",
    type: "greeting",
    contextExample: "Asking about the current weather",
    contextual: true
  },
  {
    spanish: "No olvides tu paraguas",
    english: "Don't forget your umbrella",
    type: "greeting",
    contextExample: "Reminder when it's raining or going to rain"
  }
];

// Level 14: Clothing and Shopping - 25 vocabulary items with greetings
const level14Vocabulary: VocabularyWord[] = [
  {
    spanish: "La ropa",
    english: "The clothing",
    type: "noun",
    contextExample: "Items worn to cover the body"
  },
  {
    spanish: "La camisa",
    english: "The shirt",
    type: "clothing",
    contextExample: "Upper body garment"
  },
  {
    spanish: "Los pantalones",
    english: "The pants",
    type: "clothing",
    contextExample: "Lower body garment"
  },
  {
    spanish: "Los zapatos",
    english: "The shoes",
    type: "clothing",
    contextExample: "Footwear"
  },
  {
    spanish: "El vestido",
    english: "The dress",
    type: "clothing",
    contextExample: "One-piece garment typically for women"
  },
  {
    spanish: "La falda",
    english: "The skirt",
    type: "clothing",
    contextExample: "Lower body garment typically for women"
  },
  {
    spanish: "La chaqueta",
    english: "The jacket",
    type: "clothing",
    contextExample: "Outer garment for the upper body"
  },
  {
    spanish: "El sombrero",
    english: "The hat",
    type: "clothing",
    contextExample: "Head covering"
  },
  {
    spanish: "La tienda",
    english: "The store/shop",
    type: "noun",
    contextExample: "Place to buy things"
  },
  {
    spanish: "El precio",
    english: "The price",
    type: "noun",
    contextExample: "Cost of an item"
  },
  {
    spanish: "¿Cuánto cuesta?",
    english: "How much does it cost?",
    type: "question",
    contextExample: "Asking about price"
  },
  {
    spanish: "Barato",
    english: "Cheap",
    type: "adjective",
    contextExample: "Low price"
  },
  {
    spanish: "Caro",
    english: "Expensive",
    type: "adjective",
    contextExample: "High price"
  },
  {
    spanish: "Comprar",
    english: "To buy",
    type: "verb",
    contextExample: "To purchase something"
  },
  {
    spanish: "Vender",
    english: "To sell",
    type: "verb",
    contextExample: "To provide something for money"
  },
  // Additional clothing and shopping vocabulary
  {
    spanish: "La talla",
    english: "The size",
    type: "noun",
    contextExample: "Measurement for clothing"
  },
  {
    spanish: "El probador",
    english: "The fitting room",
    type: "noun",
    contextExample: "Room to try on clothes"
  },
  {
    spanish: "El descuento",
    english: "The discount",
    type: "noun",
    contextExample: "Reduction in price"
  },
  {
    spanish: "En oferta",
    english: "On sale",
    type: "phrase",
    contextExample: "Indicating a reduced price"
  },
  {
    spanish: "La caja",
    english: "The cash register",
    type: "noun",
    contextExample: "Where you pay in a store"
  },
  // Shopping and clothing-related greetings
  {
    spanish: "¿Puedo ayudarle?",
    english: "Can I help you?",
    type: "greeting",
    contextExample: "Shop assistant offering help"
  },
  {
    spanish: "Estoy buscando...",
    english: "I am looking for...",
    type: "greeting",
    contextExample: "When shopping for specific items",
    contextual: true
  },
  {
    spanish: "Me gusta esta camisa",
    english: "I like this shirt",
    type: "greeting",
    contextExample: "Expressing preference for an item"
  },
  {
    spanish: "¿Tiene esto en azul?",
    english: "Do you have this in blue?",
    type: "greeting",
    contextExample: "Asking for a different color",
    contextual: true
  },
  {
    spanish: "Quiero probarlo",
    english: "I want to try it on",
    type: "greeting",
    contextExample: "Wanting to try clothes"
  }
];

// Level 15: Parts of the Body - 25 vocabulary items with greetings
const level15Vocabulary: VocabularyWord[] = [
  {
    spanish: "El cuerpo",
    english: "The body",
    type: "noun",
    contextExample: "The physical structure of a person"
  },
  {
    spanish: "La cabeza",
    english: "The head",
    type: "bodyPart",
    contextExample: "Upper part of the body containing the brain"
  },
  {
    spanish: "La cara",
    english: "The face",
    type: "bodyPart",
    contextExample: "Front part of the head"
  },
  {
    spanish: "Los ojos",
    english: "The eyes",
    type: "bodyPart",
    contextExample: "Organs for seeing"
  },
  {
    spanish: "La nariz",
    english: "The nose",
    type: "bodyPart",
    contextExample: "Organ for smelling"
  },
  {
    spanish: "La boca",
    english: "The mouth",
    type: "bodyPart",
    contextExample: "Opening for eating and speaking"
  },
  {
    spanish: "Las orejas",
    english: "The ears",
    type: "bodyPart",
    contextExample: "Organs for hearing"
  },
  {
    spanish: "El brazo",
    english: "The arm",
    type: "bodyPart",
    contextExample: "Upper limb"
  },
  {
    spanish: "La mano",
    english: "The hand",
    type: "bodyPart",
    contextExample: "End part of the arm with fingers"
  },
  {
    spanish: "Los dedos",
    english: "The fingers",
    type: "bodyPart",
    contextExample: "Digits on the hand"
  },
  {
    spanish: "La pierna",
    english: "The leg",
    type: "bodyPart",
    contextExample: "Lower limb"
  },
  {
    spanish: "El pie",
    english: "The foot",
    type: "bodyPart",
    contextExample: "End part of the leg"
  },
  {
    spanish: "La espalda",
    english: "The back",
    type: "bodyPart",
    contextExample: "Rear part of the body"
  },
  {
    spanish: "El estómago",
    english: "The stomach",
    type: "bodyPart",
    contextExample: "Organ for digesting food"
  },
  {
    spanish: "El corazón",
    english: "The heart",
    type: "bodyPart",
    contextExample: "Organ that pumps blood"
  },
  // Additional body parts
  {
    spanish: "Los hombros",
    english: "The shoulders",
    type: "bodyPart",
    contextExample: "Where the arms connect to the torso"
  },
  {
    spanish: "El cuello",
    english: "The neck",
    type: "bodyPart",
    contextExample: "Part connecting the head to the body"
  },
  {
    spanish: "La rodilla",
    english: "The knee",
    type: "bodyPart",
    contextExample: "Joint in the middle of the leg"
  },
  {
    spanish: "El codo",
    english: "The elbow",
    type: "bodyPart",
    contextExample: "Joint in the middle of the arm"
  },
  {
    spanish: "El pulmón",
    english: "The lung",
    type: "bodyPart",
    contextExample: "Organ for breathing"
  },
  // Body-related greetings and health phrases
  {
    spanish: "Me duele la cabeza",
    english: "My head hurts",
    type: "greeting",
    contextExample: "Expressing a headache"
  },
  {
    spanish: "¿Cómo te sientes?",
    english: "How do you feel?",
    type: "greeting",
    contextExample: "Asking about someone's health",
    contextual: true
  },
  {
    spanish: "No me siento bien",
    english: "I don't feel well",
    type: "greeting",
    contextExample: "Expressing feeling ill"
  },
  {
    spanish: "Estoy saludable",
    english: "I am healthy",
    type: "greeting",
    contextExample: "Expressing good health"
  },
  {
    spanish: "Necesito ir al médico",
    english: "I need to go to the doctor",
    type: "greeting",
    contextExample: "Expressing need for medical attention"
  }
];

// Level 16: School and Education - 25 vocabulary items with greetings
const level16Vocabulary: VocabularyWord[] = [
  {
    spanish: "La escuela",
    english: "The school",
    type: "noun",
    contextExample: "Place for education"
  },
  {
    spanish: "La clase",
    english: "The class",
    type: "noun",
    contextExample: "A group of students or a lesson"
  },
  {
    spanish: "El estudiante",
    english: "The student",
    type: "noun",
    contextExample: "Person who studies"
  },
  {
    spanish: "El profesor",
    english: "The teacher (male)",
    type: "noun",
    contextExample: "Person who teaches"
  },
  {
    spanish: "La profesora",
    english: "The teacher (female)",
    type: "noun",
    contextExample: "Person who teaches"
  },
  {
    spanish: "El libro",
    english: "The book",
    type: "noun",
    contextExample: "Collection of written pages"
  },
  {
    spanish: "El cuaderno",
    english: "The notebook",
    type: "noun",
    contextExample: "Book for writing notes"
  },
  {
    spanish: "El lápiz",
    english: "The pencil",
    type: "noun",
    contextExample: "Writing tool with lead"
  },
  {
    spanish: "La pluma",
    english: "The pen",
    type: "noun",
    contextExample: "Writing tool with ink"
  },
  {
    spanish: "La mochila",
    english: "The backpack",
    type: "noun",
    contextExample: "Bag for carrying school supplies"
  },
  {
    spanish: "Estudiar",
    english: "To study",
    type: "verb",
    contextExample: "To learn or review material"
  },
  {
    spanish: "Leer",
    english: "To read",
    type: "verb",
    contextExample: "To look at and comprehend written words"
  },
  {
    spanish: "Escribir",
    english: "To write",
    type: "verb",
    contextExample: "To form letters and words"
  },
  {
    spanish: "Aprender",
    english: "To learn",
    type: "verb",
    contextExample: "To gain knowledge"
  },
  {
    spanish: "La tarea",
    english: "The homework",
    type: "noun",
    contextExample: "Work assigned to do at home"
  },
  // Additional school and education vocabulary
  {
    spanish: "El examen",
    english: "The exam",
    type: "noun",
    contextExample: "Test of knowledge"
  },
  {
    spanish: "La biblioteca",
    english: "The library",
    type: "noun",
    contextExample: "Place with many books"
  },
  {
    spanish: "El recreo",
    english: "Recess",
    type: "noun",
    contextExample: "Break time at school"
  },
  {
    spanish: "La pizarra",
    english: "The blackboard/whiteboard",
    type: "noun",
    contextExample: "Surface for writing in a classroom"
  },
  {
    spanish: "El idioma",
    english: "The language",
    type: "noun",
    contextExample: "System of communication with words"
  },
  // School and education-related greetings and phrases
  {
    spanish: "Buenos días, profesor",
    english: "Good morning, teacher",
    type: "greeting",
    contextExample: "Morning greeting to a male teacher"
  },
  {
    spanish: "Buenos días, profesora",
    english: "Good morning, teacher",
    type: "greeting",
    contextExample: "Morning greeting to a female teacher"
  },
  {
    spanish: "¿Puedo hacer una pregunta?",
    english: "May I ask a question?",
    type: "greeting",
    contextExample: "Asking permission to speak in class",
    contextual: true
  },
  {
    spanish: "No entiendo",
    english: "I don't understand",
    type: "greeting",
    contextExample: "Expressing confusion"
  },
  {
    spanish: "Tengo que estudiar para el examen",
    english: "I need to study for the test",
    type: "greeting",
    contextExample: "Talking about exam preparation"
  }
];

// Level 17: Hobbies and Free Time - 25 vocabulary items with greetings
const level17Vocabulary: VocabularyWord[] = [
  {
    spanish: "El pasatiempo",
    english: "The hobby",
    type: "noun",
    contextExample: "Activity done for pleasure"
  },
  {
    spanish: "El tiempo libre",
    english: "Free time",
    type: "noun",
    contextExample: "Time when you're not working"
  },
  {
    spanish: "Leer",
    english: "To read",
    type: "verb",
    contextExample: "To look at and comprehend written words"
  },
  {
    spanish: "Escribir",
    english: "To write",
    type: "verb",
    contextExample: "To form letters and words"
  },
  {
    spanish: "Dibujar",
    english: "To draw",
    type: "verb",
    contextExample: "To create pictures with a pencil or pen"
  },
  {
    spanish: "Pintar",
    english: "To paint",
    type: "verb",
    contextExample: "To create pictures with paint"
  },
  {
    spanish: "Escuchar música",
    english: "To listen to music",
    type: "phrase",
    contextExample: "To hear songs or instrumental pieces"
  },
  {
    spanish: "Tocar la guitarra",
    english: "To play the guitar",
    type: "phrase",
    contextExample: "To make music with a string instrument"
  },
  {
    spanish: "Cantar",
    english: "To sing",
    type: "verb",
    contextExample: "To make musical sounds with the voice"
  },
  {
    spanish: "Bailar",
    english: "To dance",
    type: "verb",
    contextExample: "To move rhythmically to music"
  },
  {
    spanish: "Jugar videojuegos",
    english: "To play video games",
    type: "phrase",
    contextExample: "To interact with electronic games"
  },
  {
    spanish: "Ver la televisión",
    english: "To watch television",
    type: "phrase",
    contextExample: "To view programs on TV"
  },
  {
    spanish: "Hacer deporte",
    english: "To play sports",
    type: "phrase",
    contextExample: "To engage in athletic activities"
  },
  {
    spanish: "Nadar",
    english: "To swim",
    type: "verb",
    contextExample: "To move through water"
  },
  {
    spanish: "Correr",
    english: "To run",
    type: "verb",
    contextExample: "To move quickly on foot"
  },
  // Additional hobbies vocabulary
  {
    spanish: "La fotografía",
    english: "Photography",
    type: "noun",
    contextExample: "Taking pictures as a hobby"
  },
  {
    spanish: "Cocinar",
    english: "To cook",
    type: "verb",
    contextExample: "To prepare food"
  },
  {
    spanish: "Viajar",
    english: "To travel",
    type: "verb",
    contextExample: "To go to different places"
  },
  {
    spanish: "El jardín",
    english: "The garden",
    type: "noun",
    contextExample: "Area for growing plants"
  },
  {
    spanish: "Coleccionar",
    english: "To collect",
    type: "verb",
    contextExample: "To gather items of interest"
  },
  // Hobby-related greetings and phrases
  {
    spanish: "¿Qué te gusta hacer en tu tiempo libre?",
    english: "What do you like to do in your free time?",
    type: "greeting",
    contextExample: "Asking about someone's hobbies",
    contextual: true
  },
  {
    spanish: "Me gusta mucho bailar",
    english: "I really like to dance",
    type: "greeting",
    contextExample: "Expressing fondness for dancing"
  },
  {
    spanish: "¿Quieres jugar al fútbol?",
    english: "Do you want to play soccer?",
    type: "greeting",
    contextExample: "Inviting someone to play a sport",
    contextual: true
  },
  {
    spanish: "Mi pasatiempo favorito es...",
    english: "My favorite hobby is...",
    type: "greeting",
    contextExample: "Talking about preferred activities"
  },
  {
    spanish: "Vamos a escuchar música",
    english: "Let's listen to music",
    type: "greeting",
    contextExample: "Suggesting an activity"
  }
];

// Level 18: Transportation - 25 vocabulary items with greetings
const level18Vocabulary: VocabularyWord[] = [
  {
    spanish: "El transporte",
    english: "Transportation",
    type: "noun",
    contextExample: "Means of moving from one place to another"
  },
  {
    spanish: "El coche / El carro",
    english: "The car",
    type: "noun",
    contextExample: "Four-wheeled motor vehicle"
  },
  {
    spanish: "El autobús",
    english: "The bus",
    type: "noun",
    contextExample: "Large vehicle for multiple passengers"
  },
  {
    spanish: "El tren",
    english: "The train",
    type: "noun",
    contextExample: "Vehicle that runs on tracks"
  },
  {
    spanish: "El avión",
    english: "The airplane",
    type: "noun",
    contextExample: "Flying vehicle with wings"
  },
  {
    spanish: "La bicicleta",
    english: "The bicycle",
    type: "noun",
    contextExample: "Two-wheeled vehicle powered by pedaling"
  },
  {
    spanish: "El barco",
    english: "The boat",
    type: "noun",
    contextExample: "Vehicle that travels on water"
  },
  {
    spanish: "El metro",
    english: "The subway",
    type: "noun",
    contextExample: "Underground train system"
  },
  {
    spanish: "El taxi",
    english: "The taxi",
    type: "noun",
    contextExample: "Car that can be hired with a driver"
  },
  {
    spanish: "Conducir",
    english: "To drive",
    type: "verb",
    contextExample: "To operate a vehicle"
  },
  {
    spanish: "Viajar",
    english: "To travel",
    type: "verb",
    contextExample: "To go from one place to another"
  },
  {
    spanish: "La estación",
    english: "The station",
    type: "noun",
    contextExample: "Place where trains or buses stop"
  },
  {
    spanish: "El aeropuerto",
    english: "The airport",
    type: "noun",
    contextExample: "Place where airplanes land and take off"
  },
  {
    spanish: "El boleto / El billete",
    english: "The ticket",
    type: "noun",
    contextExample: "Permit to travel on public transport"
  },
  {
    spanish: "La parada",
    english: "The stop",
    type: "noun",
    contextExample: "Place where buses or trams stop"
  },
  // Additional transportation vocabulary
  {
    spanish: "La motocicleta",
    english: "The motorcycle",
    type: "noun",
    contextExample: "Two-wheeled motor vehicle"
  },
  {
    spanish: "El helicóptero",
    english: "The helicopter",
    type: "noun",
    contextExample: "Aircraft with rotating blades"
  },
  {
    spanish: "El pasajero",
    english: "The passenger",
    type: "noun",
    contextExample: "Person traveling in a vehicle"
  },
  {
    spanish: "El camión",
    english: "The truck",
    type: "noun",
    contextExample: "Large vehicle for transporting goods"
  },
  {
    spanish: "El conductor",
    english: "The driver",
    type: "noun",
    contextExample: "Person who operates a vehicle"
  },
  // Transportation-related greetings and phrases
  {
    spanish: "¿Cómo vas al trabajo?",
    english: "How do you get to work?",
    type: "greeting",
    contextExample: "Asking about someone's commute",
    contextual: true
  },
  {
    spanish: "Voy en autobús",
    english: "I go by bus",
    type: "greeting",
    contextExample: "Describing transportation mode"
  },
  {
    spanish: "¿A qué hora sale el tren?",
    english: "What time does the train leave?",
    type: "greeting",
    contextExample: "Asking about a train schedule",
    contextual: true
  },
  {
    spanish: "Necesito un taxi",
    english: "I need a taxi",
    type: "greeting",
    contextExample: "Requesting transportation"
  },
  {
    spanish: "El avión está retrasado",
    english: "The plane is delayed",
    type: "greeting",
    contextExample: "Discussing a travel situation"
  }
];

// Level 19: Travel and Directions - 25 vocabulary items with greetings
const level19Vocabulary: VocabularyWord[] = [
  {
    spanish: "El viaje",
    english: "The trip/journey",
    type: "noun",
    contextExample: "An act of traveling"
  },
  {
    spanish: "El mapa",
    english: "The map",
    type: "noun",
    contextExample: "Representation of an area"
  },
  {
    spanish: "La dirección",
    english: "The direction/address",
    type: "noun",
    contextExample: "The way to go or location details"
  },
  {
    spanish: "Norte",
    english: "North",
    type: "direction",
    contextExample: "Direction toward the North Pole"
  },
  {
    spanish: "Sur",
    english: "South",
    type: "direction",
    contextExample: "Direction toward the South Pole"
  },
  {
    spanish: "Este",
    english: "East",
    type: "direction",
    contextExample: "Direction toward where the sun rises"
  },
  {
    spanish: "Oeste",
    english: "West",
    type: "direction",
    contextExample: "Direction toward where the sun sets"
  },
  {
    spanish: "Derecha",
    english: "Right",
    type: "direction",
    contextExample: "Direction to the right side"
  },
  {
    spanish: "Izquierda",
    english: "Left",
    type: "direction",
    contextExample: "Direction to the left side"
  },
  {
    spanish: "Recto",
    english: "Straight ahead",
    type: "direction",
    contextExample: "Direction forward without turning"
  },
  {
    spanish: "La calle",
    english: "The street",
    type: "noun",
    contextExample: "Road in a city or town"
  },
  {
    spanish: "La avenida",
    english: "The avenue",
    type: "noun",
    contextExample: "Wide road in a city or town"
  },
  {
    spanish: "El semáforo",
    english: "The traffic light",
    type: "noun",
    contextExample: "Signal to control traffic"
  },
  {
    spanish: "¿Dónde está...?",
    english: "Where is...?",
    type: "question",
    contextExample: "Asking for the location of something"
  },
  {
    spanish: "¿Cómo llego a...?",
    english: "How do I get to...?",
    type: "question",
    contextExample: "Asking for directions"
  },
  // Additional travel and directions vocabulary
  {
    spanish: "El destino",
    english: "The destination",
    type: "noun",
    contextExample: "Place where someone is going"
  },
  {
    spanish: "La esquina",
    english: "The corner",
    type: "noun",
    contextExample: "Where two streets meet"
  },
  {
    spanish: "El cruce",
    english: "The intersection",
    type: "noun",
    contextExample: "Where roads cross"
  },
  {
    spanish: "La rotonda",
    english: "The roundabout",
    type: "noun",
    contextExample: "Circular junction"
  },
  {
    spanish: "El turista",
    english: "The tourist",
    type: "noun",
    contextExample: "Person traveling for pleasure"
  },
  // Travel and directions-related greetings and phrases
  {
    spanish: "Estoy perdido/a",
    english: "I am lost",
    type: "greeting",
    contextExample: "When you don't know where you are"
  },
  {
    spanish: "¿Puedes ayudarme a encontrar...?",
    english: "Can you help me find...?",
    type: "greeting",
    contextExample: "Asking for help with directions",
    contextual: true
  },
  {
    spanish: "Gira a la derecha",
    english: "Turn right",
    type: "greeting",
    contextExample: "Giving directions"
  },
  {
    spanish: "Sigue todo recto",
    english: "Go straight ahead",
    type: "greeting",
    contextExample: "Giving directions"
  },
  {
    spanish: "¿Está lejos de aquí?",
    english: "Is it far from here?",
    type: "greeting",
    contextExample: "Asking about distance",
    contextual: true
  }
];

// Level 20: Sports and Games - 25 vocabulary items with greetings
const level20Vocabulary: VocabularyWord[] = [
  {
    spanish: "El deporte",
    english: "The sport",
    type: "noun",
    contextExample: "Physical activity involving competition"
  },
  {
    spanish: "El juego",
    english: "The game",
    type: "noun",
    contextExample: "Activity for entertainment or competition"
  },
  {
    spanish: "El fútbol",
    english: "Soccer/Football",
    type: "sport",
    contextExample: "Game played with a ball kicked by foot"
  },
  {
    spanish: "El baloncesto",
    english: "Basketball",
    type: "sport",
    contextExample: "Game with a ball and hoop"
  },
  {
    spanish: "El tenis",
    english: "Tennis",
    type: "sport",
    contextExample: "Game played with rackets and a ball"
  },
  {
    spanish: "La natación",
    english: "Swimming",
    type: "sport",
    contextExample: "Sport of moving through water"
  },
  {
    spanish: "El béisbol",
    english: "Baseball",
    type: "sport",
    contextExample: "Game with a bat and ball"
  },
  {
    spanish: "El voleibol",
    english: "Volleyball",
    type: "sport",
    contextExample: "Game with a ball over a net"
  },
  {
    spanish: "Correr",
    english: "To run",
    type: "verb",
    contextExample: "To move quickly on foot"
  },
  {
    spanish: "Nadar",
    english: "To swim",
    type: "verb",
    contextExample: "To move through water"
  },
  {
    spanish: "Jugar",
    english: "To play",
    type: "verb",
    contextExample: "To engage in a game or sport"
  },
  {
    spanish: "Ganar",
    english: "To win",
    type: "verb",
    contextExample: "To be victorious"
  },
  {
    spanish: "Perder",
    english: "To lose",
    type: "verb",
    contextExample: "To be defeated"
  },
  {
    spanish: "El equipo",
    english: "The team",
    type: "noun",
    contextExample: "Group playing together in a sport"
  },
  {
    spanish: "La competencia",
    english: "The competition",
    type: "noun",
    contextExample: "Contest to determine a winner"
  },
  // Additional sports vocabulary
  {
    spanish: "El gol",
    english: "The goal",
    type: "noun",
    contextExample: "Point scored in soccer/football"
  },
  {
    spanish: "La cancha",
    english: "The court/field",
    type: "noun",
    contextExample: "Area where sports are played"
  },
  {
    spanish: "El arbitro",
    english: "The referee",
    type: "noun",
    contextExample: "Person who enforces the rules in a game"
  },
  {
    spanish: "El ciclismo",
    english: "Cycling",
    type: "sport",
    contextExample: "Sport of riding bicycles"
  },
  {
    spanish: "El partido",
    english: "The match/game",
    type: "noun",
    contextExample: "Contest between teams or individuals"
  },
  // Sports-related greetings and phrases
  {
    spanish: "¡Buen partido!",
    english: "Good game!",
    type: "greeting",
    contextExample: "Congratulating on a well-played game"
  },
  {
    spanish: "¿Qué deportes practicas?",
    english: "What sports do you play?",
    type: "greeting",
    contextExample: "Asking about someone's athletic activities",
    contextual: true
  },
  {
    spanish: "Juego al fútbol los domingos",
    english: "I play soccer on Sundays",
    type: "greeting",
    contextExample: "Talking about regular sports activities"
  },
  {
    spanish: "¿Quién ganó el partido?",
    english: "Who won the game?",
    type: "greeting",
    contextExample: "Asking about sports results",
    contextual: true
  },
  {
    spanish: "Mi equipo favorito es...",
    english: "My favorite team is...",
    type: "greeting",
    contextExample: "Expressing preference for a sports team"
  }
];

// Level 21: Music & Art - 25 vocabulary items with greetings
const level21Vocabulary: VocabularyWord[] = [
  {
    spanish: "La música",
    english: "Music",
    type: "noun",
    contextExample: "Art form with sound"
  },
  {
    spanish: "El arte",
    english: "Art",
    type: "noun",
    contextExample: "Expression of creativity"
  },
  {
    spanish: "La canción",
    english: "The song",
    type: "noun",
    contextExample: "Musical composition with vocals"
  },
  {
    spanish: "El/La cantante",
    english: "The singer",
    type: "noun",
    contextExample: "Person who sings"
  },
  {
    spanish: "El/La músico/a",
    english: "The musician",
    type: "noun",
    contextExample: "Person who plays music"
  },
  {
    spanish: "El instrumento",
    english: "The instrument",
    type: "noun",
    contextExample: "Device to produce musical sounds"
  },
  {
    spanish: "La guitarra",
    english: "The guitar",
    type: "noun",
    contextExample: "Stringed musical instrument"
  },
  {
    spanish: "El piano",
    english: "The piano",
    type: "noun",
    contextExample: "Keyboard musical instrument"
  },
  {
    spanish: "La batería",
    english: "The drums",
    type: "noun",
    contextExample: "Percussion musical instrument"
  },
  {
    spanish: "El/La artista",
    english: "The artist",
    type: "noun",
    contextExample: "Person who creates art"
  },
  {
    spanish: "La pintura",
    english: "The painting",
    type: "noun",
    contextExample: "Art created with paint"
  },
  {
    spanish: "El dibujo",
    english: "The drawing",
    type: "noun",
    contextExample: "Art created with pencil or pen"
  },
  {
    spanish: "El pincel",
    english: "The paintbrush",
    type: "noun",
    contextExample: "Tool for applying paint"
  },
  {
    spanish: "Dibujar",
    english: "To draw",
    type: "verb",
    contextExample: "To create pictures with pencil or pen"
  },
  {
    spanish: "Pintar",
    english: "To paint",
    type: "verb",
    contextExample: "To apply color with a brush"
  },
  // Additional music & art vocabulary
  {
    spanish: "El concierto",
    english: "The concert",
    type: "noun",
    contextExample: "Musical performance before an audience"
  },
  {
    spanish: "La escultura",
    english: "The sculpture",
    type: "noun",
    contextExample: "Three-dimensional artwork"
  },
  {
    spanish: "El museo",
    english: "The museum",
    type: "noun",
    contextExample: "Building displaying art or artifacts"
  },
  {
    spanish: "La galería",
    english: "The gallery",
    type: "noun",
    contextExample: "Place to display art"
  },
  {
    spanish: "La fotografía",
    english: "The photography",
    type: "noun",
    contextExample: "Art of taking pictures"
  },
  // Music & art-related greetings and phrases
  {
    spanish: "¿Qué tipo de música te gusta?",
    english: "What kind of music do you like?",
    type: "greeting",
    contextExample: "Asking about music preferences",
    contextual: true
  },
  {
    spanish: "Me encanta esta canción",
    english: "I love this song",
    type: "greeting",
    contextExample: "Expressing appreciation for music"
  },
  {
    spanish: "¿Tocas algún instrumento?",
    english: "Do you play any instrument?",
    type: "greeting",
    contextExample: "Asking about musical abilities",
    contextual: true
  },
  {
    spanish: "Este cuadro es hermoso",
    english: "This painting is beautiful",
    type: "greeting",
    contextExample: "Commenting on artwork"
  },
  {
    spanish: "Vamos a un concierto",
    english: "Let's go to a concert",
    type: "greeting",
    contextExample: "Suggesting a music outing"
  }
];

// Level 22: Getting Around - 25 vocabulary items with greetings
const level22Vocabulary: VocabularyWord[] = [
  {
    spanish: "El coche / El carro",
    english: "The car",
    type: "noun",
    contextExample: "Vehicle with four wheels"
  },
  {
    spanish: "El autobús",
    english: "The bus",
    type: "noun",
    contextExample: "Large vehicle for public transport"
  },
  {
    spanish: "El tren",
    english: "The train",
    type: "noun",
    contextExample: "Vehicle that runs on rails"
  },
  {
    spanish: "La bicicleta",
    english: "The bicycle",
    type: "noun",
    contextExample: "Two-wheeled vehicle powered by pedaling"
  },
  {
    spanish: "El avión",
    english: "The airplane",
    type: "noun",
    contextExample: "Flying vehicle with wings"
  },
  {
    spanish: "El barco",
    english: "The boat",
    type: "noun",
    contextExample: "Vehicle that travels on water"
  },
  {
    spanish: "El metro",
    english: "The subway",
    type: "noun",
    contextExample: "Underground train system"
  },
  {
    spanish: "El taxi",
    english: "The taxi",
    type: "noun",
    contextExample: "Car that can be hired with a driver"
  },
  {
    spanish: "La parada",
    english: "The stop",
    type: "noun",
    contextExample: "Place where buses stop"
  },
  {
    spanish: "La estación",
    english: "The station",
    type: "noun",
    contextExample: "Place for trains or buses"
  },
  {
    spanish: "El aeropuerto",
    english: "The airport",
    type: "noun",
    contextExample: "Place for airplanes"
  },
  {
    spanish: "La calle",
    english: "The street",
    type: "noun",
    contextExample: "Public road in a city"
  },
  {
    spanish: "El camino",
    english: "The road/path",
    type: "noun",
    contextExample: "Route for traveling"
  },
  {
    spanish: "El mapa",
    english: "The map",
    type: "noun",
    contextExample: "Representation of an area"
  },
  {
    spanish: "Viajar",
    english: "To travel",
    type: "verb",
    contextExample: "To go from one place to another"
  },
  // Additional transportation vocabulary
  {
    spanish: "Conducir",
    english: "To drive",
    type: "verb",
    contextExample: "To operate a vehicle"
  },
  {
    spanish: "Caminar",
    english: "To walk",
    type: "verb",
    contextExample: "To move on foot"
  },
  {
    spanish: "El boleto / El billete",
    english: "The ticket",
    type: "noun",
    contextExample: "Document allowing travel"
  },
  {
    spanish: "La maleta",
    english: "The suitcase",
    type: "noun",
    contextExample: "Container for traveling clothes"
  },
  {
    spanish: "El semáforo",
    english: "The traffic light",
    type: "noun",
    contextExample: "Signal controlling traffic"
  },
  // Transportation-related greetings and phrases
  {
    spanish: "¿Cómo llegas a la escuela?",
    english: "How do you get to school?",
    type: "greeting",
    contextExample: "Asking about transportation method",
    contextual: true
  },
  {
    spanish: "Voy en autobús",
    english: "I go by bus",
    type: "greeting",
    contextExample: "Describing transportation method"
  },
  {
    spanish: "¿Dónde está la parada del autobús?",
    english: "Where is the bus stop?",
    type: "greeting",
    contextExample: "Asking for directions",
    contextual: true
  },
  {
    spanish: "¿A qué hora sale el tren?",
    english: "What time does the train leave?",
    type: "greeting",
    contextExample: "Asking about schedules"
  },
  {
    spanish: "Necesito un taxi",
    english: "I need a taxi",
    type: "greeting",
    contextExample: "Requesting transportation"
  }
];

// Level 23: Occupations - 25 vocabulary items with greetings
const level23Vocabulary: VocabularyWord[] = [
  {
    spanish: "El trabajo",
    english: "The job/work",
    type: "noun",
    contextExample: "Employment or occupation"
  },
  {
    spanish: "La profesión",
    english: "The profession",
    type: "noun",
    contextExample: "Type of work requiring training"
  },
  {
    spanish: "El médico / La médica",
    english: "The doctor",
    type: "occupation",
    contextExample: "Person who treats illness"
  },
  {
    spanish: "El profesor / La profesora",
    english: "The teacher",
    type: "occupation",
    contextExample: "Person who educates"
  },
  {
    spanish: "El ingeniero / La ingeniera",
    english: "The engineer",
    type: "occupation",
    contextExample: "Person who designs and builds"
  },
  {
    spanish: "El abogado / La abogada",
    english: "The lawyer",
    type: "occupation",
    contextExample: "Person who practices law"
  },
  {
    spanish: "El enfermero / La enfermera",
    english: "The nurse",
    type: "occupation",
    contextExample: "Person who cares for the sick"
  },
  {
    spanish: "El bombero / La bombera",
    english: "The firefighter",
    type: "occupation",
    contextExample: "Person who fights fires"
  },
  {
    spanish: "El policía / La policía",
    english: "The police officer",
    type: "occupation",
    contextExample: "Person who enforces the law"
  },
  {
    spanish: "El cocinero / La cocinera",
    english: "The cook/chef",
    type: "occupation",
    contextExample: "Person who prepares food"
  },
  {
    spanish: "El artista / La artista",
    english: "The artist",
    type: "occupation",
    contextExample: "Person who creates art"
  },
  {
    spanish: "El músico / La música",
    english: "The musician",
    type: "occupation",
    contextExample: "Person who plays music"
  },
  {
    spanish: "El escritor / La escritora",
    english: "The writer",
    type: "occupation",
    contextExample: "Person who writes books or articles"
  },
  {
    spanish: "Trabajar",
    english: "To work",
    type: "verb",
    contextExample: "To be employed"
  },
  {
    spanish: "¿En qué trabajas?",
    english: "What do you do for work?",
    type: "question",
    contextExample: "Asking about occupation"
  },
  // Additional occupation vocabulary
  {
    spanish: "El arquitecto / La arquitecta",
    english: "The architect",
    type: "occupation",
    contextExample: "Person who designs buildings"
  },
  {
    spanish: "El electricista",
    english: "The electrician",
    type: "occupation",
    contextExample: "Person who works with electrical systems"
  },
  {
    spanish: "El carpintero / La carpintera",
    english: "The carpenter",
    type: "occupation",
    contextExample: "Person who works with wood"
  },
  {
    spanish: "El empresario / La empresaria",
    english: "The businessman/businesswoman",
    type: "occupation",
    contextExample: "Person who owns or manages a business"
  },
  {
    spanish: "La oficina",
    english: "The office",
    type: "noun",
    contextExample: "Place of business"
  },
  // Occupation-related greetings and phrases
  {
    spanish: "Soy [profesión]",
    english: "I am a [profession]",
    type: "greeting",
    contextExample: "Stating your occupation"
  },
  {
    spanish: "¿Cuál es tu profesión?",
    english: "What is your profession?",
    type: "greeting",
    contextExample: "Asking about someone's job",
    contextual: true
  },
  {
    spanish: "Trabajo como [profesión]",
    english: "I work as a [profession]",
    type: "greeting",
    contextExample: "Describing your job"
  },
  {
    spanish: "¿Dónde trabajas?",
    english: "Where do you work?",
    type: "greeting",
    contextExample: "Asking about workplace",
    contextual: true
  },
  {
    spanish: "Me gusta mi trabajo",
    english: "I like my job",
    type: "greeting",
    contextExample: "Expressing job satisfaction"
  }
];

// Level 24: Travel Vocabulary - 25 vocabulary items with greetings
const level24Vocabulary: VocabularyWord[] = [
  {
    spanish: "El viaje",
    english: "The trip/journey",
    type: "noun",
    contextExample: "Travel from one place to another"
  },
  {
    spanish: "El destino",
    english: "The destination",
    type: "noun",
    contextExample: "Place to which one is traveling"
  },
  {
    spanish: "El pasaporte",
    english: "The passport",
    type: "noun",
    contextExample: "Official document for international travel"
  },
  {
    spanish: "La maleta",
    english: "The suitcase",
    type: "noun",
    contextExample: "Container for traveling clothes"
  },
  {
    spanish: "El hotel",
    english: "The hotel",
    type: "noun",
    contextExample: "Place for temporary lodging"
  },
  {
    spanish: "La reserva",
    english: "The reservation",
    type: "noun",
    contextExample: "Arrangement to hold accommodations"
  },
  {
    spanish: "El turista",
    english: "The tourist",
    type: "noun",
    contextExample: "Person who travels for pleasure"
  },
  {
    spanish: "La playa",
    english: "The beach",
    type: "noun",
    contextExample: "Sandy shore by water"
  },
  {
    spanish: "El monumento",
    english: "The monument",
    type: "noun",
    contextExample: "Structure built to commemorate"
  },
  {
    spanish: "El museo",
    english: "The museum",
    type: "noun",
    contextExample: "Building displaying artifacts"
  },
  {
    spanish: "La excursión",
    english: "The excursion/tour",
    type: "noun",
    contextExample: "Short journey for pleasure"
  },
  {
    spanish: "El guía turístico",
    english: "The tour guide",
    type: "noun",
    contextExample: "Person who shows tourists around"
  },
  {
    spanish: "La moneda",
    english: "The currency",
    type: "noun",
    contextExample: "System of money"
  },
  {
    spanish: "Viajar",
    english: "To travel",
    type: "verb",
    contextExample: "To make a journey"
  },
  {
    spanish: "Reservar",
    english: "To book/reserve",
    type: "verb",
    contextExample: "To arrange for accommodations"
  },
  // Additional travel vocabulary
  {
    spanish: "La frontera",
    english: "The border",
    type: "noun",
    contextExample: "Boundary between countries"
  },
  {
    spanish: "El equipaje",
    english: "The luggage",
    type: "noun",
    contextExample: "Bags and suitcases for travel"
  },
  {
    spanish: "El mapa",
    english: "The map",
    type: "noun",
    contextExample: "Representation of an area"
  },
  {
    spanish: "La guía",
    english: "The guidebook",
    type: "noun",
    contextExample: "Book with tourist information"
  },
  {
    spanish: "El alojamiento",
    english: "The accommodation",
    type: "noun",
    contextExample: "Place to stay while traveling"
  },
  // Travel-related greetings and phrases
  {
    spanish: "¿Dónde está el hotel?",
    english: "Where is the hotel?",
    type: "greeting",
    contextExample: "Asking for directions to accommodation",
    contextual: true
  },
  {
    spanish: "Necesito hacer una reserva",
    english: "I need to make a reservation",
    type: "greeting",
    contextExample: "Requesting accommodation booking"
  },
  {
    spanish: "¿Cuánto cuesta un boleto a...?",
    english: "How much is a ticket to...?",
    type: "greeting",
    contextExample: "Asking about travel costs",
    contextual: true
  },
  {
    spanish: "Me gustaría visitar...",
    english: "I would like to visit...",
    type: "greeting",
    contextExample: "Expressing travel desires"
  },
  {
    spanish: "¿Qué lugares recomiendas visitar?",
    english: "What places do you recommend visiting?",
    type: "greeting",
    contextExample: "Asking for travel recommendations",
    contextual: true
  }
];

// Level 25: Classroom Vocabulary - 25 vocabulary items with greetings
const level25Vocabulary: VocabularyWord[] = [
  {
    spanish: "La clase",
    english: "The class",
    type: "noun",
    contextExample: "Group of students learning together"
  },
  {
    spanish: "El aula",
    english: "The classroom",
    type: "noun",
    contextExample: "Room where students learn"
  },
  {
    spanish: "El pupitre",
    english: "The desk",
    type: "noun",
    contextExample: "Table for a student"
  },
  {
    spanish: "La silla",
    english: "The chair",
    type: "noun",
    contextExample: "Seat for sitting"
  },
  {
    spanish: "El pizarrón / La pizarra",
    english: "The board",
    type: "noun",
    contextExample: "Surface for writing in front of class"
  },
  {
    spanish: "La tiza",
    english: "The chalk",
    type: "noun",
    contextExample: "Tool for writing on blackboard"
  },
  {
    spanish: "El marcador",
    english: "The marker",
    type: "noun",
    contextExample: "Tool for writing on whiteboard"
  },
  {
    spanish: "El lápiz",
    english: "The pencil",
    type: "noun",
    contextExample: "Writing instrument with lead"
  },
  {
    spanish: "El bolígrafo / La pluma",
    english: "The pen",
    type: "noun",
    contextExample: "Writing instrument with ink"
  },
  {
    spanish: "El cuaderno",
    english: "The notebook",
    type: "noun",
    contextExample: "Book of blank paper for notes"
  },
  {
    spanish: "El libro",
    english: "The book",
    type: "noun",
    contextExample: "Printed publication with pages"
  },
  {
    spanish: "La mochila",
    english: "The backpack",
    type: "noun",
    contextExample: "Bag for carrying school supplies"
  },
  {
    spanish: "El/La profesor/a",
    english: "The teacher",
    type: "noun",
    contextExample: "Person who teaches students"
  },
  {
    spanish: "El/La estudiante",
    english: "The student",
    type: "noun",
    contextExample: "Person who attends school"
  },
  {
    spanish: "La tarea",
    english: "The homework",
    type: "noun",
    contextExample: "Work assigned to do at home"
  },
  // Additional classroom vocabulary
  {
    spanish: "El borrador",
    english: "The eraser",
    type: "noun",
    contextExample: "Tool for removing writing"
  },
  {
    spanish: "Las tijeras",
    english: "The scissors",
    type: "noun",
    contextExample: "Tool for cutting paper"
  },
  {
    spanish: "La regla",
    english: "The ruler",
    type: "noun",
    contextExample: "Tool for measuring and drawing lines"
  },
  {
    spanish: "El pegamento",
    english: "The glue",
    type: "noun",
    contextExample: "Substance for sticking things together"
  },
  {
    spanish: "El sacapuntas",
    english: "The pencil sharpener",
    type: "noun",
    contextExample: "Tool for sharpening pencils"
  },
  // Classroom-related greetings and phrases
  {
    spanish: "¿Puedo ir al baño?",
    english: "May I go to the bathroom?",
    type: "greeting",
    contextExample: "Asking for permission in class",
    contextual: true
  },
  {
    spanish: "Levanta la mano",
    english: "Raise your hand",
    type: "greeting",
    contextExample: "Classroom instruction"
  },
  {
    spanish: "¿Puedes repetir, por favor?",
    english: "Can you repeat, please?",
    type: "greeting",
    contextExample: "Asking for clarification",
    contextual: true
  },
  {
    spanish: "Abre tu libro en la página...",
    english: "Open your book to page...",
    type: "greeting",
    contextExample: "Classroom instruction"
  },
  {
    spanish: "No entiendo",
    english: "I don't understand",
    type: "greeting",
    contextExample: "Expressing confusion in class"
  }
];

// Level 26: School Subjects - 25 vocabulary items with greetings
const level26Vocabulary: VocabularyWord[] = [
  {
    spanish: "Las matemáticas",
    english: "Mathematics",
    type: "noun",
    contextExample: "Study of numbers and calculations"
  },
  {
    spanish: "La ciencia",
    english: "Science",
    type: "noun",
    contextExample: "Study of the natural world"
  },
  {
    spanish: "La historia",
    english: "History",
    type: "noun",
    contextExample: "Study of past events"
  },
  {
    spanish: "La geografía",
    english: "Geography",
    type: "noun",
    contextExample: "Study of the Earth's surface"
  },
  {
    spanish: "El inglés",
    english: "English",
    type: "noun",
    contextExample: "Study of the English language"
  },
  {
    spanish: "El español",
    english: "Spanish",
    type: "noun",
    contextExample: "Study of the Spanish language"
  },
  {
    spanish: "La literatura",
    english: "Literature",
    type: "noun",
    contextExample: "Study of written works"
  },
  {
    spanish: "La música",
    english: "Music",
    type: "noun",
    contextExample: "Study of sound and composition"
  },
  {
    spanish: "El arte",
    english: "Art",
    type: "noun",
    contextExample: "Study of visual expression"
  },
  {
    spanish: "La educación física",
    english: "Physical Education",
    type: "noun",
    contextExample: "Study of physical activity and sports"
  },
  {
    spanish: "La biología",
    english: "Biology",
    type: "noun",
    contextExample: "Study of living organisms"
  },
  {
    spanish: "La química",
    english: "Chemistry",
    type: "noun",
    contextExample: "Study of substances and their properties"
  },
  {
    spanish: "La física",
    english: "Physics",
    type: "noun",
    contextExample: "Study of matter and energy"
  },
  {
    spanish: "La computación / La informática",
    english: "Computer Science",
    type: "noun",
    contextExample: "Study of computers and programming"
  },
  {
    spanish: "La economía",
    english: "Economics",
    type: "noun",
    contextExample: "Study of production and consumption"
  },
  // Additional school subjects vocabulary
  {
    spanish: "La filosofía",
    english: "Philosophy",
    type: "noun",
    contextExample: "Study of knowledge and existence"
  },
  {
    spanish: "La psicología",
    english: "Psychology",
    type: "noun",
    contextExample: "Study of the mind and behavior"
  },
  {
    spanish: "La sociología",
    english: "Sociology",
    type: "noun",
    contextExample: "Study of society and social relations"
  },
  {
    spanish: "El álgebra",
    english: "Algebra",
    type: "noun",
    contextExample: "Branch of mathematics with variables"
  },
  {
    spanish: "La geometría",
    english: "Geometry",
    type: "noun",
    contextExample: "Study of shapes and their properties"
  },
  // School subjects-related greetings and phrases
  {
    spanish: "¿Cuál es tu materia favorita?",
    english: "What is your favorite subject?",
    type: "greeting",
    contextExample: "Asking about subject preferences",
    contextual: true
  },
  {
    spanish: "Me gusta mucho la ciencia",
    english: "I really like science",
    type: "greeting",
    contextExample: "Expressing subject preference"
  },
  {
    spanish: "¿A qué hora tienes matemáticas?",
    english: "What time do you have math?",
    type: "greeting",
    contextExample: "Asking about class schedule",
    contextual: true
  },
  {
    spanish: "Tengo que estudiar para el examen de historia",
    english: "I have to study for the history exam",
    type: "greeting",
    contextExample: "Talking about studying"
  },
  {
    spanish: "El profesor de ciencias es muy bueno",
    english: "The science teacher is very good",
    type: "greeting",
    contextExample: "Commenting on a teacher"
  }
];

// Level 27: Academic Activities - 25 vocabulary items with greetings
const level27Vocabulary: VocabularyWord[] = [
  {
    spanish: "Estudiar",
    english: "To study",
    type: "verb",
    contextExample: "To acquire knowledge through learning"
  },
  {
    spanish: "Aprender",
    english: "To learn",
    type: "verb",
    contextExample: "To gain knowledge or skill"
  },
  {
    spanish: "Leer",
    english: "To read",
    type: "verb",
    contextExample: "To look at and understand written words"
  },
  {
    spanish: "Escribir",
    english: "To write",
    type: "verb",
    contextExample: "To form letters or words on a surface"
  },
  {
    spanish: "La lectura",
    english: "Reading",
    type: "noun",
    contextExample: "Activity of understanding written words"
  },
  {
    spanish: "La escritura",
    english: "Writing",
    type: "noun",
    contextExample: "Activity of forming words on paper"
  },
  {
    spanish: "El examen",
    english: "The exam/test",
    type: "noun",
    contextExample: "Assessment of knowledge"
  },
  {
    spanish: "La prueba",
    english: "The quiz/test",
    type: "noun",
    contextExample: "Short assessment"
  },
  {
    spanish: "La tarea",
    english: "The homework",
    type: "noun",
    contextExample: "Work assigned to do at home"
  },
  {
    spanish: "El proyecto",
    english: "The project",
    type: "noun",
    contextExample: "Major assignment requiring time and effort"
  },
  {
    spanish: "La investigación",
    english: "The research",
    type: "noun",
    contextExample: "Systematic study to establish facts"
  },
  {
    spanish: "La presentación",
    english: "The presentation",
    type: "noun",
    contextExample: "Act of showing work to an audience"
  },
  {
    spanish: "Tomar apuntes",
    english: "To take notes",
    type: "phrase",
    contextExample: "To write down important information"
  },
  {
    spanish: "Hacer la tarea",
    english: "To do homework",
    type: "phrase",
    contextExample: "To complete assignments at home"
  },
  {
    spanish: "Preguntar",
    english: "To ask a question",
    type: "verb",
    contextExample: "To request information"
  },
  // Additional academic vocabulary
  {
    spanish: "El ensayo",
    english: "The essay",
    type: "noun",
    contextExample: "Short piece of writing on a subject"
  },
  {
    spanish: "La biblioteca",
    english: "The library",
    type: "noun",
    contextExample: "Place with collection of books"
  },
  {
    spanish: "El diccionario",
    english: "The dictionary",
    type: "noun",
    contextExample: "Book of word definitions"
  },
  {
    spanish: "El resumen",
    english: "The summary",
    type: "noun",
    contextExample: "Brief statement of main points"
  },
  {
    spanish: "La calificación / La nota",
    english: "The grade",
    type: "noun",
    contextExample: "Mark indicating level of performance"
  },
  // Academic activity-related greetings and phrases
  {
    spanish: "¿Puedes ayudarme con la tarea?",
    english: "Can you help me with the homework?",
    type: "greeting",
    contextExample: "Asking for help with assignments",
    contextual: true
  },
  {
    spanish: "Voy a estudiar para el examen",
    english: "I'm going to study for the exam",
    type: "greeting",
    contextExample: "Discussing study plans"
  },
  {
    spanish: "¿Entiendes la lección?",
    english: "Do you understand the lesson?",
    type: "greeting",
    contextExample: "Checking for comprehension",
    contextual: true
  },
  {
    spanish: "He terminado mi proyecto",
    english: "I have finished my project",
    type: "greeting",
    contextExample: "Stating completion of work"
  },
  {
    spanish: "¿Cuándo es la fecha de entrega?",
    english: "When is the due date?",
    type: "greeting",
    contextExample: "Asking about deadline",
    contextual: true
  }
];

// Level 28: Arts and Entertainment - 25 vocabulary items with greetings
const level28Vocabulary: VocabularyWord[] = [
  {
    spanish: "El arte",
    english: "Art",
    type: "noun",
    contextExample: "Expression of human creativity"
  },
  {
    spanish: "El entretenimiento",
    english: "Entertainment",
    type: "noun",
    contextExample: "Activities providing enjoyment"
  },
  {
    spanish: "La música",
    english: "Music",
    type: "noun",
    contextExample: "Art form with sound"
  },
  {
    spanish: "El cine",
    english: "Cinema/Movies",
    type: "noun",
    contextExample: "Films as an art form"
  },
  {
    spanish: "La película",
    english: "The movie/film",
    type: "noun",
    contextExample: "Motion picture"
  },
  {
    spanish: "El teatro",
    english: "The theater",
    type: "noun",
    contextExample: "Place for performing arts"
  },
  {
    spanish: "El concierto",
    english: "The concert",
    type: "noun",
    contextExample: "Musical performance"
  },
  {
    spanish: "La pintura",
    english: "The painting",
    type: "noun",
    contextExample: "Art created with paint"
  },
  {
    spanish: "La fotografía",
    english: "Photography",
    type: "noun",
    contextExample: "Art of taking pictures"
  },
  {
    spanish: "El museo",
    english: "The museum",
    type: "noun",
    contextExample: "Building displaying art or artifacts"
  },
  {
    spanish: "La galería",
    english: "The gallery",
    type: "noun",
    contextExample: "Place to display art"
  },
  {
    spanish: "El/La artista",
    english: "The artist",
    type: "noun",
    contextExample: "Person who creates art"
  },
  {
    spanish: "El/La actor/actriz",
    english: "The actor/actress",
    type: "noun",
    contextExample: "Person who performs in films or plays"
  },
  {
    spanish: "El/La director/a",
    english: "The director",
    type: "noun",
    contextExample: "Person who supervises a film or play"
  },
  {
    spanish: "Crear",
    english: "To create",
    type: "verb",
    contextExample: "To make something new"
  },
  // Additional arts vocabulary
  {
    spanish: "La escultura",
    english: "The sculpture",
    type: "noun",
    contextExample: "Three-dimensional artwork"
  },
  {
    spanish: "El dibujo",
    english: "The drawing",
    type: "noun",
    contextExample: "Picture created with pencil, pen, etc."
  },
  {
    spanish: "La obra de teatro",
    english: "The play",
    type: "noun",
    contextExample: "Theatrical performance"
  },
  {
    spanish: "La exposición",
    english: "The exhibition",
    type: "noun",
    contextExample: "Public display of art or other items"
  },
  {
    spanish: "El/La espectador/a",
    english: "The spectator/viewer",
    type: "noun",
    contextExample: "Person who watches a performance or event"
  },
  // Arts-related greetings and phrases
  {
    spanish: "¿Te gusta el arte?",
    english: "Do you like art?",
    type: "greeting",
    contextExample: "Asking about interest in art",
    contextual: true
  },
  {
    spanish: "Vamos al cine",
    english: "Let's go to the movies",
    type: "greeting",
    contextExample: "Suggesting a movie outing"
  },
  {
    spanish: "¿Qué tipo de música te gusta?",
    english: "What kind of music do you like?",
    type: "greeting",
    contextExample: "Asking about music preferences",
    contextual: true
  },
  {
    spanish: "La película estuvo interesante",
    english: "The movie was interesting",
    type: "greeting",
    contextExample: "Giving an opinion about a film"
  },
  {
    spanish: "Me encanta esta canción",
    english: "I love this song",
    type: "greeting",
    contextExample: "Expressing fondness for music"
  }
];

// Level 29: Descriptions and Comparisons - 25 vocabulary items with greetings
const level29Vocabulary: VocabularyWord[] = [
  {
    spanish: "Grande",
    english: "Big",
    type: "adjective",
    contextExample: "Large in size"
  },
  {
    spanish: "Pequeño",
    english: "Small",
    type: "adjective",
    contextExample: "Little in size"
  },
  {
    spanish: "Alto",
    english: "Tall/High",
    type: "adjective",
    contextExample: "Of great height"
  },
  {
    spanish: "Bajo",
    english: "Short/Low",
    type: "adjective",
    contextExample: "Of little height"
  },
  {
    spanish: "Largo",
    english: "Long",
    type: "adjective",
    contextExample: "Having great length"
  },
  {
    spanish: "Corto",
    english: "Short",
    type: "adjective",
    contextExample: "Having little length"
  },
  {
    spanish: "Viejo",
    english: "Old",
    type: "adjective",
    contextExample: "Having lived for a long time"
  },
  {
    spanish: "Nuevo",
    english: "New",
    type: "adjective",
    contextExample: "Recently made or created"
  },
  {
    spanish: "Fácil",
    english: "Easy",
    type: "adjective",
    contextExample: "Not difficult"
  },
  {
    spanish: "Difícil",
    english: "Difficult",
    type: "adjective",
    contextExample: "Hard to do or accomplish"
  },
  {
    spanish: "Más",
    english: "More",
    type: "adverb",
    contextExample: "To a greater degree"
  },
  {
    spanish: "Menos",
    english: "Less",
    type: "adverb",
    contextExample: "To a smaller degree"
  },
  {
    spanish: "Que",
    english: "Than",
    type: "conjunction",
    contextExample: "Used in comparisons"
  },
  {
    spanish: "Tan...como",
    english: "As...as",
    type: "phrase",
    contextExample: "Used for equal comparisons"
  },
  {
    spanish: "El/La mejor",
    english: "The best",
    type: "adjective",
    contextExample: "Of the highest quality"
  },
  // Additional descriptive vocabulary
  {
    spanish: "Bonito/a",
    english: "Pretty/Beautiful",
    type: "adjective",
    contextExample: "Pleasing to look at"
  },
  {
    spanish: "Feo/a",
    english: "Ugly",
    type: "adjective",
    contextExample: "Unattractive in appearance"
  },
  {
    spanish: "Rápido",
    english: "Fast",
    type: "adjective",
    contextExample: "Moving or capable of moving quickly"
  },
  {
    spanish: "Lento",
    english: "Slow",
    type: "adjective",
    contextExample: "Moving or operating at low speed"
  },
  {
    spanish: "Interesante",
    english: "Interesting",
    type: "adjective",
    contextExample: "Arousing curiosity or attention"
  },
  // Description-related greetings and phrases
  {
    spanish: "¿Cómo es...?",
    english: "What is...like?",
    type: "greeting",
    contextExample: "Asking for a description",
    contextual: true
  },
  {
    spanish: "Esto es más grande que aquello",
    english: "This is bigger than that",
    type: "greeting",
    contextExample: "Making a comparison"
  },
  {
    spanish: "¿Cuál es mejor?",
    english: "Which one is better?",
    type: "greeting",
    contextExample: "Asking for a comparison",
    contextual: true
  },
  {
    spanish: "Se parece a...",
    english: "It looks like...",
    type: "greeting",
    contextExample: "Making a comparison with something else"
  },
  {
    spanish: "Es el/la más...",
    english: "It is the most...",
    type: "greeting",
    contextExample: "Making a superlative statement"
  }
];

// Level 30: Future Plans and Career Aspirations - 25 vocabulary items with greetings
const level30Vocabulary: VocabularyWord[] = [
  {
    spanish: "El futuro",
    english: "The future",
    type: "noun",
    contextExample: "Time that is to come"
  },
  {
    spanish: "El plan",
    english: "The plan",
    type: "noun",
    contextExample: "Detailed arrangement"
  },
  {
    spanish: "La meta",
    english: "The goal",
    type: "noun",
    contextExample: "Object of effort"
  },
  {
    spanish: "El sueño",
    english: "The dream",
    type: "noun",
    contextExample: "Aspiration or ideal"
  },
  {
    spanish: "La carrera",
    english: "The career",
    type: "noun",
    contextExample: "Profession pursued as a lifework"
  },
  {
    spanish: "La universidad",
    english: "The university",
    type: "noun",
    contextExample: "Institution of higher education"
  },
  {
    spanish: "El título",
    english: "The degree",
    type: "noun",
    contextExample: "Academic qualification"
  },
  {
    spanish: "La experiencia",
    english: "The experience",
    type: "noun",
    contextExample: "Practical knowledge or skill"
  },
  {
    spanish: "La oportunidad",
    english: "The opportunity",
    type: "noun",
    contextExample: "Favorable chance or occasion"
  },
  {
    spanish: "El éxito",
    english: "Success",
    type: "noun",
    contextExample: "Achievement of goals"
  },
  {
    spanish: "Querer",
    english: "To want",
    type: "verb",
    contextExample: "To desire something"
  },
  {
    spanish: "Esperar",
    english: "To hope",
    type: "verb",
    contextExample: "To expect or look forward to"
  },
  {
    spanish: "Planear",
    english: "To plan",
    type: "verb",
    contextExample: "To arrange a method"
  },
  {
    spanish: "Lograr",
    english: "To achieve",
    type: "verb",
    contextExample: "To accomplish something"
  },
  {
    spanish: "¿Qué quieres ser en el futuro?",
    english: "What do you want to be in the future?",
    type: "question",
    contextExample: "Asking about career aspirations"
  },
  // Additional future/career vocabulary
  {
    spanish: "El trabajo",
    english: "The job",
    type: "noun",
    contextExample: "Paid position of employment"
  },
  {
    spanish: "El objetivo",
    english: "The objective",
    type: "noun",
    contextExample: "Goal or aim"
  },
  {
    spanish: "La ambición",
    english: "The ambition",
    type: "noun",
    contextExample: "Strong desire for success"
  },
  {
    spanish: "El desafío",
    english: "The challenge",
    type: "noun",
    contextExample: "Task requiring effort to overcome"
  },
  {
    spanish: "Graduarse",
    english: "To graduate",
    type: "verb",
    contextExample: "To complete studies and receive a degree"
  },
  // Future-related greetings and phrases
  {
    spanish: "¿Cuáles son tus planes para el futuro?",
    english: "What are your plans for the future?",
    type: "greeting",
    contextExample: "Asking about future intentions",
    contextual: true
  },
  {
    spanish: "Quiero ser...",
    english: "I want to be...",
    type: "greeting",
    contextExample: "Expressing career aspirations"
  },
  {
    spanish: "Espero lograr mis metas",
    english: "I hope to achieve my goals",
    type: "greeting",
    contextExample: "Expressing hope for success"
  },
  {
    spanish: "¿Dónde te ves en cinco años?",
    english: "Where do you see yourself in five years?",
    type: "greeting",
    contextExample: "Asking about medium-term plans",
    contextual: true
  },
  {
    spanish: "Mi sueño es...",
    english: "My dream is...",
    type: "greeting",
    contextExample: "Sharing aspirations"
  }
];

// All vocabulary by level
const vocabularyByLevel: Record<number, VocabularyWord[]> = {
  1: level1Vocabulary,
  2: level2Vocabulary,
  3: level3Vocabulary,
  4: level4Vocabulary,
  5: level5Vocabulary,
  6: level6Vocabulary,
  7: level7Vocabulary,
  8: level8Vocabulary,
  9: level9Vocabulary,
  10: level10Vocabulary,
  11: level11Vocabulary,
  12: level12Vocabulary,
  13: level13Vocabulary,
  14: level14Vocabulary,
  15: level15Vocabulary,
  16: level16Vocabulary,
  17: level17Vocabulary,
  18: level18Vocabulary,
  19: level19Vocabulary,
  20: level20Vocabulary,
  21: level21Vocabulary,
  22: level22Vocabulary,
  23: level23Vocabulary,
  24: level24Vocabulary,
  25: level25Vocabulary,
  26: level26Vocabulary,
  27: level27Vocabulary,
  28: level28Vocabulary,
  29: level29Vocabulary,
  30: level30Vocabulary,
};

// Get vocabulary for a specific level
export const getVocabularyForLevel = (levelId: number): VocabularyWord[] => {
  // Check if we have vocabulary for this level
  if (vocabularyByLevel[levelId]) {
    return vocabularyByLevel[levelId];
  }
  
  // Fallback to level 1 vocabulary if the level doesn't exist
  return level1Vocabulary;
};

// Get a random word from a level's vocabulary
export const getRandomWord = (levelId: number): VocabularyWord => {
  const vocabulary = getVocabularyForLevel(levelId);
  const randomIndex = Math.floor(Math.random() * vocabulary.length);
  return vocabulary[randomIndex];
};

// Get words of a specific type from a level
export const getWordsByType = (levelId: number, type: string): VocabularyWord[] => {
  const vocabulary = getVocabularyForLevel(levelId);
  return vocabulary.filter(word => word.type === type);
};
