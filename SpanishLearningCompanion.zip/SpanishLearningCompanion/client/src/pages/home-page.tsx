import Navbar from "@/components/layout/navbar";
import WelcomeBanner from "@/components/welcome-banner";
import LevelGrid from "@/components/level/level-grid";
import GamePreview from "@/components/game-preview";
import Achievements from "@/components/achievements";
import SoundTest from "@/components/audio/sound-test";
import PinEntryModal from "@/components/parent/pin-entry-modal";
import ParentPortal from "@/components/parent/parent-portal";
import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { ParentSettings, Progress } from "@shared/schema";

export default function HomePage() {
  const { user } = useAuth();
  const [showPinModal, setShowPinModal] = useState(false);
  const [showParentPortal, setShowParentPortal] = useState(false);
  
  const { data: progress } = useQuery<Progress>({
    queryKey: ["/api/progress"],
  });
  
  const { data: parentSettings } = useQuery<ParentSettings>({
    queryKey: ["/api/parent-settings"],
  });
  
  const handleParentPortalAccess = () => {
    setShowPinModal(true);
  };
  
  const handlePinVerified = (isValid: boolean) => {
    setShowPinModal(false);
    if (isValid) {
      setShowParentPortal(true);
    }
  };
  
  const handleCloseParentPortal = () => {
    setShowParentPortal(false);
  };

  return (
    <div className="min-h-screen">
      <Navbar onParentPortalClick={handleParentPortalAccess} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <WelcomeBanner 
          childName={user?.childName || "Friend"} 
          sessionDuration={parentSettings?.sessionDuration || 30}
          currentProgress={progress}
        />
        
        <LevelGrid 
          currentLevel={progress?.currentLevel || 1}
          completedLevels={progress?.completedLevels || []}
        />
        
        <GamePreview />
        
        <SoundTest />
        
        <Achievements userId={user?.id || 0} />
      </main>
      
      {showPinModal && (
        <PinEntryModal 
          isOpen={showPinModal}
          onClose={() => setShowPinModal(false)}
          onPinVerified={handlePinVerified}
        />
      )}
      
      {showParentPortal && (
        <ParentPortal 
          isOpen={showParentPortal}
          onClose={handleCloseParentPortal}
          childName={user?.childName || ""}
          progress={progress}
          settings={parentSettings}
        />
      )}
    </div>
  );
}
