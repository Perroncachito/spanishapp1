import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { GameSession } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Loader2, Play, SkipForward, Lock, Clock, Award } from "lucide-react";
import { getGameComponent } from "@/lib/games";
import QuizInterface from "@/components/quiz/quiz-interface";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

export default function LevelPage() {
  const { id } = useParams();
  const levelId = parseInt(id);
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  
  // Check if user is admin
  const isAdmin = user?.isAdmin || false;
  
  const [activeGameIndex, setActiveGameIndex] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [quizUnlocked, setQuizUnlocked] = useState(isAdmin); // Auto-unlock for admins
  const [adminBypass, setAdminBypass] = useState(isAdmin); // Admin bypass toggle
  const [showQuiz, setShowQuiz] = useState(false);
  const [completedGames, setCompletedGames] = useState<number[]>([]);
  const [gameDifficulty, setGameDifficulty] = useState<"easy" | "normal">("easy"); // Default to easy for kids
  
  // ADMIN UNLOCK LEVEL FUNCTIONS
  const MAX_LEVEL = 30; // Total levels in the application
  
  // ===== ADMIN FUNCTION #1: SKIP QUIZ AND UNLOCK NEXT LEVEL =====
  // This marks the current level as completed and unlocks the next level
  const handleAdminUnlockNextLevel = async () => {
    try {
      // Complete the current level by simulating a quiz result
      await apiRequest("POST", "/api/quizzes", {
        levelId: levelId,
        score: 5, // Perfect score
        totalQuestions: 5,
        isPassed: true
      });
      
      // Show success message
      toast({
        title: "Admin Action: Success",
        description: `Level ${levelId} completed and next level unlocked!`,
      });
      
      // Redirect to home page
      setTimeout(() => navigate("/"), 1500);
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to unlock next level: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive"
      });
    }
  };
  
  // ===== ADMIN FUNCTION #2: UNLOCK NEXT SEQUENTIAL LEVEL =====
  // This unlocks the next level after the highest completed level
  const handleAdminUnlockNextSequentialLevel = async () => {
    try {
      // Get current progress to determine highest completed level
      const progressRes = await apiRequest("GET", "/api/progress");
      const progress = await progressRes.json();
      const completedLevels = [...(progress.completedLevels || [])];
      
      // Find the highest completed level number
      let highestCompletedLevel = 0;
      for (const levelStr of completedLevels) {
        const level = parseInt(levelStr);
        if (level > highestCompletedLevel) {
          highestCompletedLevel = level;
        }
      }
      
      // Determine the next level to unlock
      const nextLevelToUnlock = highestCompletedLevel + 1;
      
      // Check if we've already unlocked all levels
      if (nextLevelToUnlock > MAX_LEVEL) {
        toast({
          title: "Admin Action",
          description: "All levels are already unlocked!",
        });
        return;
      }
      
      // Complete this level with a perfect score to unlock the next one
      await apiRequest("POST", "/api/quizzes", {
        levelId: nextLevelToUnlock,
        score: 5,
        totalQuestions: 5,
        isPassed: true
      });
      
      // Show success message
      toast({
        title: "Admin Action: Success",
        description: `Level ${nextLevelToUnlock} completed. Level ${nextLevelToUnlock + 1} is now unlocked!`,
      });
      
      // Redirect to home page
      setTimeout(() => navigate("/"), 1500);
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to unlock next level: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive"
      });
    }
  };
  
  // Get parent settings to know session duration
  const { data: parentSettings } = useQuery({
    queryKey: ["/api/parent-settings"],
  });
  
  // Get active game session or create a new one
  const { data: session, isLoading: sessionLoading } = useQuery<GameSession>({
    queryKey: ["/api/game-sessions/active"],
    onError: () => {
      // If no active session, create one
      createSessionMutation.mutate({ levelId });
    }
  });
  
  // Create a new game session
  const createSessionMutation = useMutation({
    mutationFn: async ({ levelId }: { levelId: number }) => {
      const res = await apiRequest("POST", "/api/game-sessions", {
        levelId,
        gamesCompleted: []
      });
      return await res.json();
    },
    onSuccess: (newSession) => {
      queryClient.setQueryData(["/api/game-sessions/active"], newSession);
      
      // Set timer based on parent settings
      if (parentSettings) {
        setTimeRemaining(parentSettings.sessionDuration * 60); // convert to seconds
      }
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create game session: ${error.message}`,
        variant: "destructive"
      });
      navigate("/");
    }
  });
  
  // Update game session
  const updateSessionMutation = useMutation({
    mutationFn: async ({ sessionId, data }: { sessionId: number, data: any }) => {
      const res = await apiRequest("PATCH", `/api/game-sessions/${sessionId}`, data);
      return await res.json();
    },
    onSuccess: (updatedSession) => {
      queryClient.setQueryData(["/api/game-sessions/active"], updatedSession);
    },
  });
  
  // Complete a game session
  const completeSessionMutation = useMutation({
    mutationFn: async ({ sessionId, timeSpent }: { sessionId: number, timeSpent: number }) => {
      const res = await apiRequest("POST", `/api/game-sessions/${sessionId}/complete`, { timeSpent });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/progress"] });
      setQuizUnlocked(true);
    },
  });
  
  // Timer effect
  useEffect(() => {
    if (timeRemaining <= 0 || !session || session.isCompleted) return;
    
    const timer = setInterval(() => {
      setTimeRemaining(prevTime => {
        const newTime = prevTime - 1;
        
        // Check if time's up
        if (newTime <= 0) {
          clearInterval(timer);
          
          // Mark session as complete
          if (session) {
            const sessionDuration = parentSettings?.sessionDuration || 30;
            const timeSpent = sessionDuration * 60; // in seconds
            completeSessionMutation.mutate({ 
              sessionId: session.id, 
              timeSpent 
            });
          }
        }
        
        return newTime;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, [timeRemaining, session, parentSettings]);
  
  // Handle game completion
  const handleGameComplete = () => {
    if (!session) return;
    
    // Add current game to completed games
    const newCompletedGames = [...completedGames];
    if (!newCompletedGames.includes(activeGameIndex)) {
      newCompletedGames.push(activeGameIndex);
      setCompletedGames(newCompletedGames);
      
      // Update session in database
      updateSessionMutation.mutate({
        sessionId: session.id,
        data: { gamesCompleted: newCompletedGames.map(index => ({ gameIndex: index, levelId })) }
      });
    }
    
    // Move to next game
    setActiveGameIndex((prevIndex) => (prevIndex + 1) % 6);
  };
  
  // Handle skip game
  const handleSkipGame = () => {
    setActiveGameIndex((prevIndex) => (prevIndex + 1) % 6);
  };
  
  // Handle quiz completion
  const handleQuizComplete = (passed: boolean) => {
    if (passed) {
      toast({
        title: "Congratulations!",
        description: "You've completed this level successfully!",
      });
      
      // Navigate back to home after a delay
      setTimeout(() => {
        navigate("/");
      }, 2000);
    } else {
      toast({
        title: "Keep practicing!",
        description: "Try again to master this level.",
      });
      setShowQuiz(false);
    }
  };
  
  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  // Get level name
  const getLevelName = (id: number) => {
    const levels: Record<number, string> = {
      1: "Basic Greetings",
      2: "Formal vs. Informal Greetings",
      3: "Introductions & Personal Information",
      4: "Conversation Basics",
      5: "Numbers 1-10",
      6: "Numbers 11-31",
      7: "Counting & Basic Math",
      8: "Basic Colors",
      9: "Family Members",
      10: "Common Animals",
      11: "Food and Drink",
      12: "Days of the Week and Time",
      13: "Weather and Seasons",
      14: "Clothing and Shopping",
      15: "Parts of the Body",
      16: "School and Education",
      17: "Hobbies and Free Time",
      18: "Transportation",
      19: "Travel and Directions",
      20: "Sports and Games",
      21: "Music & Art",
      22: "Getting Around",
      23: "Occupations",
      24: "Travel Vocabulary",
      25: "Classroom Vocabulary",
      26: "School Subjects",
      27: "Academic Activities",
      28: "Arts and Entertainment",
      29: "Descriptions and Comparisons",
      30: "Future Plans and Career Aspirations"
    };
    return levels[id] || `Level ${id}`;
  };
  
  // Handle admin toggle
  const handleAdminBypassToggle = () => {
    // Toggle the admin bypass
    const newBypassState = !adminBypass;
    setAdminBypass(newBypassState);
    
    // If admin is toggling bypass on, automatically unlock the quiz
    if (newBypassState) {
      setQuizUnlocked(true);
      toast({
        title: "Admin Mode",
        description: "Quiz unlocked. You can now take the quiz without waiting.",
      });
    } else {
      // If toggling off and timer is still running, lock the quiz again
      if (timeRemaining > 0 && session && !session.isCompleted) {
        setQuizUnlocked(false);
        toast({
          title: "Admin Mode Disabled",
          description: "Quiz access now follows standard time requirements.",
        });
      }
    }
  };
  
  // Handle game difficulty change
  const handleDifficultyChange = () => {
    const newDifficulty = gameDifficulty === "easy" ? "normal" : "easy";
    setGameDifficulty(newDifficulty);
    toast({
      title: `Game Difficulty: ${newDifficulty === "easy" ? "Easy" : "Normal"}`,
      description: newDifficulty === "easy" ? "Games are now easier for kids." : "Games are now at normal difficulty.",
    });
  };
  
  // Get current game component with difficulty setting
  const GameComponent = getGameComponent(activeGameIndex);
  
  if (sessionLoading || !parentSettings) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-white">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
        <span className="ml-2 text-xl">Loading level...</span>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-neutral-100">
      {/* Game Header */}
      <div className="bg-primary text-white p-4 sticky top-0 z-10 shadow-md">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Button
            variant="ghost"
            className="text-white hover:bg-primary-dark"
            onClick={() => navigate("/")}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5M12 19l-7-7 7-7" />
            </svg>
          </Button>
          
          <div className="text-center">
            <h2 className="text-xl font-bold font-nunito">Level {levelId}: {getLevelName(levelId)}</h2>
            <div className="text-sm text-white text-opacity-90">
              Time remaining: {formatTime(timeRemaining)}
            </div>
          </div>
          
          <div className="bg-white bg-opacity-30 rounded-full px-3 py-1 text-sm">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="inline mr-1">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
            </svg>
            {completedGames.length * 20} pts
          </div>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-4 sm:p-6">
        {showQuiz ? (
          <QuizInterface
            levelId={levelId}
            onComplete={handleQuizComplete}
          />
        ) : (
          <>
            {/* Admin Controls - only visible for admin users */}
            {isAdmin && (
              <div className="bg-stone-100 p-4 rounded-lg mb-4 border border-stone-200">
                <h3 className="text-lg font-semibold mb-2 text-stone-700 flex items-center">
                  <Award className="mr-2 h-5 w-5 text-primary" /> Admin Controls
                </h3>
                <div className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-6">
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="admin-bypass" 
                      checked={adminBypass}
                      onCheckedChange={handleAdminBypassToggle}
                    />
                    <Label htmlFor="admin-bypass" className="font-medium">
                      Bypass Time Requirements
                    </Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="game-difficulty" 
                      checked={gameDifficulty === "easy"}
                      onCheckedChange={handleDifficultyChange}
                    />
                    <Label htmlFor="game-difficulty" className="font-medium">
                      Easy Mode for Kids
                    </Label>
                  </div>
                </div>
                
                <div className="mt-4 flex space-x-4">
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="border-green-500 text-green-600 hover:bg-green-50"
                    onClick={handleAdminUnlockNextLevel}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                    Skip Quiz & Unlock Next Level
                  </Button>
                  
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="border-purple-500 text-purple-600 hover:bg-purple-50"
                    onClick={handleAdminUnlockNextSequentialLevel}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                    Unlock Next Level
                  </Button>
                </div>
                <p className="text-xs text-stone-500 mt-2">
                  <Clock className="inline h-3 w-3 mr-1" />
                  Time-based progression: Students need to practice for {parentSettings?.sessionDuration || 30} minutes before taking quiz
                </p>
              </div>
            )}
            
            <GameComponent
              levelId={levelId}
              onComplete={handleGameComplete}
              difficulty={gameDifficulty}
            />
            
            {/* Bottom Navigation Bar */}
            <div className="border-t border-neutral-200 p-4 mt-6 flex justify-between items-center bg-white rounded-lg shadow-sm">
              <div className="text-sm text-neutral-600 flex items-center">
                <Clock className="h-4 w-4 mr-1 text-primary" />
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <span className="flex items-center cursor-help">
                        {quizUnlocked ? (
                          "Practice time completed!"
                        ) : (
                          <>
                            Practice remaining: {formatTime(timeRemaining)} 
                            <span className="ml-1 text-xs text-neutral-400">(time-based progress)</span>
                          </>
                        )}
                      </span>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Practice for {parentSettings?.sessionDuration || 30} minutes to unlock the quiz</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <div className="flex items-center">
                <Button
                  variant="outline"
                  className="mr-2"
                  onClick={handleSkipGame}
                >
                  Skip <SkipForward className="ml-1 h-4 w-4" />
                </Button>
                
                <Button
                  disabled={!quizUnlocked && !adminBypass}
                  onClick={() => setShowQuiz(true)}
                  className={!quizUnlocked && !adminBypass ? "bg-neutral-400" : ""}
                >
                  {quizUnlocked || adminBypass ? (
                    <>Take Quiz <Play className="ml-1 h-4 w-4" /></>
                  ) : (
                    <>Take Quiz <Lock className="ml-1 h-4 w-4" /></>
                  )}
                </Button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
