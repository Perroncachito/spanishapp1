import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Achievement } from "@shared/schema";

interface AchievementsProps {
  userId: number;
}

export default function Achievements({ userId }: AchievementsProps) {
  // Fetch achievements from API
  const { data: achievements } = useQuery<Achievement[]>({
    queryKey: ["/api/achievements"],
    enabled: userId > 0
  });

  // Define all possible achievements
  const allAchievements = [
    {
      id: "first_steps",
      title: "First Steps",
      description: "Completed your first level",
      icon: "fa-star",
      unlockCondition: (achievements: Achievement[] | undefined) => 
        achievements?.some(a => a.achievementType === "first_level")
    },
    {
      id: "daily_streak",
      title: "Daily Streak",
      description: "Practice for 5 days in a row",
      icon: "fa-calendar-check",
      unlockCondition: (achievements: Achievement[] | undefined) => 
        achievements?.some(a => a.achievementType === "daily_streak")
    },
    {
      id: "perfect_score",
      title: "Perfect Score",
      description: "Get 100% on any quiz",
      icon: "fa-graduation-cap",
      unlockCondition: (achievements: Achievement[] | undefined) => 
        achievements?.some(a => a.achievementType === "perfect_score")
    },
    {
      id: "quick_learner",
      title: "Quick Learner",
      description: "Complete a level in under 20 minutes",
      icon: "fa-rocket",
      unlockCondition: (achievements: Achievement[] | undefined) => 
        achievements?.some(a => a.achievementType === "quick_learner")
    }
  ];

  // View all achievements handling
  const [viewingAll, setViewingAll] = useState(false);
  
  // Determine which achievements to display
  const displayedAchievements = viewingAll 
    ? allAchievements 
    : allAchievements.slice(0, 4);

  return (
    <Card className="bg-white rounded-2xl p-6 shadow-md">
      <CardContent className="p-0">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold text-neutral-800 font-nunito">Your Achievements</h2>
          <Button 
            variant="link" 
            className="text-secondary hover:text-secondary-dark font-medium" 
            onClick={() => setViewingAll(!viewingAll)}
          >
            {viewingAll ? "Show Less" : "View All"}
          </Button>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {displayedAchievements.map((achievement) => {
            const isUnlocked = achievement.unlockCondition(achievements);
            
            return (
              <div 
                key={achievement.id} 
                className={`bg-neutral-100 rounded-lg p-4 border-2 ${
                  isUnlocked ? 'border-success' : 'border-neutral-300 opacity-70'
                }`}
              >
                <div className="flex justify-center mb-2">
                  <div className={`w-16 h-16 rounded-full ${
                    isUnlocked ? 'bg-success' : 'bg-neutral-300'
                  } flex items-center justify-center relative`}>
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      className="text-white text-2xl h-8 w-8" 
                      fill="none" 
                      viewBox="0 0 24 24" 
                      stroke="currentColor" 
                      strokeWidth={2}
                    >
                      {achievement.icon === "fa-star" && (
                        <path 
                          strokeLinecap="round" 
                          strokeLinejoin="round" 
                          d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" 
                        />
                      )}
                      {achievement.icon === "fa-calendar-check" && (
                        <path 
                          strokeLinecap="round" 
                          strokeLinejoin="round" 
                          d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" 
                        />
                      )}
                      {achievement.icon === "fa-graduation-cap" && (
                        <path 
                          strokeLinecap="round" 
                          strokeLinejoin="round" 
                          d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222" 
                        />
                      )}
                      {achievement.icon === "fa-rocket" && (
                        <path 
                          strokeLinecap="round" 
                          strokeLinejoin="round" 
                          d="M15.59 14.37a6 6 0 01-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 006.16-12.12A14.98 14.98 0 009.631 8.41m5.96 5.96a14.926 14.926 0 01-5.841 2.58m-.119-8.54a6 6 0 00-7.381 5.84h4.8m2.581-5.84a14.927 14.927 0 00-2.58 5.84m2.699 2.7c-.103.021-.207.041-.311.06a15.09 15.09 0 01-2.448-2.448 14.9 14.9 0 01.06-.312m-2.24 2.39a4.493 4.493 0 00-1.757 4.306 4.493 4.493 0 004.306-1.758M16.5 9a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z" 
                        />
                      )}
                    </svg>
                    
                    {!isUnlocked && (
                      <div className="absolute -bottom-1 -right-1 bg-white p-1 rounded-full">
                        <svg 
                          xmlns="http://www.w3.org/2000/svg" 
                          className="h-4 w-4 text-neutral-500" 
                          fill="none" 
                          viewBox="0 0 24 24" 
                          stroke="currentColor" 
                          strokeWidth={2}
                        >
                          <path 
                            strokeLinecap="round" 
                            strokeLinejoin="round" 
                            d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" 
                          />
                        </svg>
                      </div>
                    )}
                  </div>
                </div>
                <h3 className={`text-center font-bold ${
                  isUnlocked ? 'text-neutral-800' : 'text-neutral-700'
                } font-nunito mb-1`}>
                  {achievement.title}
                </h3>
                <p className={`text-center text-sm ${
                  isUnlocked ? 'text-neutral-600' : 'text-neutral-500'
                }`}>
                  {achievement.description}
                </p>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
