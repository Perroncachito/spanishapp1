import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { RotateCcw } from "lucide-react";
import { getVocabularyForLevel } from "@/lib/vocabulary";

interface DialogueBuilderProps {
  levelId: number;
  onComplete: () => void;
}

type DialogueLine = {
  id: number;
  speaker: "person1" | "person2";
  text: string;
  isGap: boolean;
  answer?: string;
  userAnswer?: string;
  options?: string[];
};

export default function DialogueBuilder({ levelId, onComplete, difficulty = "normal" }: DialogueBuilderProps & { difficulty?: "easy" | "normal" }) {
  const [dialogue, setDialogue] = useState<DialogueLine[]>([]);
  const [message, setMessage] = useState<string>("¡Hola! Complete the dialogue by selecting the correct phrases.");
  const [dialogueCompleted, setDialogueCompleted] = useState(false);
  const [allCorrect, setAllCorrect] = useState(false);
  
  useEffect(() => {
    // Get basic dialogue for current level
    const dialogues = getDialoguesForLevel(levelId);
    const selectedDialogue = dialogues[0]; // For simplicity, use the first dialogue
    
    setDialogue(selectedDialogue);
    setDialogueCompleted(false);
    setAllCorrect(false);
    
    // Set a more kid-friendly message for easy difficulty
    if (difficulty === "easy") {
      setMessage("¡Hola amigo! Help complete the conversation by picking the right Spanish words!");
    } else {
      setMessage("¡Hola! Complete the dialogue by selecting the correct phrases.");
    }
  }, [levelId, difficulty]);
  
  // Get dialogues based on level
  const getDialoguesForLevel = (levelId: number): DialogueLine[][] => {
    // For level 1 (basic greetings)
    if (levelId === 1) {
      return [
        [
          { id: 1, speaker: "person1", text: "¡Hola! ¿Cómo estás?", isGap: false },
          { id: 2, speaker: "person2", text: "", isGap: true, answer: "Estoy bien, gracias. ¿Y tú?", options: [
            "Estoy bien, gracias. ¿Y tú?",
            "Me llamo Juan.",
            "Hasta mañana.",
            "Sí, por favor."
          ]},
          { id: 3, speaker: "person1", text: "", isGap: true, answer: "Muy bien, gracias.", options: [
            "Buenos días.",
            "Muy bien, gracias.",
            "De nada.",
            "No entiendo."
          ]},
          { id: 4, speaker: "person2", text: "¿Cómo te llamas?", isGap: false },
          { id: 5, speaker: "person1", text: "", isGap: true, answer: "Me llamo Ana. ¿Y tú?", options: [
            "Me gusta el español.",
            "Me llamo Ana. ¿Y tú?",
            "Tengo 10 años.",
            "Soy de España."
          ]},
          { id: 6, speaker: "person2", text: "Me llamo Carlos. Mucho gusto.", isGap: false },
          { id: 7, speaker: "person1", text: "", isGap: true, answer: "Encantada de conocerte.", options: [
            "Encantada de conocerte.",
            "Hasta luego.",
            "Lo siento.",
            "No hay problema."
          ]},
        ],
        // Add more dialogues as needed
      ];
    }
    
    // For level 2 (formal vs informal greetings)
    if (levelId === 2) {
      return [
        [
          { id: 1, speaker: "person1", text: "Buenos días, señor Rodríguez.", isGap: false },
          { id: 2, speaker: "person2", text: "", isGap: true, answer: "Buenos días, señorita López. ¿Cómo está usted?", options: [
            "Buenos días, señorita López. ¿Cómo está usted?",
            "¡Hola! ¿Qué tal?",
            "Buenas noches, señora.",
            "Adiós, hasta pronto."
          ]},
          { id: 3, speaker: "person1", text: "", isGap: true, answer: "Muy bien, gracias. ¿Y usted?", options: [
            "Muy bien, gracias. ¿Y usted?",
            "Estoy bien, ¿y tú?",
            "Me gusta el café.",
            "Nos vemos mañana."
          ]},
          { id: 4, speaker: "person2", text: "Estoy bien. ¿En qué puedo ayudarle?", isGap: false },
          // Add more dialogue lines
        ],
      ];
    }
    
    // Default dialogue if level doesn't have specific content
    return [
      [
        { id: 1, speaker: "person1", text: "¡Hola! ¿Cómo estás?", isGap: false },
        { id: 2, speaker: "person2", text: "", isGap: true, answer: "Estoy bien, gracias. ¿Y tú?", options: [
          "Estoy bien, gracias. ¿Y tú?",
          "Me llamo Juan.",
          "Hasta mañana.",
          "Sí, por favor."
        ]},
        { id: 3, speaker: "person1", text: "Muy bien, gracias.", isGap: false },
      ],
    ];
  };
  
  // Handle option selection for a gap
  const handleOptionSelect = (lineId: number, option: string) => {
    if (dialogueCompleted) return;
    
    // Update dialogue with selected option
    const updatedDialogue = dialogue.map(line => 
      line.id === lineId 
        ? { ...line, userAnswer: option } 
        : line
    );
    
    setDialogue(updatedDialogue);
    
    // Check if all gaps have been filled
    const allFilled = updatedDialogue.every(line => !line.isGap || line.userAnswer);
    
    if (allFilled) {
      setDialogueCompleted(true);
      
      // Check if all answers are correct
      const allAnswersCorrect = updatedDialogue.every(line => 
        !line.isGap || line.userAnswer === line.answer
      );
      
      setAllCorrect(allAnswersCorrect);
      
      if (allAnswersCorrect) {
        if (difficulty === "easy") {
          setMessage("¡Súper! You're a Spanish star! You completed the conversation perfectly!");
          // Give kids a little more time to celebrate their success in easy mode
          setTimeout(onComplete, 2500);
        } else {
          setMessage("¡Excelente! You completed the dialogue perfectly!");
          setTimeout(onComplete, 1500);
        }
      } else {
        if (difficulty === "easy") {
          setMessage("Nice try! Look at the green boxes to see the right answers. You can do it!");
        } else {
          setMessage("Good try! Check the correct answers highlighted in green.");
        }
      }
    }
  };

  // Reset the dialogue
  const handleReset = () => {
    const resetDialogue = dialogue.map(line => 
      line.isGap ? { ...line, userAnswer: undefined } : line
    );
    
    setDialogue(resetDialogue);
    setDialogueCompleted(false);
    setAllCorrect(false);
    
    // Set kid-friendly reset message based on difficulty
    if (difficulty === "easy") {
      setMessage("¡Vamos a intentar! Let's try again with our Spanish conversation!");
    } else {
      setMessage("¡Hola! Complete the dialogue by selecting the correct phrases.");
    }
  };

  return (
    <div className={`p-6 ${difficulty === "easy" ? "p-8" : "p-6"} bg-white rounded-xl shadow-md`}>
      <div className="mb-6 flex justify-between items-center">
        <h3 className={`${difficulty === "easy" ? "text-3xl" : "text-2xl"} font-bold text-neutral-800 font-nunito flex items-center`}>
          <svg xmlns="http://www.w3.org/2000/svg" width={difficulty === "easy" ? "32" : "24"} height={difficulty === "easy" ? "32" : "24"} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500 mr-2">
            <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z" />
            <path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z" />
          </svg>
          Dialogue Builder
        </h3>
        <Button
          variant="outline"
          size={difficulty === "easy" ? "lg" : "sm"}
          className="bg-neutral-200 hover:bg-neutral-300 text-neutral-600"
          onClick={handleReset}
        >
          <RotateCcw className={`${difficulty === "easy" ? "h-5 w-5" : "h-4 w-4"} mr-1`} /> Start Over
        </Button>
      </div>
      
      {difficulty === "easy" ? (
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6 rounded">
          <div className="flex">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-yellow-500 mr-2 flex-shrink-0">
              <circle cx="12" cy="12" r="10"></circle>
              <line x1="12" y1="16" x2="12" y2="12"></line>
              <line x1="12" y1="8" x2="12.01" y2="8"></line>
            </svg>
            <p className="text-lg text-neutral-600">
              Help complete the conversation by choosing the correct Spanish phrases.
              <span className="block mt-1 text-neutral-500">Look for the bubbles with <b>...</b> and pick the right answer!</span>
            </p>
          </div>
        </div>
      ) : (
        <p className="text-neutral-600 mb-4">Complete the dialogue by selecting the correct Spanish phrase for each gap.</p>
      )}
      
      {/* Dialogue Exchange */}
      <div className={`bg-neutral-100 rounded-lg ${difficulty === "easy" ? "p-6" : "p-4"} mb-6 border ${difficulty === "easy" ? "border-blue-200" : "border-transparent"}`}>
        <div className={`${difficulty === "easy" ? "space-y-6" : "space-y-4"}`}>
          {dialogue.map(line => (
            <div key={line.id} className={`flex ${line.speaker === "person1" ? "justify-start" : "justify-end"}`}>
              {difficulty === "easy" && line.speaker === "person1" && (
                <div className="mr-3 flex-shrink-0">
                  <div className="bg-blue-100 rounded-full w-10 h-10 flex items-center justify-center border-2 border-blue-300">
                    <span className="text-blue-700 font-bold">1</span>
                  </div>
                </div>
              )}
              
              <div 
                className={`
                  ${difficulty === "easy" ? "max-w-[75%] text-lg" : "max-w-[80%]"} rounded-lg ${difficulty === "easy" ? "p-4" : "p-3"}
                  ${line.speaker === "person1" 
                    ? "bg-primary text-white rounded-bl-none" 
                    : "bg-secondary text-white rounded-br-none"}
                  ${line.isGap && line.userAnswer 
                    ? (dialogueCompleted && line.userAnswer === line.answer 
                        ? `border-3 ${difficulty === "easy" ? "border-4" : "border-2"} border-green-500` 
                        : dialogueCompleted 
                          ? `${difficulty === "easy" ? "border-4" : "border-2"} border-red-500` 
                          : "")
                    : ""}
                  ${line.isGap && !line.userAnswer ? "border-2 border-dashed border-yellow-400 animate-pulse" : ""}
                `}
              >
                {line.isGap ? (
                  line.userAnswer || (
                    <div className="flex items-center justify-center">
                      <span className="text-white opacity-70">...</span>
                      {difficulty === "easy" && (<span className="ml-2 bg-yellow-300 text-xs text-yellow-800 px-2 py-1 rounded-full">Choose below!</span>)}
                    </div>
                  )
                ) : (
                  line.text
                )}
                
                {dialogueCompleted && line.isGap && line.userAnswer !== line.answer && (
                  <div className={`mt-2 text-white bg-green-500 bg-opacity-90 ${difficulty === "easy" ? "p-3 text-md rounded-md" : "p-1 rounded text-sm"}`}>
                    <span className="font-bold">Correct:</span> {line.answer}
                  </div>
                )}
              </div>
              
              {difficulty === "easy" && line.speaker === "person2" && (
                <div className="ml-3 flex-shrink-0">
                  <div className="bg-green-100 rounded-full w-10 h-10 flex items-center justify-center border-2 border-green-300">
                    <span className="text-green-700 font-bold">2</span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
      
      {/* Options for Gaps */}
      {!dialogueCompleted && dialogue.filter(line => line.isGap && !line.userAnswer).length > 0 && (
        <div className={`mb-6 ${difficulty === "easy" ? "bg-blue-50 p-5 rounded-lg border border-blue-100" : ""}`}>
          <h4 className={`font-bold ${difficulty === "easy" ? "text-xl mb-4" : "text-base mb-3"} text-neutral-700`}>
            {difficulty === "easy" ? (
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary mr-2">
                  <circle cx="12" cy="12" r="10"></circle>
                  <path d="M12 8v4M12 16h.01"></path>
                </svg>
                Choose what 
                <span className="text-primary mx-2">
                  {dialogue.find(line => line.isGap && !line.userAnswer)?.speaker === "person1" ? "Person 1" : "Person 2"}
                </span> 
                should say:
              </div>
            ) : (
              <>
                Select the correct phrase for: 
                <span className="text-primary">
                  {` ${dialogue.find(line => line.isGap && !line.userAnswer)?.speaker === "person1" ? "Person 1" : "Person 2"}`}
                </span>
              </>
            )}
          </h4>
          
          <div className={`grid grid-cols-1 ${difficulty === "easy" ? "gap-4" : "md:grid-cols-2 gap-3"}`}>
            {dialogue.find(line => line.isGap && !line.userAnswer)?.options?.map((option, index) => (
              <Button
                key={index}
                variant="outline"
                className={`
                  ${difficulty === "easy" ? "text-lg py-4 px-5" : "h-auto py-2 justify-start"}
                  bg-white border-2 border-neutral-200 hover:bg-neutral-100 text-neutral-800
                  ${difficulty === "easy" ? "hover:border-primary hover:bg-primary/10" : ""}
                `}
                onClick={() => handleOptionSelect(
                  dialogue.find(line => line.isGap && !line.userAnswer)?.id || 0,
                  option
                )}
              >
                {option}
                {difficulty === "easy" && (
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-2">
                    <path d="M5 12h14"></path>
                    <path d="m12 5 7 7-7 7"></path>
                  </svg>
                )}
              </Button>
            ))}
          </div>
        </div>
      )}
      
      {/* Progress Indicator */}
      <div className={`bg-neutral-200 rounded-full ${difficulty === "easy" ? "h-6" : "h-4"} mb-6`}>
        <div 
          className={`bg-secondary h-full rounded-full transition-all duration-500`} 
          style={{ 
            width: `${(dialogue.filter(line => !line.isGap || line.userAnswer).length / dialogue.length) * 100}%` 
          }}
        >
          {difficulty === "easy" && (
            <div className="h-full flex items-center justify-center text-xs font-bold text-white">
              {Math.round((dialogue.filter(line => !line.isGap || line.userAnswer).length / dialogue.length) * 100)}%
            </div>
          )}
        </div>
      </div>
      
      {/* Toucan Character with Speech Bubble */}
      <div className="flex items-end">
        <svg width="100" height="100" viewBox="0 0 200 200" className={difficulty === "easy" ? "h-32" : "h-24"}>
          <path
            d="M100,20 C130,20 150,40 150,70 C150,85 140,95 135,100 C145,110 150,125 150,140 C150,170 130,190 100,190 C70,190 50,170 50,140 C50,125 55,110 65,100 C60,95 50,85 50,70 C50,40 70,20 100,20 Z"
            fill="#FF6B6B"
          />
          <circle cx="80" cy="70" r="10" fill="white" />
          <circle cx="80" cy="70" r="5" fill="black" />
          <circle cx="120" cy="70" r="10" fill="white" />
          <circle cx="120" cy="70" r="5" fill="black" />
          <path
            d="M90,90 C95,95 105,95 110,90"
            stroke="black"
            strokeWidth="3"
            fill="none"
          />
          <path
            d="M70,115 C80,130 120,130 130,115"
            stroke="#FFA500"
            strokeWidth="15"
            fill="none"
            strokeLinecap="round"
          />
          {allCorrect && (
            <path
              d="M60,55 C65,45 75,55 60,55 Z M140,55 C135,45 125,55 140,55 Z"
              fill="#FFA500"
            />
          )}
        </svg>
        <div className={`relative ml-4 bg-neutral-100 p-4 rounded-xl ${difficulty === "easy" ? "max-w-sm text-lg" : "max-w-xs"}`}>
          <div className="absolute w-4 h-4 bg-neutral-100 transform rotate-45 -left-2 bottom-4"></div>
          <p className={`${difficulty === "easy" ? "text-lg" : ""} text-neutral-700`}>
            {message}
            {dialogueCompleted && allCorrect && difficulty === "easy" && (
              <span className="block mt-2 text-green-600 font-bold">¡Fantástico! You're doing great!</span>
            )}
          </p>
        </div>
      </div>
    </div>
  );
}
