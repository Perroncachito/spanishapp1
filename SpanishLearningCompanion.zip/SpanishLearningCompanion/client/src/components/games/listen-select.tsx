import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Volume2, Play, RotateCcw } from "lucide-react";
import { getVocabularyForLevel } from "@/lib/vocabulary";

interface ListenSelectProps {
  levelId: number;
  onComplete: () => void;
}

type AudioQuestion = {
  spanish: string;
  english: string;
  options: string[];
  answered: boolean;
  correct: boolean;
};

export default function ListenSelect({ levelId, onComplete }: ListenSelectProps) {
  const [questions, setQuestions] = useState<AudioQuestion[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [message, setMessage] = useState<string>("¡Hola! Listen to the Spanish word and select the correct meaning.");
  const [canAnswer, setCanAnswer] = useState(true);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  
  // Create speech synthesis for Spanish audio
  const speakSpanish = (word: string) => {
    // Check if browser supports SpeechSynthesis
    if ('speechSynthesis' in window) {
      // Create a new speech synthesis utterance
      const utterance = new SpeechSynthesisUtterance(word);
      utterance.lang = 'es-ES'; // Set language to Spanish
      utterance.rate = 0.8; // Slow down a bit for clarity
      
      // Set event handlers
      utterance.onstart = () => {
        setIsPlaying(true);
      };
      
      utterance.onend = () => {
        setIsPlaying(false);
      };
      
      utterance.onerror = () => {
        setIsPlaying(false);
        setMessage("Sorry, there was an error playing the audio. Try again!");
      };
      
      // Speak the word
      window.speechSynthesis.speak(utterance);
    } else {
      // Fallback for browsers that don't support speech synthesis
      setMessage("Sorry, your browser doesn't support audio playback. Try in Chrome or Edge.");
    }
  };

  useEffect(() => {
    // Get vocabulary for the current level
    const vocabulary = getVocabularyForLevel(levelId);
    
    // Select words to use for the game (fewer words for kids - only 3 for easy mode)
    const wordsToUse = vocabulary.slice(0, 3);
    
    // Create audio questions
    const audioQuestions = wordsToUse.map(word => {
      // Create wrong options from other words
      const otherWords = vocabulary.filter(w => w.english !== word.english);
      const wrongOptions = otherWords
        .sort(() => Math.random() - 0.5)
        .slice(0, 2) // Only 2 wrong options instead of 3 to make it easier for kids
        .map(w => w.english);
      
      // Combine correct and wrong options, then shuffle
      const options = [word.english, ...wrongOptions].sort(() => Math.random() - 0.5);
      
      // Handle words with slashes - take the first option
      const spanishWord = word.spanish.split("/")[0].trim();
      
      return {
        spanish: spanishWord,
        english: word.english,
        options,
        answered: false,
        correct: false
      };
    });
    
    setQuestions(audioQuestions);
    setCurrentQuestionIndex(0);
    setCanAnswer(true);
    
    // Clean up any previous speech synthesis
    window.speechSynthesis?.cancel();
    
    return () => {
      // Cleanup any ongoing speech
      window.speechSynthesis?.cancel();
    };
  }, [levelId]);

  // Handle playing audio
  const playAudio = () => {
    if (questions.length === 0) return;
    
    const currentQuestion = questions[currentQuestionIndex];
    
    try {
      // Cancel any previous speech
      window.speechSynthesis.cancel();
      
      // Speak the Spanish word using our speech synthesis function
      speakSpanish(currentQuestion.spanish);

      // Also display the Spanish word to help kids
      setMessage(`Listen to the Spanish word: "${currentQuestion.spanish}". What does it mean?`);
    } catch (error) {
      console.error("Error playing audio:", error);
      setIsPlaying(false);
      setMessage("Sorry, there was an error playing the audio. Try again!");
    }
  };

  // Handle option selection
  const handleOptionClick = (option: string) => {
    if (!canAnswer) return;
    
    const currentQuestion = questions[currentQuestionIndex];
    
    // Check if answer is correct
    const isCorrect = option === currentQuestion.english;
    
    // Update question status
    const updatedQuestions = [...questions];
    updatedQuestions[currentQuestionIndex] = {
      ...currentQuestion,
      answered: true,
      correct: isCorrect
    };
    
    setQuestions(updatedQuestions);
    setCanAnswer(false);
    
    // Set feedback message
    if (isCorrect) {
      setMessage(`¡Correcto! "${currentQuestion.spanish}" means "${currentQuestion.english}".`);
    } else {
      setMessage(`Not quite. "${currentQuestion.spanish}" means "${currentQuestion.english}".`);
    }
    
    // Move to next question after a delay or complete game
    setTimeout(() => {
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
        setCanAnswer(true);
        setMessage("Listen to the next word and select the correct meaning.");
      } else {
        // All questions answered, check completion criteria
        const correctAnswers = updatedQuestions.filter(q => q.correct).length;
        const passThreshold = Math.ceil(questions.length * 0.7); // 70% correct to pass
        
        if (correctAnswers >= passThreshold) {
          setMessage(`¡Excelente! You got ${correctAnswers} out of ${questions.length} correct!`);
          setTimeout(onComplete, 1500);
        } else {
          setMessage(`You got ${correctAnswers} out of ${questions.length} correct. Let's try again!`);
          // Reset the game after a delay
          setTimeout(resetGame, 2000);
        }
      }
    }, 2000);
  };

  const resetGame = () => {
    const resetQuestions = questions.map(q => ({
      ...q,
      answered: false,
      correct: false
    }));
    
    setQuestions(resetQuestions);
    setCurrentQuestionIndex(0);
    setCanAnswer(true);
    setMessage("¡Hola! Listen to the Spanish word and select the correct meaning.");
  };

  // Calculate progress
  const progress = questions.length > 0 
    ? ((questions.filter(q => q.answered).length) / questions.length) * 100 
    : 0;

  return (
    <div className="p-6 bg-gradient-to-b from-purple-50 to-white rounded-xl shadow-md border-2 border-purple-100">
      <div className="mb-6 flex justify-between items-center">
        <h3 className="text-3xl font-bold text-purple-700 font-nunito flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-purple-500 mr-3">
            <path d="M3 18v-6a9 9 0 0 1 18 0v6"></path>
            <path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"></path>
          </svg>
          Listen and Select
        </h3>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="lg"
            className="bg-purple-100 hover:bg-purple-200 text-purple-700 border-purple-300 text-lg"
            onClick={resetGame}
          >
            <RotateCcw className="h-5 w-5 mr-2" /> Restart
          </Button>
        </div>
      </div>
      
      <div className="bg-purple-100 border-l-4 border-purple-400 p-4 mb-6 rounded-md">
        <p className="text-purple-800 text-lg font-medium">Listen to the Spanish word and choose the matching English word!</p>
      </div>
      
      {questions.length > 0 && (
        <div className="space-y-6">
          {/* Current Question */}
          <div className="bg-purple-100 rounded-2xl p-6 text-center border-2 border-purple-200 shadow-sm">
            <div className="text-3xl font-bold text-purple-700 mb-4 font-nunito">
              Question {currentQuestionIndex + 1} of {questions.length}
            </div>
            
            <div className="flex justify-center mb-4">
              <div className="w-20 h-20 bg-purple-500 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all">
                <Button
                  variant="default"
                  size="lg"
                  className="w-full h-full bg-purple-500 hover:bg-purple-600 text-white rounded-full text-center p-0 flex items-center justify-center"
                  onClick={playAudio}
                  disabled={isPlaying}
                >
                  {isPlaying ? (
                    <Volume2 className="h-10 w-10 animate-pulse" />
                  ) : (
                    <Play className="h-10 w-10" />
                  )}
                </Button>
              </div>
            </div>
            
            <div className="text-xl text-purple-700 font-medium">
              {isPlaying ? "Listening..." : "Press the button to hear the Spanish word"}
            </div>
            
            {questions[currentQuestionIndex].answered && (
              <div className={`mt-4 font-bold text-2xl animate-bounce ${questions[currentQuestionIndex].correct ? 'text-green-600' : 'text-red-600'}`}>
                {questions[currentQuestionIndex].correct ? '¡Correcto! 🎉' : 'Try again! 🤔'}
              </div>
            )}
          </div>
          
          {/* Options */}
          <div className="grid grid-cols-1 gap-4 mt-8">
            {questions[currentQuestionIndex].options.map((option, index) => {
              const currentQuestion = questions[currentQuestionIndex];
              let optionClass = "bg-white border-3 border-purple-300 hover:bg-purple-50 text-purple-900 shadow-md";
              let emoji = "";
              
              if (currentQuestion.answered) {
                if (option === currentQuestion.english) {
                  optionClass = "bg-green-100 border-3 border-green-500 text-green-700 shadow-md";
                  emoji = " ✓";
                } else if (!currentQuestion.correct && option === currentQuestion.options.find(
                  opt => opt !== currentQuestion.english && 
                  !canAnswer && 
                  currentQuestion.answered
                )) {
                  optionClass = "bg-red-100 border-3 border-red-400 text-red-700 shadow-md";
                  emoji = " ✗";
                }
              }
              
              return (
                <Button
                  key={index}
                  variant="outline"
                  className={`p-5 rounded-xl text-xl font-medium h-auto ${optionClass}`}
                  onClick={() => handleOptionClick(option)}
                  disabled={!canAnswer}
                >
                  {option}{emoji}
                </Button>
              );
            })}
          </div>
        </div>
      )}
      
      {/* Progress Bar */}
      <div className="flex flex-col items-center mt-8 mb-8">
        <div className="mb-2 text-purple-700 font-medium text-lg">
          Your progress: {Math.round(progress)}%
        </div>
        <div className="bg-purple-200 rounded-full h-6 w-full max-w-md mt-1 mb-4 overflow-hidden">
          <div 
            className="bg-purple-500 h-full rounded-full transition-all duration-500" 
            style={{ width: `${progress}%` }}
          >
            {progress > 25 && (
              <div className="flex h-full items-center justify-center text-white text-sm font-bold">
                {Math.round(progress)}%
              </div>
            )}
          </div>
        </div>
        {progress > 0 && progress < 100 && (
          <div className="text-center text-green-600 font-medium animate-pulse">
            ¡Muy bien! Keep going!
          </div>
        )}
      </div>
      
      {/* Toucan Character with Speech Bubble */}
      <div className="flex items-end bg-purple-50 p-4 rounded-xl border-2 border-purple-100 shadow-sm mt-4">
        <svg width="120" height="120" viewBox="0 0 200 200" className="h-32">
          <path
            d="M100,20 C130,20 150,40 150,70 C150,85 140,95 135,100 C145,110 150,125 150,140 C150,170 130,190 100,190 C70,190 50,170 50,140 C50,125 55,110 65,100 C60,95 50,85 50,70 C50,40 70,20 100,20 Z"
            fill="#8B5CF6"
          />
          <circle cx="80" cy="70" r="12" fill="white" />
          <circle cx="80" cy="70" r="6" fill="black" />
          <circle cx="120" cy="70" r="12" fill="white" />
          <circle cx="120" cy="70" r="6" fill="black" />
          <path
            d="M90,90 C95,95 105,95 110,90"
            stroke="black"
            strokeWidth="3"
            fill="none"
          />
          {questions.length > 0 && progress === 100 && (
            <path
              d="M60,55 C65,45 75,55 60,55 Z M140,55 C135,45 125,55 140,55 Z"
              fill="#FFA500"
            />
          )}
          <path
            d="M70,115 C80,130 120,130 130,115"
            stroke="#FFA500"
            strokeWidth="15"
            fill="none"
            strokeLinecap="round"
          />
        </svg>
        <div className="relative ml-4 bg-white p-4 rounded-xl max-w-sm border-2 border-purple-200">
          <div className="absolute w-4 h-4 bg-white border-l-2 border-b-2 border-purple-200 transform rotate-45 -left-3 bottom-6"></div>
          <p className="text-purple-900 text-lg">{message}</p>
          {questions.length > 0 && progress === 100 && (
            <p className="mt-2 font-bold text-green-600 text-xl">¡Fantástico! You're a Spanish star! 🌟</p>
          )}
        </div>
      </div>
    </div>
  );
}
