import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Lightbulb, RotateCcw } from "lucide-react";
import { getVocabularyForLevel } from "@/lib/vocabulary";

interface TimeMatchProps {
  levelId: number;
  onComplete: () => void;
}

type TimeExpression = {
  id: number;
  expression: string;
  matched: boolean;
};

type Situation = {
  id: number;
  description: string;
  image: string;
  matched: boolean;
};

export default function TimeMatch({ levelId, onComplete }: TimeMatchProps) {
  const [timeExpressions, setTimeExpressions] = useState<TimeExpression[]>([]);
  const [situations, setSituations] = useState<Situation[]>([]);
  const [selectedExpression, setSelectedExpression] = useState<number | null>(null);
  const [selectedSituation, setSelectedSituation] = useState<number | null>(null);
  const [matchedPairs, setMatchedPairs] = useState<number>(0);
  const [message, setMessage] = useState<string>("¡Hola! Match each time expression with the correct situation!");
  const [hintsRemaining, setHintsRemaining] = useState<number>(3);

  // Define the time expressions and situations for different levels
  const getTimeContent = (levelId: number) => {
    // These would typically come from a database or API in a real app
    // For level 1 (basic greetings), we'll focus on time-of-day greetings
    if (levelId === 1) {
      return [
        {
          expression: "Buenos días",
          situation: "Morning greeting",
          image: "☀️" // In a real app, this would be a proper image URL
        },
        {
          expression: "Buenas tardes",
          situation: "Afternoon greeting",
          image: "🌤️"
        },
        {
          expression: "Buenas noches",
          situation: "Evening/night greeting",
          image: "🌙"
        },
        {
          expression: "¡Hasta mañana!",
          situation: "See you tomorrow",
          image: "📅"
        },
        {
          expression: "¡Hasta luego!",
          situation: "See you later",
          image: "👋"
        }
      ];
    }
    
    // Higher levels would have more complex time expressions
    if (levelId >= 17) { // Days of the week level
      return [
        {
          expression: "Lunes",
          situation: "The day after Sunday",
          image: "1️⃣"
        },
        {
          expression: "Martes",
          situation: "The day after Monday",
          image: "2️⃣"
        },
        {
          expression: "Miércoles",
          situation: "The middle day of the week",
          image: "3️⃣"
        },
        {
          expression: "Jueves",
          situation: "The day before Friday",
          image: "4️⃣"
        },
        {
          expression: "Viernes",
          situation: "The last weekday",
          image: "5️⃣"
        }
      ];
    }
    
    // Default for other levels - simple time expressions
    return [
      {
        expression: "Por la mañana",
        situation: "When you wake up and have breakfast",
        image: "🌅"
      },
      {
        expression: "Al mediodía",
        situation: "When the sun is highest in the sky",
        image: "🕛"
      },
      {
        expression: "Por la tarde",
        situation: "When school is over",
        image: "🏫"
      },
      {
        expression: "Por la noche",
        situation: "When it's dark and time for bed",
        image: "🛌"
      }
    ];
  };

  useEffect(() => {
    // Get time expressions and situations for the current level
    const timeContent = getTimeContent(levelId);
    
    // Create and shuffle time expressions
    const expressionsList = timeContent.map((item, index) => ({
      id: index,
      expression: item.expression,
      matched: false
    })).sort(() => Math.random() - 0.5);
    
    // Create and shuffle situations
    const situationsList = timeContent.map((item, index) => ({
      id: index,
      description: item.situation,
      image: item.image,
      matched: false
    })).sort(() => Math.random() - 0.5);
    
    setTimeExpressions(expressionsList);
    setSituations(situationsList);
    setSelectedExpression(null);
    setSelectedSituation(null);
    setMatchedPairs(0);
    setHintsRemaining(3);
  }, [levelId]);

  const handleExpressionClick = (id: number) => {
    // Skip if this expression is already matched
    if (timeExpressions.find(e => e.id === id)?.matched) return;
    
    setSelectedExpression(id);
    
    // If there's also a selected situation, check for a match
    if (selectedSituation !== null) {
      checkForMatch(id, selectedSituation);
    }
  };

  const handleSituationClick = (id: number) => {
    // Skip if this situation is already matched
    if (situations.find(s => s.id === id)?.matched) return;
    
    setSelectedSituation(id);
    
    // If there's also a selected expression, check for a match
    if (selectedExpression !== null) {
      checkForMatch(selectedExpression, id);
    }
  };

  const checkForMatch = (expressionId: number, situationId: number) => {
    // Check if the IDs match (they're from the same pair)
    if (expressionId === situationId) {
      // It's a match!
      setTimeExpressions(timeExpressions.map(e => 
        e.id === expressionId ? { ...e, matched: true } : e
      ));
      
      setSituations(situations.map(s => 
        s.id === situationId ? { ...s, matched: true } : s
      ));
      
      setMatchedPairs(prev => prev + 1);
      setMessage("¡Excelente! That's a perfect match!");
      
      // Check if all pairs are matched
      if (matchedPairs + 1 === timeExpressions.length) {
        setMessage("¡Fantástico! You've matched all the time expressions!");
        setTimeout(onComplete, 1500);
      }
    } else {
      // Not a match
      setMessage("¡Inténtalo otra vez! That's not the right match. Try again!");
    }
    
    // Reset selections
    setSelectedExpression(null);
    setSelectedSituation(null);
  };

  const handleHint = () => {
    if (hintsRemaining <= 0) return;
    
    // Find an unmatched pair and highlight it
    const unmatchedExpressions = timeExpressions.filter(e => !e.matched);
    if (unmatchedExpressions.length === 0) return;
    
    // Get a random unmatched expression
    const randomExpression = unmatchedExpressions[Math.floor(Math.random() * unmatchedExpressions.length)];
    
    // Find its matching situation
    const matchingSituation = situations.find(s => s.id === randomExpression.id);
    if (!matchingSituation) return;
    
    // Update message with the hint
    setMessage(`Hint: "${randomExpression.expression}" matches with "${matchingSituation.description}"`);
    
    // Decrease hints remaining
    setHintsRemaining(prev => prev - 1);
  };

  const handleRestart = () => {
    // Reset matches but keep the same items
    setTimeExpressions(prev => prev.map(e => ({ ...e, matched: false })));
    setSituations(prev => prev.map(s => ({ ...s, matched: false })));
    
    setSelectedExpression(null);
    setSelectedSituation(null);
    setMatchedPairs(0);
    setMessage("¡Vamos de nuevo! Let's try again!");
    setHintsRemaining(3);
  };

  return (
    <div className="p-6 bg-white rounded-xl shadow-md">
      <div className="mb-6 flex justify-between items-center">
        <h3 className="text-2xl font-bold text-neutral-800 font-nunito flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-500 mr-2">
            <circle cx="12" cy="12" r="10" />
            <polyline points="12 6 12 12 16 14" />
          </svg>
          Time Match
        </h3>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            className="bg-neutral-200 hover:bg-neutral-300 text-neutral-600"
            onClick={handleHint}
            disabled={hintsRemaining <= 0}
          >
            <Lightbulb className="h-4 w-4 mr-1" /> Hint ({hintsRemaining})
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="bg-neutral-200 hover:bg-neutral-300 text-neutral-600"
            onClick={handleRestart}
          >
            <RotateCcw className="h-4 w-4 mr-1" /> Restart
          </Button>
        </div>
      </div>
      
      <p className="text-neutral-600 mb-4">Match each Spanish time expression with the correct situation. Connect all pairs to complete the game!</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Time Expressions Column */}
        <div className="space-y-3">
          <h4 className="font-bold text-neutral-700 mb-2">Time Expressions</h4>
          {timeExpressions.map(expression => (
            <div
              key={expression.id}
              className={`
                p-4 rounded-lg cursor-pointer transition-all
                ${expression.matched ? 'bg-success bg-opacity-20 border-2 border-success' : 
                  selectedExpression === expression.id ? 'bg-blue-500 text-white' : 'bg-neutral-100 hover:bg-neutral-200'}
              `}
              onClick={() => handleExpressionClick(expression.id)}
            >
              <div className="text-xl font-bold font-nunito">{expression.expression}</div>
              {expression.matched && <div className="text-sm text-success">MATCHED</div>}
            </div>
          ))}
        </div>
        
        {/* Situations Column */}
        <div className="space-y-3">
          <h4 className="font-bold text-neutral-700 mb-2">Situations</h4>
          {situations.map(situation => (
            <div
              key={situation.id}
              className={`
                p-4 rounded-lg cursor-pointer transition-all
                ${situation.matched ? 'bg-success bg-opacity-20 border-2 border-success' : 
                  selectedSituation === situation.id ? 'bg-blue-500 text-white' : 'bg-neutral-100 hover:bg-neutral-200'}
              `}
              onClick={() => handleSituationClick(situation.id)}
            >
              <div className="flex items-center">
                <span className="text-2xl mr-3">{situation.image}</span>
                <span>{situation.description}</span>
              </div>
              {situation.matched && <div className="text-sm text-success">MATCHED</div>}
            </div>
          ))}
        </div>
      </div>
      
      {/* Progress Bar */}
      <div className="bg-neutral-200 rounded-full h-4 mb-6">
        <div 
          className="bg-secondary h-full rounded-full" 
          style={{ width: `${(matchedPairs / timeExpressions.length) * 100}%` }}
        ></div>
      </div>
      
      {/* Toucan Character with Speech Bubble */}
      <div className="flex items-end">
        <svg width="100" height="100" viewBox="0 0 200 200" className="h-24">
          <path
            d="M100,20 C130,20 150,40 150,70 C150,85 140,95 135,100 C145,110 150,125 150,140 C150,170 130,190 100,190 C70,190 50,170 50,140 C50,125 55,110 65,100 C60,95 50,85 50,70 C50,40 70,20 100,20 Z"
            fill="#FF6B6B"
          />
          <circle cx="80" cy="70" r="10" fill="white" />
          <circle cx="80" cy="70" r="5" fill="black" />
          <circle cx="120" cy="70" r="10" fill="white" />
          <circle cx="120" cy="70" r="5" fill="black" />
          <path
            d="M90,90 C95,95 105,95 110,90"
            stroke="black"
            strokeWidth="3"
            fill="none"
          />
          <path
            d="M70,115 C80,130 120,130 130,115"
            stroke="#FFA500"
            strokeWidth="15"
            fill="none"
            strokeLinecap="round"
          />
        </svg>
        <div className="relative ml-4 bg-neutral-100 p-4 rounded-xl max-w-xs">
          <div className="absolute w-4 h-4 bg-neutral-100 transform rotate-45 -left-2 bottom-4"></div>
          <p className="text-neutral-700">{message}</p>
        </div>
      </div>
    </div>
  );
}
