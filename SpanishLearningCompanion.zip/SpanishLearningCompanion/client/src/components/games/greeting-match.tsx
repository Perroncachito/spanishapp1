import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Lightbulb, RotateCcw } from "lucide-react";
import { getVocabularyForLevel } from "@/lib/vocabulary";

interface GreetingMatchProps {
  levelId: number;
  onComplete: () => void;
}

type Greeting = {
  id: number;
  text: string;
  matched: boolean;
};

type Situation = {
  id: number;
  description: string;
  matched: boolean;
};

export default function GreetingMatch({ levelId, onComplete }: GreetingMatchProps) {
  const [greetings, setGreetings] = useState<Greeting[]>([]);
  const [situations, setSituations] = useState<Situation[]>([]);
  const [selectedGreeting, setSelectedGreeting] = useState<number | null>(null);
  const [selectedSituation, setSelectedSituation] = useState<number | null>(null);
  const [matchedPairs, setMatchedPairs] = useState<number>(0);
  const [message, setMessage] = useState<string>("¡Hola! Match each Spanish greeting with the correct situation!");
  const [hintsRemaining, setHintsRemaining] = useState<number>(3);

  // Define the greeting-situation pairs for different levels
  const getGreetingSituations = (levelId: number) => {
    const vocabulary = getVocabularyForLevel(levelId);
    
    // Filter only greetings from vocabulary
    const greetingsVocab = vocabulary.filter(word => 
      word.type === "greeting" || word.contextual
    );
    
    // Create pairs with appropriate situations
    return greetingsVocab.map((word, index) => {
      // Handle words with slashes - take the first option
      const spanishWord = word.spanish.split("/")[0].trim();
      
      return {
        greeting: spanishWord,
        situation: word.contextExample || `When you want to say "${word.english}" in Spanish`
      };
    }).slice(0, 6); // Limit to 6 pairs for the game
  };

  useEffect(() => {
    // Get greeting-situation pairs for the current level
    const pairs = getGreetingSituations(levelId);
    
    // Create and shuffle greetings
    const greetingsList = pairs.map((pair, index) => ({
      id: index,
      text: pair.greeting,
      matched: false
    })).sort(() => Math.random() - 0.5);
    
    // Create and shuffle situations
    const situationsList = pairs.map((pair, index) => ({
      id: index,
      description: pair.situation,
      matched: false
    })).sort(() => Math.random() - 0.5);
    
    setGreetings(greetingsList);
    setSituations(situationsList);
    setSelectedGreeting(null);
    setSelectedSituation(null);
    setMatchedPairs(0);
  }, [levelId]);

  const handleGreetingClick = (id: number) => {
    // Skip if this greeting is already matched
    if (greetings.find(g => g.id === id)?.matched) return;
    
    setSelectedGreeting(id);
    
    // If there's also a selected situation, check for a match
    if (selectedSituation !== null) {
      checkForMatch(id, selectedSituation);
    }
  };

  const handleSituationClick = (id: number) => {
    // Skip if this situation is already matched
    if (situations.find(s => s.id === id)?.matched) return;
    
    setSelectedSituation(id);
    
    // If there's also a selected greeting, check for a match
    if (selectedGreeting !== null) {
      checkForMatch(selectedGreeting, id);
    }
  };

  const checkForMatch = (greetingId: number, situationId: number) => {
    // Check if the IDs match (they're from the same pair)
    if (greetingId === situationId) {
      // It's a match!
      setGreetings(greetings.map(g => 
        g.id === greetingId ? { ...g, matched: true } : g
      ));
      
      setSituations(situations.map(s => 
        s.id === situationId ? { ...s, matched: true } : s
      ));
      
      setMatchedPairs(prev => prev + 1);
      setMessage("¡Excelente! That's a perfect match!");
      
      // Check if all pairs are matched
      if (matchedPairs + 1 === greetings.length) {
        setMessage("¡Fantástico! You've matched all the greetings!");
        setTimeout(onComplete, 1500);
      }
    } else {
      // Not a match
      setMessage("¡Inténtalo otra vez! That's not the right match. Try again!");
    }
    
    // Reset selections
    setSelectedGreeting(null);
    setSelectedSituation(null);
  };

  const handleHint = () => {
    if (hintsRemaining <= 0) return;
    
    // Find an unmatched pair and highlight it
    const unmatchedGreetings = greetings.filter(g => !g.matched);
    if (unmatchedGreetings.length === 0) return;
    
    // Get a random unmatched greeting
    const randomGreeting = unmatchedGreetings[Math.floor(Math.random() * unmatchedGreetings.length)];
    
    // Find its matching situation
    const matchingSituation = situations.find(s => s.id === randomGreeting.id);
    if (!matchingSituation) return;
    
    // Update message with the hint
    setMessage(`Hint: "${randomGreeting.text}" matches with "${matchingSituation.description}"`);
    
    // Decrease hints remaining
    setHintsRemaining(prev => prev - 1);
  };

  const handleRestart = () => {
    // Reshuffle all items
    setGreetings(prev => [...prev.map(g => ({ ...g, matched: false }))].sort(() => Math.random() - 0.5));
    setSituations(prev => [...prev.map(s => ({ ...s, matched: false }))].sort(() => Math.random() - 0.5));
    
    setSelectedGreeting(null);
    setSelectedSituation(null);
    setMatchedPairs(0);
    setMessage("¡Vamos de nuevo! Let's try again!");
    setHintsRemaining(3);
  };

  return (
    <div className="p-6 bg-white rounded-xl shadow-md">
      <div className="mb-6 flex justify-between items-center">
        <h3 className="text-2xl font-bold text-neutral-800 font-nunito flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary mr-2">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
          </svg>
          Greeting Match
        </h3>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            className="bg-neutral-200 hover:bg-neutral-300 text-neutral-600"
            onClick={handleHint}
            disabled={hintsRemaining <= 0}
          >
            <Lightbulb className="h-4 w-4 mr-1" /> Hint ({hintsRemaining})
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="bg-neutral-200 hover:bg-neutral-300 text-neutral-600"
            onClick={handleRestart}
          >
            <RotateCcw className="h-4 w-4 mr-1" /> Restart
          </Button>
        </div>
      </div>
      
      <p className="text-neutral-600 mb-4">Match each Spanish greeting with the correct situation. Connect all pairs to complete the game!</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Greetings Column */}
        <div className="space-y-3">
          <h4 className="font-bold text-neutral-700 mb-2">Spanish Greetings</h4>
          {greetings.map(greeting => (
            <div
              key={greeting.id}
              className={`
                p-4 rounded-lg cursor-pointer transition-all
                ${greeting.matched ? 'bg-success bg-opacity-20 border-2 border-success' : 
                  selectedGreeting === greeting.id ? 'bg-primary text-white' : 'bg-neutral-100 hover:bg-neutral-200'}
              `}
              onClick={() => handleGreetingClick(greeting.id)}
            >
              <div className="text-xl font-bold font-nunito">{greeting.text}</div>
              {greeting.matched && <div className="text-sm text-success">MATCHED</div>}
            </div>
          ))}
        </div>
        
        {/* Situations Column */}
        <div className="space-y-3">
          <h4 className="font-bold text-neutral-700 mb-2">When to Use</h4>
          {situations.map(situation => (
            <div
              key={situation.id}
              className={`
                p-4 rounded-lg cursor-pointer transition-all
                ${situation.matched ? 'bg-success bg-opacity-20 border-2 border-success' : 
                  selectedSituation === situation.id ? 'bg-secondary text-white' : 'bg-neutral-100 hover:bg-neutral-200'}
              `}
              onClick={() => handleSituationClick(situation.id)}
            >
              <div className="text-md">{situation.description}</div>
              {situation.matched && <div className="text-sm text-success">MATCHED</div>}
            </div>
          ))}
        </div>
      </div>
      
      {/* Progress Bar */}
      <div className="bg-neutral-200 rounded-full h-4 mb-6">
        <div 
          className="bg-secondary h-full rounded-full" 
          style={{ width: `${(matchedPairs / greetings.length) * 100}%` }}
        ></div>
      </div>
      
      {/* Toucan Character with Speech Bubble */}
      <div className="flex items-end">
        <svg width="100" height="100" viewBox="0 0 200 200" className="h-24">
          <path
            d="M100,20 C130,20 150,40 150,70 C150,85 140,95 135,100 C145,110 150,125 150,140 C150,170 130,190 100,190 C70,190 50,170 50,140 C50,125 55,110 65,100 C60,95 50,85 50,70 C50,40 70,20 100,20 Z"
            fill="#FF6B6B"
          />
          <circle cx="80" cy="70" r="10" fill="white" />
          <circle cx="80" cy="70" r="5" fill="black" />
          <circle cx="120" cy="70" r="10" fill="white" />
          <circle cx="120" cy="70" r="5" fill="black" />
          <path
            d="M90,90 C95,95 105,95 110,90"
            stroke="black"
            strokeWidth="3"
            fill="none"
          />
          <path
            d="M70,115 C80,130 120,130 130,115"
            stroke="#FFA500"
            strokeWidth="15"
            fill="none"
            strokeLinecap="round"
          />
        </svg>
        <div className="relative ml-4 bg-neutral-100 p-4 rounded-xl max-w-xs">
          <div className="absolute w-4 h-4 bg-neutral-100 transform rotate-45 -left-2 bottom-4"></div>
          <p className="text-neutral-700">{message}</p>
        </div>
      </div>
    </div>
  );
}
