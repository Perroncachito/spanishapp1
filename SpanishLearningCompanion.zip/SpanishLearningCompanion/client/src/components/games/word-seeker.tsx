import React, { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Lightbulb, RotateCcw } from "lucide-react";
import { getVocabularyForLevel } from "@/lib/vocabulary";

interface WordSeekerProps {
  levelId: number;
  onComplete: () => void;
  difficulty?: "easy" | "normal";
}

type WordPosition = {
  word: string;
  startRow: number;
  startCol: number;
  direction: "horizontal" | "vertical" | "diagonal";
  found: boolean;
};

type Cell = {
  row: number;
  col: number;
  letter: string;
  selected: boolean;
  inFoundWord: boolean;
};

// Smaller grid and fewer words for easy mode (kid-friendly)
const GRID_SIZE_NORMAL = 10;
const GRID_SIZE_EASY = 6; // Even smaller grid for kids
const MAX_WORDS_NORMAL = 8;
const MAX_WORDS_EASY = 3; // Just 3 words for younger kids

export default function WordSeeker({ levelId, onComplete, difficulty = "normal" }: WordSeekerProps) {
  const [grid, setGrid] = useState<Cell[][]>([]);
  const [wordPositions, setWordPositions] = useState<WordPosition[]>([]);
  const [foundWords, setFoundWords] = useState<string[]>([]);
  const [message, setMessage] = useState<string>("¡Hola! Find the Spanish words hidden in the grid!");
  const [hintsRemaining, setHintsRemaining] = useState<number>(3);
  const [selectionStart, setSelectionStart] = useState<{row: number, col: number} | null>(null);
  const [currentSelection, setCurrentSelection] = useState<{row: number, col: number}[]>([]);
  const [isSelecting, setIsSelecting] = useState(false);
  
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Determine grid size and max words based on difficulty
    const gridSize = difficulty === "easy" ? GRID_SIZE_EASY : GRID_SIZE_NORMAL;
    const maxWords = difficulty === "easy" ? MAX_WORDS_EASY : MAX_WORDS_NORMAL;
    const maxHints = difficulty === "easy" ? 5 : 3;
    
    // Get vocabulary for the current level
    const vocabulary = getVocabularyForLevel(levelId);
    
    // Select words to include in puzzle
    const wordsToInclude = vocabulary
      .filter(word => {
        // Take the first option if there are slashes
        const spanishWord = word.spanish.split("/")[0].trim();
        // Ensure word is short enough to fit in grid
        return spanishWord.length <= gridSize;
      })
      .slice(0, maxWords)
      .map(word => {
        // Take the first option if there are slashes and remove spaces
        return word.spanish.split("/")[0].trim().toUpperCase().replace(/\s/g, "");
      });
    
    // Create an empty grid
    const emptyGrid: Cell[][] = Array(gridSize).fill(null).map((_, rowIndex) =>
      Array(gridSize).fill(null).map((_, colIndex) => ({
        row: rowIndex,
        col: colIndex,
        letter: "",
        selected: false,
        inFoundWord: false
      }))
    );
    
    // Place words in the grid
    const positions: WordPosition[] = [];
    const filledGrid = placeWordsInGrid(emptyGrid, wordsToInclude, positions, gridSize);
    
    // Fill empty cells with random letters
    for (let row = 0; row < gridSize; row++) {
      for (let col = 0; col < gridSize; col++) {
        if (filledGrid[row][col].letter === "") {
          const randomLetter = String.fromCharCode(65 + Math.floor(Math.random() * 26)); // A-Z
          filledGrid[row][col].letter = randomLetter;
        }
      }
    }
    
    setGrid(filledGrid);
    setWordPositions(positions);
    setFoundWords([]);
    setHintsRemaining(maxHints);
    
    // Set a more kid-friendly message for easy mode
    if (difficulty === "easy") {
      setMessage("¡Vamos a buscar palabras! Let's find the hidden Spanish words!");
    } else {
      setMessage("¡Busca las palabras en español! Find the Spanish words in the grid!");
    }
  }, [levelId, difficulty]);

  // Function to place words in the grid
  const placeWordsInGrid = (grid: Cell[][], words: string[], positions: WordPosition[], gridSize: number): Cell[][] => {
    const copyGrid = JSON.parse(JSON.stringify(grid));
    
    // Try to place each word
    for (const word of words) {
      let placed = false;
      
      // Try multiple times to place the word
      for (let attempts = 0; attempts < 100 && !placed; attempts++) {
        // Choose random starting position and direction
        const row = Math.floor(Math.random() * gridSize);
        const col = Math.floor(Math.random() * gridSize);
        
        // In easy mode, prefer horizontal and vertical directions over diagonal
        let directions: ("horizontal" | "vertical" | "diagonal")[];
        if (difficulty === "easy") {
          // Higher chance of horizontal and vertical for easier finding
          directions = ["horizontal", "horizontal", "vertical", "vertical", "diagonal"];
        } else {
          directions = ["horizontal", "vertical", "diagonal"];
        }
        
        const direction = directions[Math.floor(Math.random() * directions.length)];
        
        // Check if word fits in the chosen direction
        if (wordFits(copyGrid, word, row, col, direction, gridSize)) {
          // Place the word
          placeWord(copyGrid, word, row, col, direction);
          positions.push({
            word,
            startRow: row,
            startCol: col,
            direction,
            found: false
          });
          placed = true;
        }
      }
    }
    
    return copyGrid;
  };

  // Check if a word fits at the given position and direction
  const wordFits = (grid: Cell[][], word: string, startRow: number, startCol: number, direction: string, gridSize: number): boolean => {
    const wordLength = word.length;
    
    for (let i = 0; i < wordLength; i++) {
      let row = startRow, col = startCol;
      
      if (direction === "horizontal") {
        col += i;
      } else if (direction === "vertical") {
        row += i;
      } else if (direction === "diagonal") {
        row += i;
        col += i;
      }
      
      // Check if position is out of bounds
      if (row < 0 || row >= gridSize || col < 0 || col >= gridSize) {
        return false;
      }
      
      // Check if cell is empty or already has the same letter
      if (grid[row][col].letter !== "" && grid[row][col].letter !== word[i]) {
        return false;
      }
    }
    
    return true;
  };

  // Place a word in the grid
  const placeWord = (grid: Cell[][], word: string, startRow: number, startCol: number, direction: string) => {
    const wordLength = word.length;
    
    for (let i = 0; i < wordLength; i++) {
      let row = startRow, col = startCol;
      
      if (direction === "horizontal") {
        col += i;
      } else if (direction === "vertical") {
        row += i;
      } else if (direction === "diagonal") {
        row += i;
        col += i;
      }
      
      grid[row][col].letter = word[i];
    }
  };

  const handleCellMouseDown = (row: number, col: number) => {
    setIsSelecting(true);
    setSelectionStart({ row, col });
    setCurrentSelection([{ row, col }]);
    
    // Update grid selection
    const newGrid = [...grid];
    newGrid[row][col].selected = true;
    setGrid(newGrid);
  };

  const handleCellMouseOver = (row: number, col: number) => {
    if (!isSelecting || !selectionStart) return;
    
    // Only allow selection in straight lines (horizontal, vertical, diagonal)
    const rowDiff = row - selectionStart.row;
    const colDiff = col - selectionStart.col;
    
    let newSelection: {row: number, col: number}[] = [selectionStart];
    
    if (rowDiff === 0 && colDiff !== 0) {
      // Horizontal
      const direction = colDiff > 0 ? 1 : -1;
      for (let c = 1; c <= Math.abs(colDiff); c++) {
        newSelection.push({ row: selectionStart.row, col: selectionStart.col + (c * direction) });
      }
    } else if (colDiff === 0 && rowDiff !== 0) {
      // Vertical
      const direction = rowDiff > 0 ? 1 : -1;
      for (let r = 1; r <= Math.abs(rowDiff); r++) {
        newSelection.push({ row: selectionStart.row + (r * direction), col: selectionStart.col });
      }
    } else if (Math.abs(rowDiff) === Math.abs(colDiff)) {
      // Diagonal
      const rowDirection = rowDiff > 0 ? 1 : -1;
      const colDirection = colDiff > 0 ? 1 : -1;
      for (let i = 1; i <= Math.abs(rowDiff); i++) {
        newSelection.push({ 
          row: selectionStart.row + (i * rowDirection), 
          col: selectionStart.col + (i * colDirection) 
        });
      }
    } else {
      // Not a straight line, keep just the starting point
      return;
    }
    
    setCurrentSelection(newSelection);
    
    // Update grid selection
    const newGrid = grid.map(row => row.map(cell => ({
      ...cell,
      selected: newSelection.some(pos => pos.row === cell.row && pos.col === cell.col)
    })));
    
    setGrid(newGrid);
  };

  const handleCellMouseUp = () => {
    if (!isSelecting) return;
    setIsSelecting(false);
    
    // Check if selection is a word
    const selectedWord = currentSelection.map(pos => grid[pos.row][pos.col].letter).join("");
    
    // Check if this is one of our hidden words
    const matchedPosition = wordPositions.find(position => 
      position.word === selectedWord && !position.found
    );
    
    if (matchedPosition) {
      // Word found!
      setFoundWords([...foundWords, selectedWord]);
      setMessage(`¡Muy bien! You found "${selectedWord}"!`);
      
      // Mark word as found
      const newPositions = wordPositions.map(position => 
        position.word === selectedWord ? { ...position, found: true } : position
      );
      setWordPositions(newPositions);
      
      // Mark cells as part of found word
      const newGrid = grid.map(row => row.map(cell => ({
        ...cell,
        selected: false,
        inFoundWord: cell.inFoundWord || currentSelection.some(pos => pos.row === cell.row && pos.col === cell.col)
      })));
      
      setGrid(newGrid);
      
      // Check if all words are found
      if (foundWords.length + 1 === wordPositions.length) {
        setMessage("¡Fantástico! You've found all the words!");
        setTimeout(onComplete, 1500);
      }
    } else {
      // Not a hidden word
      // Reset selection
      const newGrid = grid.map(row => row.map(cell => ({
        ...cell,
        selected: false
      })));
      
      setGrid(newGrid);
    }
    
    setCurrentSelection([]);
  };

  const handleHint = () => {
    if (hintsRemaining <= 0) return;
    
    // Find an unfound word
    const unfoundWords = wordPositions.filter(pos => !pos.found);
    if (unfoundWords.length === 0) return;
    
    // Select a random unfound word
    const wordToHint = unfoundWords[Math.floor(Math.random() * unfoundWords.length)];
    
    // Flash the word's position briefly
    const hintCells: {row: number, col: number}[] = [];
    
    for (let i = 0; i < wordToHint.word.length; i++) {
      let row = wordToHint.startRow, col = wordToHint.startCol;
      
      if (wordToHint.direction === "horizontal") {
        col += i;
      } else if (wordToHint.direction === "vertical") {
        row += i;
      } else if (wordToHint.direction === "diagonal") {
        row += i;
        col += i;
      }
      
      hintCells.push({ row, col });
    }
    
    // Update grid to highlight the hint
    const newGrid = grid.map(row => row.map(cell => ({
      ...cell,
      selected: hintCells.some(pos => pos.row === cell.row && pos.col === cell.col)
    })));
    
    setGrid(newGrid);
    
    // Make the hint message more kid-friendly in easy mode
    if (difficulty === "easy") {
      if (wordToHint.direction === "horizontal") {
        setMessage(`Hint: Look for "${wordToHint.word}" going across (→) from row ${wordToHint.startRow + 1}, column ${wordToHint.startCol + 1}`);
      } else if (wordToHint.direction === "vertical") {
        setMessage(`Hint: Look for "${wordToHint.word}" going down (↓) from row ${wordToHint.startRow + 1}, column ${wordToHint.startCol + 1}`);
      } else {
        setMessage(`Hint: Look for "${wordToHint.word}" going diagonal (↘) from row ${wordToHint.startRow + 1}, column ${wordToHint.startCol + 1}`);
      }
    } else {
      setMessage(`Hint: Look for "${wordToHint.word}" starting at position (${wordToHint.startRow + 1}, ${wordToHint.startCol + 1})`);
    }
    
    // Reset after a longer moment in easy mode for kids to see the hint better
    const hintDuration = difficulty === "easy" ? 3000 : 2000;
    setTimeout(() => {
      const resetGrid = grid.map(row => row.map(cell => ({
        ...cell,
        selected: false
      })));
      
      setGrid(resetGrid);
    }, hintDuration);
    
    // Decrease hints remaining
    setHintsRemaining(prev => prev - 1);
  };

  const handleRestart = () => {
    // Reset everything but keep the same words and positions
    const resetGrid = grid.map(row => row.map(cell => ({
      ...cell,
      selected: false,
      inFoundWord: false
    })));
    
    const resetPositions = wordPositions.map(position => ({
      ...position,
      found: false
    }));
    
    setGrid(resetGrid);
    setWordPositions(resetPositions);
    setFoundWords([]);
    setMessage("¡Vamos de nuevo! Let's try again!");
    
    // Reset hints based on difficulty
    const maxHints = difficulty === "easy" ? 5 : 3;
    setHintsRemaining(maxHints);
  };

  // Determine grid size for the grid CSS
  const gridSize = difficulty === "easy" ? GRID_SIZE_EASY : GRID_SIZE_NORMAL;
  
  return (
    <div className={`${difficulty === "easy" ? "p-8" : "p-6"} bg-gradient-to-b from-indigo-50 via-white to-purple-50 rounded-2xl shadow-xl border-2 border-indigo-200 relative overflow-hidden`}>
      {/* Fun background elements for kids - only in easy mode */}
      {difficulty === "easy" && (
        <>
          <div className="absolute top-0 left-0 w-40 h-40 bg-yellow-200 rounded-full opacity-20 -translate-x-20 -translate-y-20 blur-md"></div>
          <div className="absolute bottom-0 right-0 w-60 h-60 bg-purple-200 rounded-full opacity-20 translate-x-20 translate-y-20 blur-md"></div>
          <div className="absolute top-1/4 right-10 w-20 h-20 bg-blue-200 rounded-full opacity-20 blur-sm"></div>
        </>
      )}
      <div className="mb-6 flex justify-between items-center relative z-10">
        <h3 className={`${difficulty === "easy" ? "text-3xl" : "text-2xl"} font-bold text-blue-700 font-nunito flex items-center`}>
          <svg xmlns="http://www.w3.org/2000/svg" width={difficulty === "easy" ? "36" : "28"} height={difficulty === "easy" ? "36" : "28"} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-500 mr-3">
            <circle cx="11" cy="11" r="8" fill="#EFF6FF" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          Word Seeker
        </h3>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size={difficulty === "easy" ? "lg" : "sm"}
            className={`${difficulty === "easy" ? "bg-amber-100 hover:bg-amber-200 text-amber-700 border-amber-300" : "bg-neutral-200 hover:bg-neutral-300 text-neutral-600"}`}
            onClick={handleHint}
            disabled={hintsRemaining <= 0}
          >
            <Lightbulb className={`${difficulty === "easy" ? "h-5 w-5" : "h-4 w-4"} mr-1`} /> Hint ({hintsRemaining})
          </Button>
          <Button
            variant="outline"
            size={difficulty === "easy" ? "lg" : "sm"}
            className={`${difficulty === "easy" ? "bg-blue-100 hover:bg-blue-200 text-blue-700 border-blue-300" : "bg-neutral-200 hover:bg-neutral-300 text-neutral-600"}`}
            onClick={handleRestart}
          >
            <RotateCcw className={`${difficulty === "easy" ? "h-5 w-5" : "h-4 w-4"} mr-1`} /> Restart
          </Button>
        </div>
      </div>
      
      {difficulty === "easy" ? (
        <div className="bg-white border-2 border-blue-200 p-4 mb-6 rounded-xl shadow-sm relative z-10">
          <div className="flex items-start">
            <div className="bg-blue-500 rounded-full p-2 mr-3 flex-shrink-0">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="16" x2="12" y2="12"></line>
                <line x1="12" y1="8" x2="12.01" y2="8"></line>
              </svg>
            </div>
            <div>
              <h4 className="text-lg font-bold text-blue-700 mb-1">How to Play:</h4>
              <p className="text-lg text-neutral-600">
                Find all these Spanish words hidden in the puzzle grid! 🎮
              </p>
              <div className="flex flex-wrap gap-2 mt-2">
                <div className="bg-blue-100 px-3 py-1 rounded-full text-blue-700 font-medium flex items-center">
                  <span className="mr-1">→</span> Across
                </div>
                <div className="bg-green-100 px-3 py-1 rounded-full text-green-700 font-medium flex items-center">
                  <span className="mr-1">↓</span> Down
                </div>
                <div className="bg-purple-100 px-3 py-1 rounded-full text-purple-700 font-medium flex items-center">
                  <span className="mr-1">↘</span> Diagonal
                </div>
              </div>
              <p className="text-blue-600 mt-2 font-medium">
                Drag your mouse over the letters to select words! ✨
              </p>
            </div>
          </div>
        </div>
      ) : (
        <p className="text-neutral-600 mb-4 relative z-10">Find all the Spanish words hidden in the grid. Words can be horizontal, vertical, or diagonal.</p>
      )}
      
      <div className="flex flex-col md:flex-row gap-6 mb-6">
        {/* Word Seeker Grid */}
        <div
          ref={gridRef}
          className="rounded-lg overflow-hidden select-none touch-none shadow-lg"
          onMouseUp={handleCellMouseUp}
          onMouseLeave={handleCellMouseUp}
        >
          {/* Column Headers in Easy Mode */}
          {difficulty === "easy" && (
            <div className="grid gap-0 bg-gradient-to-r from-blue-500 to-purple-500 border-b-4 border-blue-700 rounded-t-lg" 
                 style={{ gridTemplateColumns: `repeat(${gridSize}, minmax(0, 1fr))` }}>
              {Array(gridSize).fill(0).map((_, i) => (
                <div key={`col-${i}`} className="h-12 flex items-center justify-center text-xl font-bold text-white">
                  {i + 1}
                </div>
              ))}
            </div>
          )}
          <div className="grid gap-0 border-4 border-blue-300 bg-blue-50 rounded-b-lg shadow-inner" 
               style={{ gridTemplateColumns: `repeat(${gridSize}, minmax(0, 1fr))` }}>
            {grid.map((row, rowIndex) => (
              <React.Fragment key={`row-${rowIndex}`}>
                {row.map(cell => (
                  <div
                    key={`${cell.row}-${cell.col}`}
                    className={`
                      ${difficulty === "easy" ? "w-14 h-14 text-2xl" : "w-10 h-10 md:w-11 md:h-11 text-lg"} 
                      flex items-center justify-center font-bold
                      border-2 ${difficulty === "easy" ? "border-blue-200" : "border-neutral-200"} 
                      select-none transition-all duration-200 transform hover:scale-105
                      ${cell.inFoundWord ? 'bg-green-100 text-green-700 border-green-300 font-bold shadow-md' : 
                        cell.selected ? 'bg-yellow-100 text-yellow-800 border-yellow-300 shadow-md' : 
                        (difficulty === "easy" ? 'bg-white hover:bg-blue-100 text-blue-800' : 'bg-white text-neutral-800')}
                    `}
                    onMouseDown={() => handleCellMouseDown(cell.row, cell.col)}
                    onMouseOver={() => handleCellMouseOver(cell.row, cell.col)}
                  >
                    {cell.letter}
                  </div>
                ))}
              </React.Fragment>
            ))}
          </div>
        </div>
        
        {/* Word List */}
        <div className={`${difficulty === "easy" ? 
          "bg-gradient-to-b from-purple-100 to-blue-100 border-2 border-purple-200" : 
          "bg-neutral-100"} rounded-lg p-4 flex-1 shadow-lg`}>
          <h4 className={`${difficulty === "easy" ? 
            "text-xl text-blue-800 bg-white px-4 py-2 rounded-md inline-block shadow-sm border border-blue-200" : 
            "text-lg text-neutral-700"} font-bold mb-4`}>
            {difficulty === "easy" ? "🔍 Words to Find:" : "Words to Find:"}
          </h4>
          <div className="grid grid-cols-2 gap-3">
            {wordPositions.map((position, index) => (
              <div
                key={index}
                className={`
                  px-4 py-2 rounded-md font-medium transition-all duration-300
                  ${position.found ? 
                    (difficulty === "easy" ? 'bg-green-100 text-green-700 border-2 border-green-300 shadow-inner' : 'bg-success bg-opacity-20 text-success line-through') : 
                    (difficulty === "easy" ? 'bg-white border-2 border-purple-300 text-purple-800 shadow-sm hover:shadow-md' : 'bg-neutral-200 text-neutral-600')}
                  ${difficulty === "easy" ? "text-lg" : ""}
                `}
              >
                {position.word}
                {difficulty === "easy" && position.found && (
                  <span className="ml-2 animate-bounce inline-block">✅</span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Progress Bar - with text indicator in easy mode */}
      <div className="mb-6">
        {difficulty === "easy" && (
          <div className="flex justify-between mb-2 bg-purple-50 p-3 rounded-lg border border-purple-200">
            <span className="text-purple-700 font-medium flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-purple-500">
                <path d="M22 12h-4l-3 9L9 3l-3 9H2"/>
              </svg>
              Your progress:
            </span>
            <span className="font-bold text-indigo-600 bg-white px-3 py-1 rounded-full border border-indigo-200">
              {foundWords.length} of {wordPositions.length} words found
            </span>
          </div>
        )}
        <div className={`bg-gradient-to-r from-blue-100 to-purple-100 rounded-full ${difficulty === "easy" ? "h-8" : "h-5"} mb-2 shadow-inner border border-blue-200`}>
          <div 
            className="bg-gradient-to-r from-blue-500 to-purple-600 h-full rounded-full transition-all duration-500 shadow-sm" 
            style={{ width: `${(foundWords.length / wordPositions.length) * 100}%` }}
          >
            {difficulty === "easy" && (
              <div className="h-full flex items-center justify-center text-sm font-bold text-white">
                {Math.round((foundWords.length / wordPositions.length) * 100)}%
              </div>
            )}
          </div>
        </div>
        {difficulty === "easy" && foundWords.length > 0 && foundWords.length < wordPositions.length && (
          <div className="text-center text-base text-indigo-600 font-medium animate-pulse bg-white p-2 rounded-md border border-indigo-200 shadow-sm">
            ¡Excelente! Keep searching for more words! 🔍
          </div>
        )}
      </div>
      
      {/* Toucan Character with Speech Bubble */}
      <div className="flex items-end bg-gradient-to-r from-blue-50 to-purple-50 p-5 rounded-xl border-2 border-blue-200 shadow-md mt-4 relative z-10">
        <div className="relative">
          <div className="absolute -top-2 -left-2 w-10 h-10 bg-yellow-300 rounded-full opacity-40 animate-pulse"></div>
          <svg width="120" height="120" viewBox="0 0 200 200" className={difficulty === "easy" ? "h-36" : "h-24"}>
            <path
              d="M100,20 C130,20 150,40 150,70 C150,85 140,95 135,100 C145,110 150,125 150,140 C150,170 130,190 100,190 C70,190 50,170 50,140 C50,125 55,110 65,100 C60,95 50,85 50,70 C50,40 70,20 100,20 Z"
              fill="#6366F1"
            />
            <circle cx="80" cy="70" r="14" fill="white" />
            <circle cx="80" cy="70" r="7" fill="black" />
            <circle cx="82" cy="66" r="3" fill="white" />
            <circle cx="120" cy="70" r="14" fill="white" />
            <circle cx="120" cy="70" r="7" fill="black" />
            <circle cx="122" cy="66" r="3" fill="white" />
            <path
              d="M90,90 C95,95 105,95 110,90"
              stroke="black"
              strokeWidth="3"
              fill="none"
            />
            <path
              d="M70,115 C80,130 120,130 130,115"
              stroke="#FFA500"
              strokeWidth="15"
              fill="none"
              strokeLinecap="round"
            />
            {foundWords.length > 0 && difficulty === "easy" && (
              <path
                d="M60,55 C65,45 75,55 60,55 Z M140,55 C135,45 125,55 140,55 Z"
                fill="#FFA500"
              />
            )}
          </svg>
        </div>
        <div className="relative ml-4 bg-white p-5 rounded-xl max-w-sm border-2 border-indigo-200 shadow transition-all duration-300 transform hover:scale-105">
          <div className="absolute w-5 h-5 bg-white border-l-2 border-b-2 border-indigo-200 transform rotate-45 -left-3 bottom-8"></div>
          <p className="text-indigo-800 text-lg font-medium">{message}</p>
          {foundWords.length === wordPositions.length && difficulty === "easy" && (
            <div className="mt-3 p-2 bg-green-50 border border-green-200 rounded-lg">
              <p className="font-bold text-green-600 text-xl flex items-center justify-center">
                <span className="animate-bounce mr-2">🌟</span>
                ¡Fantástico! You're a Spanish star!
                <span className="animate-bounce ml-2">🌟</span>
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
