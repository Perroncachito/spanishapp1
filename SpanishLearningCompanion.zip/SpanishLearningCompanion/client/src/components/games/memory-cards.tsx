import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Lightbulb, RotateCcw } from "lucide-react";
import { getVocabularyForLevel } from "@/lib/vocabulary";

interface MemoryCardsProps {
  levelId: number;
  onComplete: () => void;
  difficulty?: "easy" | "normal";
}

type Card = {
  id: number;
  content: string;
  type: "spanish" | "english";
  isFlipped: boolean;
  isMatched: boolean;
  pairId: number;
};

export default function MemoryCards({ levelId, onComplete, difficulty = "easy" }: MemoryCardsProps) {
  const [cards, setCards] = useState<Card[]>([]);
  const [selectedCards, setSelectedCards] = useState<number[]>([]);
  const [matchedPairs, setMatchedPairs] = useState<number>(0);
  const [message, setMessage] = useState<string>("¡Hola! Match the Spanish words with their English translations!");
  const [hintsRemaining, setHintsRemaining] = useState<number>(3);
  
  useEffect(() => {
    // Get vocabulary for the current level
    const vocabulary = getVocabularyForLevel(levelId);
    
    // Create paired cards (Spanish + English)
    // Use fewer pairs in easy mode to make it easier for kids
    const pairsCount = difficulty === "easy" ? 3 : 8; // 8 pairs (16 cards) in normal mode, just 3 pairs (6 cards) in easy mode for younger kids
    const pairsToUse = vocabulary.slice(0, pairsCount);
    
    // Create card pairs with proper handling of slashes in Spanish words
    const cardPairs: Card[] = [];
    
    // Process each vocabulary word pair
    pairsToUse.forEach((word, index) => {
      // Handle words with slashes - take the first option
      const spanishWord = word.spanish.split("/")[0].trim();
      
      // Create Spanish card
      cardPairs.push({ 
        id: index * 2, 
        content: spanishWord, 
        type: "spanish", 
        isFlipped: false, 
        isMatched: false,
        pairId: index
      });
      
      // Create English card
      cardPairs.push({ 
        id: index * 2 + 1, 
        content: word.english, 
        type: "english", 
        isFlipped: false, 
        isMatched: false,
        pairId: index
      });
    });
    
    // Shuffle the cards, but not too much in easy mode
    let shuffledCards = [...cardPairs];
    
    if (difficulty === "easy") {
      // In easy mode, keep pairs somewhat close to each other
      // This creates a more predictable pattern that's easier for kids
      shuffledCards = [];
      for (let i = 0; i < pairsToUse.length; i++) {
        // Place spanish and english cards within 3 positions of each other
        const pos1 = i * 2;
        const pos2 = pos1 + 1;
        shuffledCards[pos1] = cardPairs[i * 2]; // Spanish
        shuffledCards[pos2] = cardPairs[i * 2 + 1]; // English
      }
      
      // Minimal shuffling for easy mode
      shuffledCards = shuffledCards.sort(() => Math.random() > 0.7 ? 1 : -1);
    } else {
      // Full random shuffle for normal mode
      shuffledCards = shuffledCards.sort(() => Math.random() - 0.5);
    }
    
    // Set up the game
    setCards(shuffledCards);
    setSelectedCards([]);
    setMatchedPairs(0);
    
    // Set higher number of hints in easy mode
    setHintsRemaining(difficulty === "easy" ? 5 : 3);
  }, [levelId, difficulty]);
  
  // Handle card click
  const handleCardClick = (id: number) => {
    // Ignore click if there are already two cards flipped or if the card is already flipped/matched
    const card = cards.find(c => c.id === id);
    if (
      selectedCards.length >= 2 || 
      !card || 
      card.isFlipped || 
      card.isMatched
    ) {
      return;
    }
    
    // Flip the card
    const updatedCards = cards.map(card => 
      card.id === id ? { ...card, isFlipped: true } : card
    );
    setCards(updatedCards);
    
    // Add to selected cards
    const newSelectedCards = [...selectedCards, id];
    setSelectedCards(newSelectedCards);
    
    // Check for a match if two cards are selected
    if (newSelectedCards.length === 2) {
      const firstCard = cards.find(c => c.id === newSelectedCards[0]);
      const secondCard = cards.find(c => c.id === newSelectedCards[1]);
      
      if (firstCard && secondCard) {
        if (
          (firstCard.type === "spanish" && secondCard.type === "english") || 
          (firstCard.type === "english" && secondCard.type === "spanish")
        ) {
          // Check if they are a matching pair
          // Need to handle slash-separated options in Spanish words
          const vocabPair = getVocabularyForLevel(levelId).find(word => {
            // Handle slash-separated options in Spanish words
            const spanishOptions = word.spanish.split("/").map(option => option.trim());
            
            // Check Spanish card to English card match
            if (firstCard.type === "spanish" && secondCard.type === "english") {
              return spanishOptions.includes(firstCard.content) && word.english === secondCard.content;
            }
            // Check English card to Spanish card match
            else if (firstCard.type === "english" && secondCard.type === "spanish") {
              return word.english === firstCard.content && spanishOptions.includes(secondCard.content);
            }
            
            return false;
          });
          
          if (vocabPair) {
            // It's a match!
            // In easy mode, match feedback is quicker and more rewarding
            const matchDelay = difficulty === "easy" ? 500 : 1000;
            
            setTimeout(() => {
              const matchedCards = cards.map(card => 
                card.id === firstCard.id || card.id === secondCard.id
                  ? { ...card, isMatched: true }
                  : card
              );
              setCards(matchedCards);
              setSelectedCards([]);
              setMatchedPairs(prev => prev + 1);
              
              // More encouraging messages in easy mode
              if (difficulty === "easy") {
                const messages = [
                  "¡Excelente! That's a perfect match!", 
                  "¡Increíble! You found a match!",
                  "¡Fantástico! You're doing great!",
                  "¡Asombroso! What a great memory!"
                ];
                setMessage(messages[Math.floor(Math.random() * messages.length)]);
              } else {
                setMessage("¡Muy bien! That's a match! Keep going!");
              }
              
              // Check if all pairs are matched
              if (matchedPairs + 1 === cards.length / 2) {
                setMessage("¡Fantástico! You've matched all the pairs!");
                
                // Complete game faster in easy mode
                const completeDelay = difficulty === "easy" ? 1000 : 1500;
                setTimeout(onComplete, completeDelay);
              }
            }, matchDelay);
          } else {
            // Not a match
            // In easy mode, wrong answers are shown briefly to help learning
            const mismatchDelay = difficulty === "easy" ? 2000 : 1500;
            
            setTimeout(() => {
              const resetCards = cards.map(card => 
                card.id === firstCard.id || card.id === secondCard.id
                  ? { ...card, isFlipped: false }
                  : card
              );
              setCards(resetCards);
              setSelectedCards([]);
              
              // More helpful message in easy mode
              if (difficulty === "easy") {
                setMessage("That's not quite right. Try again - you can do it!");
              } else {
                setMessage("¡Inténtalo otra vez! Try again!");
              }
            }, mismatchDelay);
          }
        } else {
          // Same type (both Spanish or both English), not a match
          // In easy mode, provide more helpful guidance
          setTimeout(() => {
            const resetCards = cards.map(card => 
              card.id === firstCard.id || card.id === secondCard.id
                ? { ...card, isFlipped: false }
                : card
              );
            setCards(resetCards);
            setSelectedCards([]);
            
            if (difficulty === "easy") {
              setMessage("Remember to match Spanish words with English words. Try again!");
            } else {
              setMessage("You need to match Spanish words with English translations!");
            }
          }, difficulty === "easy" ? 2000 : 1500);
        }
      }
    }
  };
  
  // Handle hint
  const handleHint = () => {
    if (hintsRemaining <= 0) return;
    
    // Find an unmatched pair and briefly flash them
    const unmatchedCards = cards.filter(card => !card.isMatched);
    if (unmatchedCards.length === 0) return;
    
    // Get a random unmatched card
    const randomCard = unmatchedCards[Math.floor(Math.random() * unmatchedCards.length)];
    
    // Find its pair
    const vocabulary = getVocabularyForLevel(levelId);
    let pairCard;
    
    if (randomCard.type === "spanish") {
      // For Spanish cards, need to handle slash-separated options
      const word = vocabulary.find(w => {
        const spanishOptions = w.spanish.split("/").map(option => option.trim());
        return spanishOptions.includes(randomCard.content);
      });
      pairCard = cards.find(c => c.type === "english" && c.content === word?.english);
    } else {
      // For English cards, find the matching Spanish card
      const word = vocabulary.find(w => w.english === randomCard.content);
      if (word) {
        // Get the first option from slash-separated Spanish words
        const spanishWord = word.spanish.split("/")[0].trim();
        pairCard = cards.find(c => c.type === "spanish" && c.content === spanishWord);
      }
    }
    
    if (!pairCard) return;
    
    // Flash both cards briefly
    const highlightedCards = cards.map(card => 
      card.id === randomCard.id || card.id === pairCard.id
        ? { ...card, isFlipped: true }
        : card
    );
    setCards(highlightedCards);
    
    // Different hint messages based on difficulty
    if (difficulty === "easy") {
      const hintMessages = [
        "Look at these cards! They go together!",
        "Remember where these matching cards are!",
        "These two cards are a match! Can you find them again?",
        "Here's a hint to help you win!"
      ];
      setMessage(hintMessages[Math.floor(Math.random() * hintMessages.length)]);
    } else {
      setMessage("Here's a hint! Remember these cards!");
    }
    
    // In easy mode, show the hint for longer
    const hintDuration = difficulty === "easy" ? 3000 : 2000;
    
    // Reset after a short time
    setTimeout(() => {
      const resetCards = cards.map(card => 
        (!card.isMatched && (card.id === randomCard.id || card.id === pairCard.id))
          ? { ...card, isFlipped: false }
          : card
      );
      setCards(resetCards);
      setSelectedCards([]);
    }, hintDuration);
    
    // Decrease hints remaining
    setHintsRemaining(prev => prev - 1);
  };
  
  // Handle restart
  const handleRestart = () => {
    // Reshuffle all cards
    let shuffledCards = [...cards].map(card => ({ ...card, isFlipped: false, isMatched: false }));
    
    if (difficulty === "easy") {
      // In easy mode, minimal shuffling to keep similar patterns
      shuffledCards = shuffledCards.sort(() => Math.random() > 0.7 ? 1 : -1);
    } else {
      // Full random shuffle for normal mode
      shuffledCards = shuffledCards.sort(() => Math.random() - 0.5);
    }
    
    setCards(shuffledCards);
    setSelectedCards([]);
    setMatchedPairs(0);
    
    // More encouraging message in easy mode
    if (difficulty === "easy") {
      setMessage("Let's play again! You're doing great!");
    } else {
      setMessage("¡Vamos de nuevo! Let's try again!");
    }
    
    // Reset hints based on difficulty
    setHintsRemaining(difficulty === "easy" ? 5 : 3);
  };
  
  return (
    <div className={`${difficulty === "easy" ? "p-8" : "p-6"} bg-white rounded-xl shadow-md`}>
      <div className="mb-6 flex justify-between items-center">
        <h3 className={`${difficulty === "easy" ? "text-3xl" : "text-2xl"} font-bold text-neutral-800 font-nunito flex items-center`}>
          <svg xmlns="http://www.w3.org/2000/svg" width={difficulty === "easy" ? "32" : "24"} height={difficulty === "easy" ? "32" : "24"} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-accent mr-2">
            <rect x="2" y="2" width="20" height="8" rx="2" ry="2" />
            <rect x="2" y="14" width="20" height="8" rx="2" ry="2" />
          </svg>
          Memory Cards
        </h3>
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size={difficulty === "easy" ? "lg" : "sm"}
            className={`${difficulty === "easy" ? "bg-amber-100 hover:bg-amber-200 text-amber-700 border-amber-300" : "bg-neutral-200 hover:bg-neutral-300 text-neutral-600"}`}
            onClick={handleHint}
            disabled={hintsRemaining <= 0}
          >
            <Lightbulb className={`${difficulty === "easy" ? "h-5 w-5" : "h-4 w-4"} mr-1`} /> Hint ({hintsRemaining})
          </Button>
          <Button
            variant="outline"
            size={difficulty === "easy" ? "lg" : "sm"}
            className="bg-neutral-200 hover:bg-neutral-300 text-neutral-600"
            onClick={handleRestart}
          >
            <RotateCcw className={`${difficulty === "easy" ? "h-5 w-5" : "h-4 w-4"} mr-1`} /> Restart
          </Button>
        </div>
      </div>
      
      {difficulty === "easy" ? (
        <div className="bg-blue-50 border-l-4 border-blue-400 p-4 mb-6 rounded">
          <div className="flex">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-500 mr-2 flex-shrink-0">
              <circle cx="12" cy="12" r="10"></circle>
              <line x1="12" y1="16" x2="12" y2="12"></line>
              <line x1="12" y1="8" x2="12.01" y2="8"></line>
            </svg>
            <p className="text-lg text-neutral-600">
              Find the matching pairs! Match each Spanish word with its English meaning.
              <span className="block mt-1 text-neutral-500">Click on the <b>?</b> cards to flip them and find matches!</span>
            </p>
          </div>
        </div>
      ) : (
        <p className="text-neutral-600 mb-4">Match the Spanish words with their English translations. Find all pairs to complete the game!</p>
      )}
      
      {/* Memory Card Grid - Fewer columns and bigger cards in easy mode */}
      <div className={`grid ${difficulty === "easy" ? "grid-cols-2 sm:grid-cols-3" : "grid-cols-2 sm:grid-cols-3 md:grid-cols-4"} gap-6 mb-6`}>
        {cards.map((card) => (
          <div
            key={card.id}
            className={`
              ${difficulty === "easy" ? "h-48" : "h-32"} flex items-center justify-center cursor-pointer shadow-md 
              transform transition-transform duration-300 active:scale-95 rounded-xl
              ${card.isMatched ? 'bg-success bg-opacity-20 border-2 border-success' : ''}
              ${card.isFlipped && !card.isMatched ? 
                (card.type === 'spanish' ? 'bg-accent' : 'bg-secondary text-white') : 
                (!card.isMatched ? 
                  (difficulty === "easy" ? 'bg-gradient-to-r from-primary to-primary-light' : 'bg-primary') : ''
                )
              }
            `}
            onClick={() => handleCardClick(card.id)}
          >
            {(card.isFlipped || card.isMatched) ? (
              <div className="text-center p-4">
                <div className={`${difficulty === "easy" ? "text-2xl" : "text-xl"} font-bold font-nunito`}>{card.content}</div>
                <div className="text-sm opacity-80">
                  {card.type === "spanish" ? 
                    <span className="flex items-center justify-center">
                      <span className="inline-block mr-1">🇪🇸</span> Spanish
                    </span> : 
                    <span className="flex items-center justify-center">
                      <span className="inline-block mr-1">🇺🇸</span> English
                    </span>
                  }
                </div>
                {card.isMatched && (
                  <div className="text-sm text-success flex items-center justify-center mt-1">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                    MATCHED
                  </div>
                )}
              </div>
            ) : (
              <div className={`${difficulty === "easy" ? "text-5xl" : "text-4xl"} text-white flex flex-col items-center`}>
                <span>?</span>
                {difficulty === "easy" && <span className="text-sm mt-2">Click to flip</span>}
              </div>
            )}
          </div>
        ))}
      </div>
      
      {/* Progress Bar - with text indicator in easy mode */}
      <div className="mb-6">
        {difficulty === "easy" && (
          <div className="flex justify-between mb-1">
            <span className="text-neutral-600 font-medium">Your progress:</span>
            <span className="font-bold text-secondary">{matchedPairs} of {cards.length / 2} matches found</span>
          </div>
        )}
        <div className={`bg-neutral-200 rounded-full ${difficulty === "easy" ? "h-6" : "h-4"} mb-2`}>
          <div 
            className="bg-secondary h-full rounded-full transition-all duration-500" 
            style={{ width: `${(matchedPairs / (cards.length / 2)) * 100}%` }}
          >
            {difficulty === "easy" && (
              <div className="h-full flex items-center justify-center text-xs font-bold text-white">
                {Math.round((matchedPairs / (cards.length / 2)) * 100)}%
              </div>
            )}
          </div>
        </div>
        {difficulty === "easy" && matchedPairs > 0 && matchedPairs < cards.length / 2 && (
          <div className="text-center text-sm text-green-600 font-medium animate-pulse">
            Keep going! You're doing great!
          </div>
        )}
      </div>
      
      {/* Toucan Character with Speech Bubble */}
      <div className="flex items-end">
        <svg width="100" height="100" viewBox="0 0 200 200" className={difficulty === "easy" ? "h-32" : "h-24"}>
          <path
            d="M100,20 C130,20 150,40 150,70 C150,85 140,95 135,100 C145,110 150,125 150,140 C150,170 130,190 100,190 C70,190 50,170 50,140 C50,125 55,110 65,100 C60,95 50,85 50,70 C50,40 70,20 100,20 Z"
            fill="#FF6B6B"
          />
          <circle cx="80" cy="70" r="10" fill="white" />
          <circle cx="80" cy="70" r="5" fill="black" />
          <circle cx="120" cy="70" r="10" fill="white" />
          <circle cx="120" cy="70" r="5" fill="black" />
          <path
            d="M90,90 C95,95 105,95 110,90"
            stroke="black"
            strokeWidth="3"
            fill="none"
          />
          <path
            d="M70,115 C80,130 120,130 130,115"
            stroke="#FFA500"
            strokeWidth="15"
            fill="none"
            strokeLinecap="round"
          />
          {matchedPairs > 0 && difficulty === "easy" && (
            <path
              d="M60,55 C65,45 75,55 60,55 Z M140,55 C135,45 125,55 140,55 Z"
              fill="#FFA500"
            />
          )}
        </svg>
        <div className={`relative ml-4 bg-neutral-100 p-4 rounded-xl ${difficulty === "easy" ? "max-w-sm text-lg" : "max-w-xs"}`}>
          <div className="absolute w-4 h-4 bg-neutral-100 transform rotate-45 -left-2 bottom-4"></div>
          <p className={`${difficulty === "easy" ? "text-lg" : ""} text-neutral-700`}>{message}</p>
          {matchedPairs === cards.length / 2 && difficulty === "easy" && (
            <span className="block mt-2 text-green-600 font-bold">¡Fantástico! You're a Spanish star!</span>
          )}  
        </div>
      </div>
    </div>
  );
}
