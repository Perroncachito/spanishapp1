import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { getVocabularyForLevel } from "@/lib/vocabulary";
import { Volume2, Flag, Check, X } from "lucide-react";

interface QuizInterfaceProps {
  levelId: number;
  onComplete: (passed: boolean) => void;
}

type QuizQuestion = {
  id: number;
  type: "multiple-choice" | "audio" | "situation" | "image" | "dialogue" | "culture";
  question: string;
  options: string[];
  correctAnswer: string;
  audioSrc?: string;
  imageSrc?: string;
  userAnswer?: string;
  flagged?: boolean;
};

export default function QuizInterface({ levelId, onComplete }: QuizInterfaceProps) {
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [score, setScore] = useState(0);
  const [message, setMessage] = useState<string>("¡Vamos a ver! Let's test your knowledge!");
  
  // Generate quiz questions based on the level
  useEffect(() => {
    const generatedQuestions = generateQuizQuestions(levelId);
    setQuestions(generatedQuestions);
    setCurrentQuestionIndex(0);
    setQuizCompleted(false);
    setScore(0);
  }, [levelId]);
  
  // Submit quiz results mutation
  const submitQuizMutation = useMutation({
    mutationFn: async ({ levelId, score, totalQuestions, isPassed }: { 
      levelId: number, 
      score: number, 
      totalQuestions: number, 
      isPassed: boolean 
    }) => {
      const res = await apiRequest("POST", "/api/quizzes", {
        levelId,
        score,
        totalQuestions,
        isPassed
      });
      return await res.json();
    },
    onSuccess: (data) => {
      // Inform parent component of completion
      onComplete(data.isPassed);
    }
  });
  
  // Generate quiz questions based on the level content
  const generateQuizQuestions = (levelId: number): QuizQuestion[] => {
    const vocabulary = getVocabularyForLevel(levelId);
    const questions: QuizQuestion[] = [];
    
    // Generate multiple choice vocabulary questions
    vocabulary.forEach((word, index) => {
      // Get incorrect options from other words
      const incorrectOptions = vocabulary
        .filter(w => w.english !== word.english)
        .sort(() => Math.random() - 0.5)
        .slice(0, 3)
        .map(w => w.english);
      
      // Create options array with correct answer and shuffled
      const options = [word.english, ...incorrectOptions].sort(() => Math.random() - 0.5);
      
      questions.push({
        id: index,
        type: "multiple-choice",
        question: `What does "${word.spanish}" mean in English?`,
        options,
        correctAnswer: word.english
      });
    });
    
    // Generate audio questions (if we had real audio)
    vocabulary.slice(0, 3).forEach((word, index) => {
      const incorrectOptions = vocabulary
        .filter(w => w.spanish !== word.spanish)
        .sort(() => Math.random() - 0.5)
        .slice(0, 3)
        .map(w => w.spanish);
      
      const options = [word.spanish, ...incorrectOptions].sort(() => Math.random() - 0.5);
      
      questions.push({
        id: vocabulary.length + index,
        type: "audio",
        question: "Listen and select the word you hear:",
        options,
        correctAnswer: word.spanish,
        audioSrc: `audio/${word.spanish.toLowerCase().replace(/\s/g, '_')}.mp3` // Simulated path
      });
    });
    
    // For level 1, add some situation-based questions
    if (levelId === 1) {
      questions.push({
        id: vocabulary.length + 3,
        type: "situation",
        question: "What would you say when meeting someone for the first time?",
        options: ["¡Hola! Mucho gusto.", "¡Hasta luego!", "¡Gracias!", "Lo siento."],
        correctAnswer: "¡Hola! Mucho gusto."
      });
      
      questions.push({
        id: vocabulary.length + 4,
        type: "situation",
        question: "What would you say to someone in the morning?",
        options: ["Buenos días", "Buenas noches", "¡Hasta mañana!", "¿Cómo te llamas?"],
        correctAnswer: "Buenos días"
      });
    }
    
    // Shuffle questions and take 10
    return questions.sort(() => Math.random() - 0.5).slice(0, 10);
  };
  
  // Handle answer selection
  const handleAnswerSelect = (answer: string) => {
    const updatedQuestions = [...questions];
    updatedQuestions[currentQuestionIndex].userAnswer = answer;
    setQuestions(updatedQuestions);
    
    // Move to next question or complete quiz
    setTimeout(() => {
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
      } else {
        completeQuiz();
      }
    }, 500);
  };
  
  // Toggle flag on a question
  const handleFlagQuestion = () => {
    const updatedQuestions = [...questions];
    updatedQuestions[currentQuestionIndex].flagged = !updatedQuestions[currentQuestionIndex].flagged;
    setQuestions(updatedQuestions);
  };
  
  // Move to previous question
  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };
  
  // Complete the quiz and calculate results
  const completeQuiz = () => {
    // Calculate score
    const correctAnswers = questions.filter(q => 
      q.userAnswer === q.correctAnswer
    ).length;
    
    setScore(correctAnswers);
    setQuizCompleted(true);
    
    const totalQuestions = questions.length;
    const percentage = (correctAnswers / totalQuestions) * 100;
    const passed = percentage >= 70; // 70% passing threshold
    
    // Update message based on score
    if (percentage >= 90) {
      setMessage("¡Excelente! You're a Spanish superstar!");
    } else if (percentage >= 70) {
      setMessage("¡Muy bien! You passed the quiz!");
    } else {
      setMessage("Keep practicing! You'll get it next time!");
    }
    
    // Submit quiz results to API
    submitQuizMutation.mutate({
      levelId,
      score: correctAnswers,
      totalQuestions,
      isPassed: passed
    });
  };
  
  // Review missed questions
  const handleReviewMissed = () => {
    // Find first question that was answered incorrectly
    const firstMissedIndex = questions.findIndex(q => 
      q.userAnswer !== q.correctAnswer
    );
    
    if (firstMissedIndex !== -1) {
      setCurrentQuestionIndex(firstMissedIndex);
    }
  };
  
  // Play audio for audio questions
  const playAudio = (src: string) => {
    // In a real app, this would play an actual audio file
    console.log(`Playing audio: ${src}`);
    alert(`Playing audio: ${src} (simulated)`);
  };
  
  // Calculate current progress
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  return (
    <div className="p-6 bg-white rounded-xl shadow-md">
      {!quizCompleted ? (
        <>
          <div className="mb-6 flex justify-between items-center">
            <h3 className="text-2xl font-bold text-neutral-800 font-nunito flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary mr-2">
                <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
                <path d="m9 12 2 2 4-4" />
              </svg>
              Quiz: Level {levelId}
            </h3>
            <div className="text-sm text-neutral-600">
              Question {currentQuestionIndex + 1} of {questions.length}
            </div>
          </div>
          
          {questions.length > 0 && (
            <div className="space-y-6">
              {/* Progress Bar */}
              <div className="bg-neutral-200 rounded-full h-2 mb-6">
                <div 
                  className="bg-primary h-full rounded-full" 
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
              
              {/* Current Question */}
              <div className="bg-neutral-100 rounded-lg p-6">
                <h4 className="text-xl font-bold text-neutral-800 mb-4 font-nunito">
                  {questions[currentQuestionIndex].question}
                </h4>
                
                {/* Audio Button for Audio Questions */}
                {questions[currentQuestionIndex].type === "audio" && (
                  <Button
                    variant="default"
                    size="lg"
                    className="bg-purple-500 hover:bg-purple-600 mb-4"
                    onClick={() => playAudio(questions[currentQuestionIndex].audioSrc || "")}
                  >
                    <Volume2 className="h-5 w-5 mr-2" /> Play Audio
                  </Button>
                )}
                
                {/* Answer Options */}
                <div className="space-y-3">
                  {questions[currentQuestionIndex].options.map((option, index) => {
                    const question = questions[currentQuestionIndex];
                    let optionClass = "border-2 border-neutral-200 hover:bg-neutral-100";
                    
                    if (question.userAnswer) {
                      if (option === question.correctAnswer) {
                        optionClass = "border-2 border-success bg-success bg-opacity-10 text-success";
                      } else if (option === question.userAnswer && option !== question.correctAnswer) {
                        optionClass = "border-2 border-error bg-error bg-opacity-10 text-error";
                      }
                    }
                    
                    return (
                      <Button
                        key={index}
                        variant="outline"
                        className={`w-full justify-start text-left p-4 h-auto ${optionClass}`}
                        onClick={() => handleAnswerSelect(option)}
                        disabled={!!question.userAnswer}
                      >
                        <div className="flex items-center">
                          <span className="w-8 h-8 flex items-center justify-center rounded-full border-2 border-current mr-3">
                            {String.fromCharCode(65 + index)}
                          </span>
                          {option}
                        </div>
                        
                        {question.userAnswer && option === question.correctAnswer && (
                          <Check className="ml-auto h-5 w-5 text-success" />
                        )}
                        
                        {question.userAnswer === option && option !== question.correctAnswer && (
                          <X className="ml-auto h-5 w-5 text-error" />
                        )}
                      </Button>
                    );
                  })}
                </div>
              </div>
              
              {/* Navigation Buttons */}
              <div className="flex justify-between">
                <Button
                  variant="outline"
                  onClick={handlePreviousQuestion}
                  disabled={currentQuestionIndex === 0}
                >
                  Previous
                </Button>
                
                <Button
                  variant="outline"
                  onClick={handleFlagQuestion}
                >
                  <Flag className={`h-4 w-4 mr-2 ${questions[currentQuestionIndex].flagged ? 'text-primary' : ''}`} />
                  {questions[currentQuestionIndex].flagged ? 'Unflag' : 'Flag'} Question
                </Button>
                
                {/* Skip this question button */}
                {!questions[currentQuestionIndex].userAnswer && (
                  <Button
                    variant="default"
                    onClick={() => {
                      // Mark as skipped (no answer)
                      const updatedQuestions = [...questions];
                      updatedQuestions[currentQuestionIndex].userAnswer = "";
                      setQuestions(updatedQuestions);
                      
                      // Move to next question or complete quiz
                      if (currentQuestionIndex < questions.length - 1) {
                        setCurrentQuestionIndex(currentQuestionIndex + 1);
                      } else {
                        completeQuiz();
                      }
                    }}
                  >
                    Skip Question
                  </Button>
                )}
              </div>
            </div>
          )}
        </>
      ) : (
        // Quiz Results
        <div className="text-center">
          <h3 className="text-2xl font-bold text-neutral-800 font-nunito mb-4">
            Quiz Results
          </h3>
          
          <div className="mb-6">
            <div className="text-5xl font-bold mb-2">
              {score}/{questions.length}
            </div>
            <div className="text-xl text-neutral-600">
              {(score / questions.length * 100).toFixed(0)}%
            </div>
          </div>
          
          {/* Pass/Fail Status */}
          {score >= Math.ceil(questions.length * 0.7) ? (
            <div className="bg-success bg-opacity-10 text-success p-4 rounded-lg mb-6">
              <Check className="h-8 w-8 mx-auto mb-2" />
              <div className="font-bold text-lg">¡Felicidades! You passed!</div>
            </div>
          ) : (
            <div className="bg-error bg-opacity-10 text-error p-4 rounded-lg mb-6">
              <X className="h-8 w-8 mx-auto mb-2" />
              <div className="font-bold text-lg">Keep practicing! You need 70% to pass.</div>
            </div>
          )}
          
          {/* Question Summary */}
          <div className="bg-neutral-100 rounded-lg p-4 mb-6">
            <h4 className="font-bold text-neutral-700 mb-2">Question Summary</h4>
            <div className="grid grid-cols-5 gap-2">
              {questions.map((question, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className={`h-10 w-10 p-0 ${
                    question.userAnswer === question.correctAnswer 
                      ? 'bg-success bg-opacity-20 border-success text-success' 
                      : 'bg-error bg-opacity-20 border-error text-error'
                  }`}
                  onClick={() => setCurrentQuestionIndex(index)}
                >
                  {index + 1}
                </Button>
              ))}
            </div>
          </div>
          
          <div className="flex space-x-4 justify-center">
            <Button
              variant="outline"
              onClick={handleReviewMissed}
              disabled={score === questions.length}
            >
              Review Missed Questions
            </Button>
            
            <Button
              variant="default"
              onClick={() => onComplete(score >= Math.ceil(questions.length * 0.7))}
            >
              {score >= Math.ceil(questions.length * 0.7) ? 'Continue to Next Level' : 'Try Again'}
            </Button>
          </div>
        </div>
      )}
      
      {/* Toucan Character with Speech Bubble */}
      {!quizCompleted && (
        <div className="flex items-end mt-6">
          <svg width="100" height="100" viewBox="0 0 200 200" className="h-24">
            <path
              d="M100,20 C130,20 150,40 150,70 C150,85 140,95 135,100 C145,110 150,125 150,140 C150,170 130,190 100,190 C70,190 50,170 50,140 C50,125 55,110 65,100 C60,95 50,85 50,70 C50,40 70,20 100,20 Z"
              fill="#FF6B6B"
            />
            <circle cx="80" cy="70" r="10" fill="white" />
            <circle cx="80" cy="70" r="5" fill="black" />
            <circle cx="120" cy="70" r="10" fill="white" />
            <circle cx="120" cy="70" r="5" fill="black" />
            <path
              d="M90,90 C95,95 105,95 110,90"
              stroke="black"
              strokeWidth="3"
              fill="none"
            />
            <path
              d="M70,115 C80,130 120,130 130,115"
              stroke="#FFA500"
              strokeWidth="15"
              fill="none"
              strokeLinecap="round"
            />
          </svg>
          <div className="relative ml-4 bg-neutral-100 p-4 rounded-xl max-w-xs">
            <div className="absolute w-4 h-4 bg-neutral-100 transform rotate-45 -left-2 bottom-4"></div>
            <p className="text-neutral-700">{message}</p>
          </div>
        </div>
      )}
    </div>
  );
}
