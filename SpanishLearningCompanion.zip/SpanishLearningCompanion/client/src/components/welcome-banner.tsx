import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Progress } from "@shared/schema";
import { Play } from "lucide-react";

interface WelcomeBannerProps {
  childName: string;
  sessionDuration: number;
  currentProgress?: Progress;
}

export default function WelcomeBanner({ childName, sessionDuration, currentProgress }: WelcomeBannerProps) {
  const [, navigate] = useLocation();
  
  // Calculate progress for current level/session
  const timeSpentToday = currentProgress?.totalTimeSpent || 0;
  const progressPercentage = Math.min(
    Math.floor((timeSpentToday / sessionDuration) * 100), 
    100
  );
  
  // Format remaining time as MM:SS
  const remainingMinutes = Math.max(0, sessionDuration - timeSpentToday);
  const hours = Math.floor(remainingMinutes / 60);
  const minutes = remainingMinutes % 60;
  const formattedTime = hours > 0 
    ? `${hours}:${minutes.toString().padStart(2, '0')}`
    : `${minutes}:00`;
  
  const handleContinueLearning = () => {
    const levelId = currentProgress?.currentLevel || 1;
    navigate(`/level/${levelId}`);
  };
  
  return (
    <div className="bg-gradient-to-r from-primary-light to-primary rounded-2xl p-6 mb-8 shadow-lg relative overflow-hidden">
      <div className="flex flex-col md:flex-row items-center">
        <div className="md:w-2/3 z-10">
          <h1 className="text-3xl md:text-4xl font-bold text-white font-nunito mb-2">
            ¡Hola! Welcome back, {childName}!
          </h1>
          <p className="text-white text-opacity-90 mb-4">
            Ready to continue your Spanish adventure?
          </p>
          
          <div className="bg-white bg-opacity-30 rounded-lg p-4 mb-4 flex items-center">
            <div className="mr-4">
              <div className="text-xl font-bold text-white">Today's Goal:</div>
              <div className="text-sm text-white">{sessionDuration} minute session</div>
            </div>
            <div className="flex-1 h-4 bg-white bg-opacity-40 rounded-full overflow-hidden">
              <div 
                className="h-full bg-accent rounded-full" 
                style={{ width: `${progressPercentage}%` }}
              ></div>
            </div>
            <div className="ml-4 text-white font-bold">{formattedTime}</div>
          </div>
          
          <Button 
            className="bg-accent hover:bg-accent-dark text-neutral-800 font-bold py-3 px-6 rounded-full shadow-md transition-all"
            onClick={handleContinueLearning}
          >
            <Play className="mr-2 h-4 w-4" /> Continue Learning
          </Button>
        </div>
        
        <div className="md:w-1/3 flex justify-center md:justify-end">
          <svg 
            width="180" 
            height="180" 
            viewBox="0 0 200 200" 
            className="h-48 -mt-6 animate-bounce-slow"
          >
            <path
              d="M100,20 C130,20 150,40 150,70 C150,85 140,95 135,100 C145,110 150,125 150,140 C150,170 130,190 100,190 C70,190 50,170 50,140 C50,125 55,110 65,100 C60,95 50,85 50,70 C50,40 70,20 100,20 Z"
              fill="#FF6B6B"
            />
            <circle cx="80" cy="70" r="10" fill="white" />
            <circle cx="80" cy="70" r="5" fill="black" />
            <circle cx="120" cy="70" r="10" fill="white" />
            <circle cx="120" cy="70" r="5" fill="black" />
            <path
              d="M90,90 C95,95 105,95 110,90"
              stroke="black"
              strokeWidth="3"
              fill="none"
            />
            <path
              d="M70,115 C80,130 120,130 130,115"
              stroke="#FFA500"
              strokeWidth="15"
              fill="none"
              strokeLinecap="round"
            />
          </svg>
        </div>
      </div>
      
      <div className="absolute bottom-0 right-0 w-full h-16 bg-white bg-opacity-10 transform -skew-y-3 -mb-8"></div>
    </div>
  );
}
