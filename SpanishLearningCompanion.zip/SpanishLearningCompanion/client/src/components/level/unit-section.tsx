import { useState } from "react";
import LevelCircle from "./level-circle";
import { ChevronDown, ChevronUp } from "lucide-react";

interface UnitSectionProps {
  unitNumber: number;
  unitName: string;
  levels: {
    id: number;
    name: string;
    isCompleted: boolean;
    isLocked: boolean;
  }[];
  completedLevelsCount: number;
  currentLevel: number;
}

export default function UnitSection({ 
  unitNumber, 
  unitName, 
  levels, 
  completedLevelsCount,
  currentLevel
}: UnitSectionProps) {
  const [isExpanded, setIsExpanded] = useState(unitNumber === 1 || levels.some(l => l.id === currentLevel));
  
  const handleToggleExpand = () => {
    setIsExpanded(!isExpanded);
  };
  
  return (
    <div className={`mb-12 ${!isExpanded ? 'opacity-60' : ''}`}>
      <div className="flex items-center mb-4">
        <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white font-bold">
          {unitNumber}
        </div>
        <h3 className="ml-3 text-xl font-bold text-neutral-800 font-nunito">{unitName}</h3>
        
        {completedLevelsCount > 0 && (
          <div className="ml-auto text-sm text-neutral-500 flex items-center">
            <div className="w-3 h-3 rounded-full bg-success mr-2"></div>
            <span>{completedLevelsCount}/{levels.length} Completed</span>
          </div>
        )}
        
        {!isExpanded && (
          <button 
            className="ml-auto text-sm text-secondary-dark hover:text-secondary"
            onClick={handleToggleExpand}
          >
            <ChevronDown className="h-5 w-5" /> Show
          </button>
        )}
        
        {isExpanded && unitNumber > 1 && (
          <button 
            className="ml-auto text-sm text-secondary-dark hover:text-secondary"
            onClick={handleToggleExpand}
          >
            <ChevronUp className="h-5 w-5" /> Hide
          </button>
        )}
      </div>
      
      {isExpanded ? (
        <div className="flex flex-wrap gap-4 mb-8">
          {levels.map((level) => (
            <LevelCircle
              key={level.id}
              level={level.id}
              name={level.name}
              isCompleted={level.isCompleted}
              isLocked={level.isLocked}
              isFree={level.id === 1}
            />
          ))}
        </div>
      ) : (
        <div className="flex flex-wrap gap-4">
          {levels.map((level) => (
            <div key={level.id} className="level-circle relative cursor-not-allowed">
              <div className="w-16 h-16 rounded-full bg-gradient-to-r from-neutral-300 to-neutral-200 flex items-center justify-center text-neutral-500 shadow border-2 border-white relative">
                <div className="text-xl font-bold">{level.id}</div>
                <div className="absolute inset-0 bg-black bg-opacity-20 rounded-full flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-sm text-white">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                  </svg>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
