import { Link } from "wouter";
import { cn } from "@/lib/utils";

interface LevelGridProps {
  currentLevel: number;
  completedLevels: string[];
}

export default function LevelGrid({ currentLevel, completedLevels }: LevelGridProps) {
  // ==== LEVEL UNLOCKING LOGIC ====
  // This is the core function that decides whether a level should be unlocked or locked
  const isLevelUnlocked = (levelId: number): boolean => {
    // Case 1: First level is always unlocked for everyone
    if (levelId === 1) return true;
    
    // Case 2: Current level assigned to user is always unlocked
    if (levelId === currentLevel) return true;
    
    // Case 3: Any level that has been completed is unlocked for replay
    if (completedLevels.includes(levelId.toString())) return true;
    
    // Case 4: Sequential progression - level unlocks if previous level is completed
    // This ensures levels unlock one by one in sequence
    if (completedLevels.includes((levelId - 1).toString())) return true;
    
    // Default: All other levels remain locked
    return false;
  };
  
  // Define linear level structure for all 30 levels
  const allLevels = [
    { id: 1, name: "Basic Greetings", theme: "greeting" },
    { id: 2, name: "Formal Greetings", theme: "greeting" },
    { id: 3, name: "Introductions", theme: "greeting" },
    { id: 4, name: "Conversation Basics", theme: "numbers" },
    { id: 5, name: "Numbers 1-10", theme: "numbers" },
    { id: 6, name: "Numbers 11-31", theme: "numbers" },
    { id: 7, name: "Counting & Basic Math", theme: "colors" },
    { id: 8, name: "Basic Colors", theme: "colors" },
    { id: 9, name: "Simple Descriptions", theme: "colors" },
    { id: 10, name: "Physical Appearance", theme: "food" },
    { id: 11, name: "Fruits & Vegetables", theme: "food" },
    { id: 12, name: "Common Foods", theme: "food" },
    { id: 13, name: "Restaurant Phrases", theme: "family" },
    { id: 14, name: "Immediate Family", theme: "family" },
    { id: 15, name: "Extended Family", theme: "family" },
    { id: 16, name: "Telling Time", theme: "time" },
    { id: 17, name: "Days of the Week", theme: "time" },
    { id: 18, name: "Months & Seasons", theme: "time" },
    { id: 19, name: "Popular Sports", theme: "sports" },
    { id: 20, name: "Leisure Activities", theme: "sports" },
    { id: 21, name: "Music & Art", theme: "sports" },
    { id: 22, name: "Getting Around", theme: "travel" },
    { id: 23, name: "Asking for Directions", theme: "travel" },
    { id: 24, name: "Travel Vocabulary", theme: "travel" },
    { id: 25, name: "Classroom Vocabulary", theme: "school" },
    { id: 26, name: "School Subjects", theme: "school" },
    { id: 27, name: "Academic Activities", theme: "school" },
    { id: 28, name: "Pets & Farm Animals", theme: "animals" },
    { id: 29, name: "Wild Animals", theme: "animals" },
    { id: 30, name: "Nature & Environment", theme: "animals" },
  ];
  
  // Map each level to contain lock/unlock status
  const levelsWithStatus = allLevels.map(level => {
    const isLevelCompleted = completedLevels.includes(level.id.toString());
    const isUnlocked = isLevelUnlocked(level.id);
    
    return {
      ...level,
      isCompleted: isLevelCompleted,
      isLocked: !isUnlocked
    };
  });
  
  // Get theme color for each level
  const getThemeColor = (theme: string): string => {
    const themeColors: Record<string, string> = {
      greeting: "bg-purple-100 border-purple-300",
      numbers: "bg-blue-100 border-blue-300",
      colors: "bg-pink-100 border-pink-300",
      food: "bg-green-100 border-green-300",
      family: "bg-yellow-100 border-yellow-300",
      time: "bg-red-100 border-red-300",
      sports: "bg-orange-100 border-orange-300",
      travel: "bg-indigo-100 border-indigo-300",
      school: "bg-teal-100 border-teal-300",
      animals: "bg-emerald-100 border-emerald-300"
    };
    
    return themeColors[theme] || "bg-gray-100 border-gray-300";
  };
  
  // Get icon based on completion/lock status
  const getLevelIcon = (isCompleted: boolean, isLocked: boolean) => {
    if (isCompleted) {
      return (
        <div className="w-6 h-6 flex items-center justify-center bg-green-500 text-white rounded-full">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
          </svg>
        </div>
      );
    } else if (isLocked) {
      return (
        <div className="w-6 h-6 flex items-center justify-center bg-gray-400 text-white rounded-full">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
          </svg>
        </div>
      );
    } else {
      return (
        <div className="w-6 h-6 flex items-center justify-center bg-blue-500 text-white rounded-full">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 0l-3 3a1 1 0 001.414 1.414L9 9.414V13a1 1 0 102 0V9.414l1.293 1.293a1 1 0 001.414-1.414z" clipRule="evenodd" />
          </svg>
        </div>
      );
    }
  };
  
  return (
    <div className="mb-12">
      <h2 className="text-2xl font-bold text-center mb-8 text-primary font-nunito">Your Spanish Learning Adventure!</h2>
      
      {/* Kid-friendly background with clouds and sun */}
      <div className="relative bg-gradient-to-b from-sky-200 to-sky-100 p-6 rounded-3xl border-2 border-sky-300 shadow-md">
        {/* Decorative Sun */}
        <div className="absolute top-4 right-4 w-16 h-16 bg-yellow-300 rounded-full flex items-center justify-center shadow-lg">
          <div className="text-yellow-600 text-2xl">☀️</div>
        </div>
        
        {/* Decorative Clouds */}
        <div className="absolute top-6 left-8 w-20 h-10 bg-white rounded-full shadow-sm"></div>
        <div className="absolute top-10 left-20 w-16 h-8 bg-white rounded-full shadow-sm"></div>
        <div className="absolute bottom-12 right-16 w-24 h-12 bg-white rounded-full shadow-sm"></div>
        
        {/* Linear Level Path */}
        <div className="relative max-w-3xl mx-auto z-10">
          {/* Connecting path between levels */}
          <div className="absolute left-1/2 top-0 bottom-0 w-2 bg-blue-200 -translate-x-1/2 rounded-full"></div>
          
          {/* Level buttons */}
          {levelsWithStatus.map((level, index) => (
            <div key={level.id} className="flex items-center mb-6 relative">
              {/* Level circle with number */}
              <div className={cn(
                "w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg relative z-10",
                level.isCompleted ? "bg-green-500 text-white" : 
                level.isLocked ? "bg-gray-300 text-gray-500" : 
                "bg-primary text-white",
                level.id === currentLevel && "ring-4 ring-offset-2 ring-primary-light"
              )}>
                {level.id}
              </div>
              
              {/* Level card */}
              <Link 
                href={level.isLocked ? "#" : `/level/${level.id}`}
                className={cn(
                  "ml-4 flex-1 p-4 rounded-2xl shadow-sm border-2 transition-all",
                  getThemeColor(level.theme),
                  level.isLocked ? "opacity-60 cursor-not-allowed" : "hover:shadow-md cursor-pointer",
                  level.id === currentLevel && "border-primary-dark border-2"
                )}
                onClick={(e) => level.isLocked && e.preventDefault()}
              >
                <div className="flex items-center">
                  {getLevelIcon(level.isCompleted, level.isLocked)}
                  <div className="ml-3">
                    <h3 className={cn(
                      "font-semibold",
                      level.isLocked ? "text-gray-500" : "text-gray-800"
                    )}>
                      Level {level.id}: {level.name}
                    </h3>
                    <p className="text-xs text-gray-600">
                      {level.isCompleted ? "Completed" : 
                       level.isLocked ? "Locked - Complete previous level" : 
                       "Ready to play"}
                    </p>
                  </div>
                </div>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
