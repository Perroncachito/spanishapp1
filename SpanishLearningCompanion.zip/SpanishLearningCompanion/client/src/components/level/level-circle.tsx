import { useLocation } from "wouter";
import { Lock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface LevelCircleProps {
  level: number;
  name: string;
  isCompleted: boolean;
  isLocked: boolean;
  isFree: boolean;
}

export default function LevelCircle({ level, name, isCompleted, isLocked, isFree }: LevelCircleProps) {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  const handleClick = () => {
    if (isLocked && !isCompleted) {
      toast({
        title: "Level Locked",
        description: "Complete the previous levels to unlock this one!",
        variant: "destructive",
      });
      return;
    }
    
    navigate(`/level/${level}`);
  };
  
  // Base classes
  let circleClasses = "level-circle relative cursor-pointer";
  let innerClasses = "w-28 h-28 rounded-full flex flex-col items-center justify-center text-white shadow-lg border-4 border-white";
  
  // Apply status-specific classes
  if (isLocked) {
    innerClasses += " bg-gradient-to-r from-neutral-300 to-neutral-200 text-neutral-500";
    circleClasses = "level-circle relative cursor-pointer";
  } else if (isCompleted) {
    innerClasses += " bg-gradient-to-r from-secondary to-secondary-light";
  } else {
    innerClasses += " bg-gradient-to-r from-primary to-primary-light";
  }
  
  // Add completed class to make it queryable in the DOM
  if (isCompleted) {
    circleClasses += " completed";
  }
  
  return (
    <div 
      className={circleClasses} 
      onClick={handleClick} 
      data-level-id={level}
      data-completed={isCompleted ? "true" : "false"}
    >
      <div className={innerClasses}>
        <div className="text-3xl font-bold">{level}</div>
        <div className="text-xs">{name}</div>
        
        {isCompleted && (
          <div className="absolute -top-2 -right-2 bg-green-500 rounded-full p-1">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
              <polyline points="20 6 9 17 4 12" />
            </svg>
          </div>
        )}
        
        {isLocked && (
          <div className="absolute inset-0 bg-black bg-opacity-20 rounded-full flex items-center justify-center">
            <Lock className="text-2xl text-white" />
          </div>
        )}
      </div>
      
      <div className={`absolute -bottom-2 left-1/2 transform -translate-x-1/2 ${isFree ? 'bg-accent' : 'bg-primary'} rounded-full px-2 py-1 text-xs font-bold ${isFree ? 'text-neutral-800' : 'text-white'}`}>
        {isFree ? 'FREE' : 'PAID'}
      </div>
    </div>
  );
}
