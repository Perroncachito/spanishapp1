import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { User, Settings, LogOut } from "lucide-react";

interface NavbarProps {
  onParentPortalClick: () => void;
}

export default function Navbar({ onParentPortalClick }: NavbarProps) {
  const { user, logoutMutation } = useAuth();
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  return (
    <header className="bg-white shadow-md">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <svg
                width="40"
                height="40"
                viewBox="0 0 200 200"
                className="block h-12 w-12"
              >
                <path
                  d="M100,20 C130,20 150,40 150,70 C150,85 140,95 135,100 C145,110 150,125 150,140 C150,170 130,190 100,190 C70,190 50,170 50,140 C50,125 55,110 65,100 C60,95 50,85 50,70 C50,40 70,20 100,20 Z"
                  fill="#FF6B6B"
                />
                <circle cx="80" cy="70" r="10" fill="white" />
                <circle cx="80" cy="70" r="5" fill="black" />
                <circle cx="120" cy="70" r="10" fill="white" />
                <circle cx="120" cy="70" r="5" fill="black" />
                <path
                  d="M90,90 C95,95 105,95 110,90"
                  stroke="black"
                  strokeWidth="3"
                  fill="none"
                />
                <path
                  d="M70,115 C80,130 120,130 130,115"
                  stroke="#FFA500"
                  strokeWidth="15"
                  fill="none"
                  strokeLinecap="round"
                />
              </svg>
              <span className="ml-2 text-2xl font-bold text-primary font-nunito">
                SRLS Spanish
              </span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="bg-neutral-200 p-2 rounded-full text-neutral-600 hover:bg-neutral-300"
                >
                  <User className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem className="font-medium text-sm">
                  Signed in as {user?.childName}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="bg-neutral-200 p-2 rounded-full text-neutral-600 hover:bg-neutral-300"
                >
                  <Settings className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>
                  <span>App Settings</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <span>Audio Settings</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <Button
              className="bg-primary text-white px-4 py-2 rounded-full font-medium hover:bg-primary-dark shadow-md"
              onClick={onParentPortalClick}
            >
              Parent Portal
            </Button>
          </div>
        </div>
      </nav>
    </header>
  );
}
