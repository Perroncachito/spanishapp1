import { Card, CardContent } from "@/components/ui/card";

export default function GamePreview() {
  const games = [
    {
      name: "Greeting Match",
      description: "Match Spanish greetings to the right situation!",
      icon: "fa-handshake",
      color: "from-primary-light to-primary",
      textColor: "text-white"
    },
    {
      name: "Memory Cards",
      description: "Find matching pairs of Spanish words and images!",
      icon: "fa-clone",
      color: "from-accent-light to-accent",
      textColor: "text-neutral-800"
    },
    {
      name: "Word Seeker",
      description: "Find hidden Spanish words in a letter grid!",
      icon: "fa-search",
      color: "from-secondary-light to-secondary",
      textColor: "text-white"
    },
    {
      name: "Listen & Select",
      description: "Hear Spanish audio and choose the right option!",
      icon: "fa-headphones",
      color: "from-purple-400 to-purple-500",
      textColor: "text-white"
    },
    {
      name: "Dialogue Builder",
      description: "Complete conversations with the right phrases!",
      icon: "fa-comments",
      color: "from-green-400 to-green-500",
      textColor: "text-white"
    },
    {
      name: "Time Match",
      description: "Match time expressions to the right situations!",
      icon: "fa-clock",
      color: "from-blue-400 to-blue-500",
      textColor: "text-white"
    }
  ];

  return (
    <Card className="bg-white rounded-2xl p-6 shadow-md mb-8">
      <CardContent className="p-0">
        <h2 className="text-2xl font-bold text-neutral-800 font-nunito mb-4">Fun Games Await!</h2>
        <p className="text-neutral-600 mb-4">Each level includes 6 different interactive games to help you master Spanish:</p>
        
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {games.map((game, index) => (
            <div key={index} className={`bg-gradient-to-r ${game.color} rounded-xl p-4 ${game.textColor}`}>
              <div className="flex items-center mb-2">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-6 w-6 mr-2"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={2}
                >
                  {game.icon === "fa-handshake" && (
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M7 11.5V14m0-2.5v-6a1.5 1.5 0 113 0m-3 6a1.5 1.5 0 00-3 0v2a7.5 7.5 0 0015 0v-5a1.5 1.5 0 00-3 0m-6-3V11m0-5.5v-1a1.5 1.5 0 013 0v1m0 0V11m0-5.5a1.5 1.5 0 013 0v3m0 0V11"
                    />
                  )}
                  {game.icon === "fa-clone" && (
                    <>
                      <rect x="2" y="2" width="9" height="9" rx="2" />
                      <rect x="13" y="2" width="9" height="9" rx="2" />
                      <rect x="2" y="13" width="9" height="9" rx="2" />
                      <rect x="13" y="13" width="9" height="9" rx="2" />
                    </>
                  )}
                  {game.icon === "fa-search" && (
                    <>
                      <circle cx="11" cy="11" r="8" />
                      <line x1="21" y1="21" x2="16.65" y2="16.65" />
                    </>
                  )}
                  {game.icon === "fa-headphones" && (
                    <>
                      <path d="M3 18v-6a9 9 0 0 1 18 0v6"></path>
                      <path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"></path>
                    </>
                  )}
                  {game.icon === "fa-comments" && (
                    <>
                      <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                    </>
                  )}
                  {game.icon === "fa-clock" && (
                    <>
                      <circle cx="12" cy="12" r="10" />
                      <polyline points="12 6 12 12 16 14" />
                    </>
                  )}
                </svg>
                <h3 className="font-bold font-nunito">{game.name}</h3>
              </div>
              <p className={`text-sm ${game.textColor} text-opacity-90`}>{game.description}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
