import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Progress, ParentSettings } from "@shared/schema";
import { X } from "lucide-react";

interface ParentPortalProps {
  isOpen: boolean;
  onClose: () => void;
  childName: string;
  progress?: Progress;
  settings?: ParentSettings;
}

export default function ParentPortal({ 
  isOpen, 
  onClose, 
  childName, 
  progress, 
  settings 
}: ParentPortalProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Parent settings state
  const [parentSettings, setParentSettings] = useState<ParentSettings | undefined>(settings);
  const [childNameState, setChildNameState] = useState(childName);
  const [parentEmail, setParentEmail] = useState(settings?.userId ? "parent@example.com" : "");
  const [currentPin, setCurrentPin] = useState("");
  const [newPin, setNewPin] = useState("");
  
  // Day selection state
  const [selectedDays, setSelectedDays] = useState<string[]>(
    settings?.availableDays || ["1", "2", "3", "4", "5"]
  );
  
  // Calculate stats
  const totalLearningTime = progress?.totalTimeSpent || 0;
  const currentLevel = progress?.currentLevel || 1;
  const completedLevels = progress?.completedLevels?.length || 0;
  
  // Format time for display (convert minutes to hours and minutes)
  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
  };

  // Mutation to update parent settings
  const updateSettingsMutation = useMutation({
    mutationFn: async (updatedSettings: Partial<ParentSettings>) => {
      const res = await apiRequest("PATCH", "/api/parent-settings", updatedSettings);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/parent-settings"] });
      toast({
        title: "Settings updated",
        description: "Your parental settings have been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Update failed",
        description: `Failed to update settings: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Handle saving settings
  const handleSaveSettings = () => {
    if (!parentSettings) return;
    
    updateSettingsMutation.mutate({
      sessionDuration: parentSettings.sessionDuration,
      dailyTimeLimit: parentSettings.dailyTimeLimit,
      availableDays: selectedDays,
      startTime: parentSettings.startTime,
      endTime: parentSettings.endTime,
      deviceRestriction: parentSettings.deviceRestriction,
    });
  };
  
  // Handle day selection
  const handleDayToggle = (day: string) => {
    if (selectedDays.includes(day)) {
      setSelectedDays(selectedDays.filter(d => d !== day));
    } else {
      setSelectedDays([...selectedDays, day]);
    }
  };
  
  // Handle session duration change
  const handleSessionDurationChange = (value: string) => {
    if (!parentSettings) return;
    setParentSettings({
      ...parentSettings,
      sessionDuration: parseInt(value),
    });
  };
  
  // Handle daily time limit change
  const handleDailyLimitChange = (value: string) => {
    if (!parentSettings) return;
    setParentSettings({
      ...parentSettings,
      dailyTimeLimit: parseInt(value),
    });
  };
  
  // Handle time range change
  const handleStartTimeChange = (value: string) => {
    if (!parentSettings) return;
    setParentSettings({
      ...parentSettings,
      startTime: value,
    });
  };
  
  const handleEndTimeChange = (value: string) => {
    if (!parentSettings) return;
    setParentSettings({
      ...parentSettings,
      endTime: value,
    });
  };
  
  // Handle device restriction toggle
  const handleDeviceRestrictionToggle = () => {
    if (!parentSettings) return;
    setParentSettings({
      ...parentSettings,
      deviceRestriction: !parentSettings.deviceRestriction,
    });
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
        <DialogHeader className="bg-neutral-800 text-white p-4 rounded-t-2xl flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center">
            <svg width="40" height="40" viewBox="0 0 200 200" className="h-10 mr-2">
              <path
                d="M100,20 C130,20 150,40 150,70 C150,85 140,95 135,100 C145,110 150,125 150,140 C150,170 130,190 100,190 C70,190 50,170 50,140 C50,125 55,110 65,100 C60,95 50,85 50,70 C50,40 70,20 100,20 Z"
                fill="#FF6B6B"
              />
              <circle cx="80" cy="70" r="10" fill="white" />
              <circle cx="80" cy="70" r="5" fill="black" />
              <circle cx="120" cy="70" r="10" fill="white" />
              <circle cx="120" cy="70" r="5" fill="black" />
              <path
                d="M90,90 C95,95 105,95 110,90"
                stroke="black"
                strokeWidth="3"
                fill="none"
              />
              <path
                d="M70,115 C80,130 120,130 130,115"
                stroke="#FFA500"
                strokeWidth="15"
                fill="none"
                strokeLinecap="round"
              />
            </svg>
            <DialogTitle className="text-xl font-bold font-nunito">Parent Portal</DialogTitle>
          </div>
          <Button 
            variant="ghost" 
            className="text-white hover:text-neutral-300"
            onClick={onClose}
          >
            <X className="h-5 w-5" />
          </Button>
        </DialogHeader>
        
        <div className="p-6">
          <div className="flex flex-col md:flex-row gap-6">
            {/* Left Column: Child Progress */}
            <div className="md:w-2/3">
              <div className="bg-neutral-100 rounded-xl p-4 mb-6">
                <h3 className="text-xl font-bold text-neutral-800 font-nunito mb-3">
                  {childName}'s Progress
                </h3>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="bg-white rounded-lg p-3 shadow-sm">
                    <div className="text-xs text-neutral-500 mb-1">Total Learning Time</div>
                    <div className="text-2xl font-bold text-neutral-800">{formatTime(totalLearningTime)}</div>
                  </div>
                  <div className="bg-white rounded-lg p-3 shadow-sm">
                    <div className="text-xs text-neutral-500 mb-1">Current Level</div>
                    <div className="text-2xl font-bold text-neutral-800">Level {currentLevel}</div>
                  </div>
                  <div className="bg-white rounded-lg p-3 shadow-sm">
                    <div className="text-xs text-neutral-500 mb-1">Levels Completed</div>
                    <div className="text-2xl font-bold text-success">{completedLevels} / 30</div>
                  </div>
                  <div className="bg-white rounded-lg p-3 shadow-sm">
                    <div className="text-xs text-neutral-500 mb-1">Vocabulary Learned</div>
                    <div className="text-2xl font-bold text-neutral-800">~{completedLevels * 15} words</div>
                  </div>
                </div>
                
                <h4 className="font-bold text-neutral-700 mb-2">Recent Activity</h4>
                <div className="bg-white rounded-lg p-3 shadow-sm mb-4">
                  {progress ? (
                    <div className="space-y-2">
                      <div className="flex justify-between items-center border-b border-neutral-100 pb-2">
                        <div>
                          <div className="font-medium">Level {currentLevel} Session</div>
                          <div className="text-xs text-neutral-500">
                            {progress.lastGameType || "Various games"} completed
                          </div>
                        </div>
                        <div className="text-sm text-neutral-500">
                          {progress.lastPlayed 
                            ? new Date(progress.lastPlayed).toLocaleString() 
                            : "Not played yet"}
                        </div>
                      </div>
                      {completedLevels > 0 && (
                        <div className="flex justify-between items-center border-b border-neutral-100 pb-2">
                          <div>
                            <div className="font-medium">Level {completedLevels} Completed</div>
                            <div className="text-xs text-neutral-500">Quiz passed successfully</div>
                          </div>
                          <div className="text-sm text-neutral-500">Recently</div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-neutral-500 text-center py-2">
                      No activity recorded yet.
                    </div>
                  )}
                </div>
                
                <Button 
                  className="w-full bg-secondary hover:bg-secondary-dark text-white py-2 rounded-lg shadow-sm"
                >
                  View Full Learning Report
                </Button>
              </div>
              
              {/* Subscription Status */}
              <div className="bg-neutral-100 rounded-xl p-4">
                <h3 className="text-xl font-bold text-neutral-800 font-nunito mb-3">Subscription Status</h3>
                
                <div className="bg-primary bg-opacity-10 border border-primary rounded-lg p-4 mb-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="text-primary font-bold">Free Trial</div>
                      <div className="text-sm text-neutral-600">Only Level 1 accessible</div>
                    </div>
                    <Button 
                      className="bg-primary hover:bg-primary-dark text-white px-4 py-2 rounded-lg shadow-sm"
                    >
                      Upgrade Now
                    </Button>
                  </div>
                </div>
                
                <div className="bg-white rounded-lg p-4 shadow-sm">
                  <h4 className="font-bold text-neutral-700 mb-2">Unlock All Content</h4>
                  <div className="space-y-2 mb-4">
                    <div className="flex items-start">
                      <svg className="h-5 w-5 text-success mt-1 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      <div className="text-sm">Access to all 30 levels across 10 thematic units</div>
                    </div>
                    <div className="flex items-start">
                      <svg className="h-5 w-5 text-success mt-1 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      <div className="text-sm">500+ vocabulary words with native speaker audio</div>
                    </div>
                    <div className="flex items-start">
                      <svg className="h-5 w-5 text-success mt-1 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      <div className="text-sm">180+ interactive games and 450+ quiz questions</div>
                    </div>
                    <div className="flex items-start">
                      <svg className="h-5 w-5 text-success mt-1 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      <div className="text-sm">Detailed progress reports and learning analytics</div>
                    </div>
                  </div>
                  <div className="text-center text-neutral-700 font-bold mb-2">$9.99/month or $89.99/year</div>
                </div>
              </div>
            </div>
            
            {/* Right Column: Time Management & Settings */}
            <div className="md:w-1/3">
              {/* Time Management */}
              <div className="bg-neutral-100 rounded-xl p-4 mb-6">
                <h3 className="text-xl font-bold text-neutral-800 font-nunito mb-3">Learning Schedule</h3>
                
                <div className="space-y-4">
                  <div>
                    <Label className="block text-sm font-medium text-neutral-700 mb-1">Session Duration</Label>
                    <Select
                      value={parentSettings?.sessionDuration?.toString()}
                      onValueChange={handleSessionDurationChange}
                    >
                      <SelectTrigger className="w-full rounded-lg border border-neutral-300 focus:ring-2 focus:ring-secondary focus:border-secondary">
                        <SelectValue placeholder="Select duration" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="15">15 minutes</SelectItem>
                        <SelectItem value="30">30 minutes</SelectItem>
                        <SelectItem value="45">45 minutes</SelectItem>
                        <SelectItem value="60">60 minutes</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label className="block text-sm font-medium text-neutral-700 mb-1">Daily Time Limit</Label>
                    <Select
                      value={parentSettings?.dailyTimeLimit?.toString()}
                      onValueChange={handleDailyLimitChange}
                    >
                      <SelectTrigger className="w-full rounded-lg border border-neutral-300 focus:ring-2 focus:ring-secondary focus:border-secondary">
                        <SelectValue placeholder="Select limit" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="30">30 minutes</SelectItem>
                        <SelectItem value="60">1 hour</SelectItem>
                        <SelectItem value="120">2 hours</SelectItem>
                        <SelectItem value="240">No limit</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label className="block text-sm font-medium text-neutral-700 mb-1">Available Days</Label>
                    <div className="flex flex-wrap gap-2 mb-2">
                      {['1', '2', '3', '4', '5', '6', '0'].map((day, index) => {
                        const dayLabels = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
                        const isSelected = selectedDays.includes(day);
                        
                        return (
                          <Button
                            key={day}
                            type="button"
                            className={`w-10 h-10 rounded-full font-bold ${
                              isSelected 
                                ? 'bg-secondary text-white' 
                                : 'bg-neutral-300 text-neutral-700'
                            }`}
                            onClick={() => handleDayToggle(day)}
                          >
                            {dayLabels[index]}
                          </Button>
                        );
                      })}
                    </div>
                  </div>
                  
                  <div>
                    <Label className="block text-sm font-medium text-neutral-700 mb-1">Available Hours</Label>
                    <div className="flex space-x-3 items-center">
                      <Select
                        value={parentSettings?.startTime}
                        onValueChange={handleStartTimeChange}
                      >
                        <SelectTrigger className="rounded-lg border border-neutral-300 p-2 w-24 focus:ring-2 focus:ring-secondary focus:border-secondary">
                          <SelectValue placeholder="Start" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="09:00">9:00 AM</SelectItem>
                          <SelectItem value="12:00">12:00 PM</SelectItem>
                          <SelectItem value="15:00">3:00 PM</SelectItem>
                          <SelectItem value="16:00">4:00 PM</SelectItem>
                        </SelectContent>
                      </Select>
                      <span className="text-neutral-600">to</span>
                      <Select
                        value={parentSettings?.endTime}
                        onValueChange={handleEndTimeChange}
                      >
                        <SelectTrigger className="rounded-lg border border-neutral-300 p-2 w-24 focus:ring-2 focus:ring-secondary focus:border-secondary">
                          <SelectValue placeholder="End" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="17:00">5:00 PM</SelectItem>
                          <SelectItem value="18:00">6:00 PM</SelectItem>
                          <SelectItem value="20:00">8:00 PM</SelectItem>
                          <SelectItem value="21:00">9:00 PM</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Account Settings */}
              <div className="bg-neutral-100 rounded-xl p-4">
                <h3 className="text-xl font-bold text-neutral-800 font-nunito mb-3">Account Settings</h3>
                
                <div className="space-y-4">
                  <div>
                    <Label className="block text-sm font-medium text-neutral-700 mb-1">Child's Name</Label>
                    <Input 
                      type="text" 
                      value={childNameState}
                      onChange={(e) => setChildNameState(e.target.value)}
                      className="w-full rounded-lg border border-neutral-300 p-2 focus:ring-2 focus:ring-secondary focus:border-secondary"
                    />
                  </div>
                  
                  <div>
                    <Label className="block text-sm font-medium text-neutral-700 mb-1">Parent Email</Label>
                    <Input 
                      type="email" 
                      value={parentEmail}
                      onChange={(e) => setParentEmail(e.target.value)}
                      className="w-full rounded-lg border border-neutral-300 p-2 focus:ring-2 focus:ring-secondary focus:border-secondary"
                    />
                  </div>
                  
                  <div>
                    <Label className="block text-sm font-medium text-neutral-700 mb-1">Change PIN</Label>
                    <div className="space-y-2">
                      <Input 
                        type="password" 
                        placeholder="Enter current PIN" 
                        value={currentPin}
                        onChange={(e) => setCurrentPin(e.target.value)}
                        maxLength={4}
                        className="w-full rounded-lg border border-neutral-300 p-2 focus:ring-2 focus:ring-secondary focus:border-secondary"
                      />
                      <Input 
                        type="password" 
                        placeholder="Enter new 4-digit PIN" 
                        value={newPin}
                        onChange={(e) => setNewPin(e.target.value)}
                        maxLength={4}
                        className="w-full rounded-lg border border-neutral-300 p-2 focus:ring-2 focus:ring-secondary focus:border-secondary"
                      />
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium text-neutral-700">Device Restriction</Label>
                    <label className="toggle-switch">
                      <input 
                        type="checkbox" 
                        checked={parentSettings?.deviceRestriction}
                        onChange={handleDeviceRestrictionToggle}
                      />
                      <span className="toggle-slider"></span>
                    </label>
                  </div>
                  
                  <Button 
                    className="w-full bg-neutral-800 hover:bg-neutral-700 text-white py-2 rounded-lg shadow-sm mt-2"
                    onClick={handleSaveSettings}
                    disabled={updateSettingsMutation.isPending}
                  >
                    {updateSettingsMutation.isPending ? "Saving..." : "Save Settings"}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
