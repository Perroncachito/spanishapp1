import { useState, useRef, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";

interface PinEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPinVerified: (isValid: boolean) => void;
}

export default function PinEntryModal({ isOpen, onClose, onPinVerified }: PinEntryModalProps) {
  const [pin, setPin] = useState<string[]>(["", "", "", ""]);
  const [errorMessage, setErrorMessage] = useState("");
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const { verifyPinMutation } = useAuth();
  
  // Reset state when modal opens
  useEffect(() => {
    if (isOpen) {
      setPin(["", "", "", ""]);
      setErrorMessage("");
      // Focus the first input when modal opens
      setTimeout(() => {
        inputRefs.current[0]?.focus();
      }, 100);
    }
  }, [isOpen]);
  
  // Handle input change
  const handleInputChange = (index: number, value: string) => {
    // Only allow digits
    if (!/^\d*$/.test(value)) return;
    
    // Update the pin array
    const newPin = [...pin];
    newPin[index] = value.slice(0, 1); // Only take the first character
    setPin(newPin);
    
    // Clear any previous error message
    if (errorMessage) setErrorMessage("");
    
    // Auto focus next input if value is entered
    if (value && index < 3) {
      inputRefs.current[index + 1]?.focus();
    }
    
    // If last digit is entered, validate PIN
    if (index === 3 && value) {
      setTimeout(() => {
        validatePin();
      }, 100);
    }
  };
  
  // Handle key down events for backspace navigation
  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    // If backspace is pressed and the input is empty, focus the previous input
    if (e.key === "Backspace" && !pin[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };
  
  // Validate the complete PIN
  const validatePin = () => {
    const completePin = pin.join("");
    
    // Check if PIN is complete
    if (completePin.length !== 4) {
      setErrorMessage("Please enter all 4 digits of your PIN");
      return;
    }
    
    // Verify PIN with the server
    verifyPinMutation.mutate({ pin: completePin }, {
      onSuccess: (data) => {
        if (data.valid) {
          onPinVerified(true);
        } else {
          setErrorMessage("Incorrect PIN. Please try again.");
          // Clear PIN inputs
          setPin(["", "", "", ""]);
          // Focus the first input
          inputRefs.current[0]?.focus();
        }
      },
      onError: () => {
        setErrorMessage("An error occurred. Please try again.");
        // Clear PIN inputs
        setPin(["", "", "", ""]);
        // Focus the first input
        inputRefs.current[0]?.focus();
      }
    });
  };
  
  // Handle forgot PIN (would typically send a reset email)
  const handleForgotPin = () => {
    // In a real application, this would initiate a PIN recovery process
    alert("In a real application, this would send a recovery email to the parent's email address.");
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-neutral-800 font-nunito text-center">
            Parent Access Required
          </DialogTitle>
          <DialogDescription className="text-center">
            Please enter your 4-digit PIN to access the parent portal.
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex justify-center space-x-4 my-6">
          {[0, 1, 2, 3].map((index) => (
            <input
              key={index}
              type="password"
              maxLength={1}
              value={pin[index]}
              onChange={(e) => handleInputChange(index, e.target.value)}
              onKeyDown={(e) => handleKeyDown(index, e)}
              ref={(el) => (inputRefs.current[index] = el)}
              className="w-12 h-16 text-2xl text-center border-2 border-neutral-300 rounded-lg focus:ring-2 focus:ring-secondary focus:border-secondary"
              autoComplete="off"
            />
          ))}
        </div>
        
        {errorMessage && (
          <div className="text-error text-center font-medium">
            {errorMessage}
          </div>
        )}
        
        <DialogFooter className="flex justify-between sm:justify-between">
          <Button 
            variant="link" 
            className="text-secondary hover:text-secondary-dark"
            onClick={handleForgotPin}
          >
            Forgot PIN?
          </Button>
          
          <div className="space-x-2">
            <Button
              variant="outline"
              onClick={onClose}
            >
              Cancel
            </Button>
            
            <Button
              variant="default"
              onClick={validatePin}
              disabled={pin.some(digit => !digit) || verifyPinMutation.isPending}
              className="bg-primary hover:bg-primary-dark"
            >
              {verifyPinMutation.isPending ? "Verifying..." : "Submit"}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
