import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Volume2, VolumeX } from "lucide-react";

export default function SoundTest() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);
  const [audioSuccess, setAudioSuccess] = useState(false);
  
  const testSound = () => {
    setAudioError(null);
    setAudioSuccess(false);
    setIsPlaying(true);
    
    try {
      // Create a simple oscillator for a test sound
      const audioContext = new AudioContext();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      // Set properties for a pleasant test sound
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(440, audioContext.currentTime); // A4 note
      gainNode.gain.setValueAtTime(0.1, audioContext.currentTime); // Lower volume
      
      // Play for 1 second
      oscillator.start();
      gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 1);
      oscillator.stop(audioContext.currentTime + 1);
      
      // Mark as success
      setAudioSuccess(true);
      
      // Clean up
      setTimeout(() => {
        setIsPlaying(false);
        oscillator.disconnect();
        gainNode.disconnect();
        audioContext.close();
      }, 1100);
      
    } catch (error) {
      console.error('Audio playback failed:', error);
      setAudioError(
        error instanceof Error 
          ? error.message 
          : 'Unknown audio error occurred. Check browser sound settings.'
      );
      setIsPlaying(false);
    }
  };
  
  return (
    <div className="p-4 bg-white rounded-lg shadow-md mb-6">
      <h3 className="text-lg font-semibold mb-3 flex items-center">
        <Volume2 className="mr-2 h-5 w-5 text-primary" /> 
        Sound Test
      </h3>
      
      <p className="text-neutral-600 mb-4">
        Click the button below to test your sound. You should hear a brief tone if sound is working properly.
      </p>
      
      <div className="flex flex-col items-start space-y-4">
        <Button 
          onClick={testSound} 
          disabled={isPlaying}
          variant={audioSuccess ? "outline" : "default"}
          className={audioSuccess ? "border-green-500 text-green-600" : ""}
        >
          {isPlaying ? (
            <>
              <span className="animate-pulse mr-2">•</span>
              Playing test sound...
            </>
          ) : audioSuccess ? (
            <>
              <span className="text-green-500 mr-2">✓</span>
              Sound working! Test again
            </>
          ) : (
            <>
              <Volume2 className="mr-2 h-4 w-4" />
              Test Sound
            </>
          )}
        </Button>
        
        {audioError && (
          <div className="text-red-500 bg-red-50 p-3 rounded-md flex items-start">
            <VolumeX className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Sound Error</p>
              <p className="text-sm">{audioError}</p>
              <p className="text-sm mt-2">Suggestions:</p>
              <ul className="text-sm list-disc pl-5 mt-1">
                <li>Check if your device is not muted</li>
                <li>Ensure browser has permission to play audio</li>
                <li>Try using headphones</li>
                <li>Close other tabs or applications that might be using audio</li>
                <li>Refresh the page and try again</li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
